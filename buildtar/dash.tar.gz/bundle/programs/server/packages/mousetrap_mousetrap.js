(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Mousetrap;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mousetrap_mousetrap/packages/mousetrap_mousetrap.js      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("mousetrap:mousetrap", {
  Mousetrap: Mousetrap
});

})();
