var require = meteorInstall({"lib":{"at_config.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/at_config.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
AccountsTemplates.configure({
  confirmPassword: false,
  overrideLoginErrors: false,
  lowercaseUsername: true,
  showForgotPasswordLink: true,
  homeRoutePath: '/'
});

if (Meteor.isServer) {
  Meteor.methods({
    "userExists": function (username) {
      return !!Meteor.users.findOne({
        username: username
      });
    }
  });
}

AccountsTemplates.addField({
  _id: 'username',
  type: 'text',
  displayName: "Location",
  required: true,
  func: function (value) {
    if (Meteor.isClient) {
      console.log("Validating location...");
      var self = this;
      Meteor.call("userExists", value, function (err, userExists) {
        if (!userExists) self.setSuccess();else self.setError(userExists);
        self.setValidating(false);
      });
      return;
    } // Server


    return Meteor.call("userExists", value);
  }
});
AccountsTemplates.configureRoute('signIn', {
  redirect: '/'
});
AccountsTemplates.configureRoute('signUp', {
  redirect: '/'
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collections.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/collections.js                                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// import { Mongo } from 'meteor/mongo';
// if (Meteor.isServer){
// 	db = new MongoInternals.RemoteCollectionDriver("mongodb://" + mongo_user + ":" + mongo_pass + "@" +  mongo_ip + ":27017/cspace");
// }
// members = new Mongo.Collection("members", {_driver: db});
members = new Mongo.Collection("members"); // console.log(members.findOne());

activities = new Mongo.Collection("activities");
displaySpaces = new Mongo.Collection("displaySpaces"); // presences = new Mongo.Collection("presences");

smallGroups = new Mongo.Collection("smallGroups");
affinities = new Mongo.Collection("affinities");
helpRequests = new Mongo.Collection("helpRequests");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"config.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/config.js                                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.startup(() => {// console.log(process.env.MONGO_URL);
  // export MONGO_URL = "mongodb://" + mongo_user + ":" + mongo_pass + "@" +  mongo_ip + ":27017/cspace";
  // process.env.MONGO_URL = "mongodb://" + mongo_user + ":" + mongo_pass + "@" +  mongo_ip + ":27017/cspace";
}); // rests = new Mongo.Collection("restaurants");
// console.log("mongodb://" + mongo_user + ":" + mongo_pass + "@" +  mongo_ip + ":27017/cspace");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logins.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/logins.js                                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
mongo_user = "meteorReader";
mongo_pass = "bottle-plot-grange-cochlea";
mongo_ip = "52.41.24.224";
peerKey = "rwcwolonbw8hyqfr";
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/routes.js                                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Router.route('/', function () {
  Session.set("Member", "0");
  Session.set("Name", undefined);
  Session.set("User", Meteor.user());

  if (Meteor.userId() != undefined && smallGroups.find().fetch().length > 0) {
    // console.log(smallGroups.find().fetch());
    this.render('home');
  } else {
    this.render('loading');
  }

  console.log("home");
});
Router.route('/askHelp', function () {
  if (Meteor.userId() != undefined) {
    this.render("askHelp");
  } else {
    this.render("loading");
  }
});
Router.route('/askHelp/:roomName', function () {
  var allRooms = ["maldenengg", "maldendesign"];
  var rName = String(this.params.roomName).toLowerCase();
  roomUser = Meteor.users.findOne({
    "username": rName
  });
  roomID = null;

  if (roomUser != null) {
    roomID = roomUser._id;
  }

  if (roomID != null) {
    Session.set("helpRoom", roomID);
    this.render("askHelp");
  } else {
    Session.set("helpRoom", null);
    this.render("loading");
  }
});
Router.route('/member/:memid', function () {
  var memId = String(this.params.memid);
  Session.set("Member", memId);
  this.subscribe('members', this.params.memId).wait();
  console.log(this.ready());

  if (this.ready()) {
    Router.go('/memberCheck');
  } else {
    this.render("loading");
    this.next();
  }
});
Router.route('/memberCheck', function () {
  memId = Session.get("Member");
  console.log(members.findOne());

  if (members.findOne({
    "MemberID": memId
  }) != undefined) {
    Router.go('/actitout');
  } else {
    Router.go('/newMember');
  }
});
Router.route('/setLocation/', function () {
  this.render("locationRegistration");

  if (Meteor.userId() != undefined) {
    this.render("locationSettings");
  }
});
Router.route('/actitout', function () {
  if (Session.get("Member") == "0" || Session.get("Member") == undefined) {
    alert("You haven't tapped a card!");
    Router.go('/');
  } else {
    this.render('activityEntry');
  }
});
Router.route('/newMember', function () {
  if (Session.get("Member") == "0" || Session.get("Member") == undefined) {
    alert("You haven't tapped a card!");
    Router.go('/');
  } else {
    this.render('signUp');
  }
});
Router.route('/admin', function () {
  this.render("administration");

  if (Meteor.userId() == undefined) {
    this.render("locationRegistration");
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"apisetup.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/apisetup.js                                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
if (Meteor.isServer) {
  // Global API configuration
  var Api = new Restivus({
    useDefaultAuth: true,
    prettyJson: true
  }); // Generates: GET, POST on /api/items and GET, PUT, PATCH, DELETE on
  // /api/items/:id for the Items collection

  Api.addCollection(members);
  Api.addCollection(activities); // Generates: POST on /api/users and GET, DELETE /api/users/:id for
  // Meteor.users collection

  Api.addCollection(Meteor.users, {
    excludedEndpoints: ['getAll', 'put'],
    routeOptions: {
      authRequired: true
    },
    endpoints: {
      post: {
        authRequired: false
      },
      delete: {
        roleRequired: 'admin'
      }
    }
  }); // Maps to: /api/articles/:id

  Api.addRoute('articles/:id', {
    authRequired: true
  }, {
    get: function () {
      return Articles.findOne(this.urlParams.id);
    },
    delete: {
      roleRequired: ['author', 'admin'],
      action: function () {
        if (Articles.remove(this.urlParams.id)) {
          return {
            status: 'success',
            data: {
              message: 'Article removed'
            }
          };
        }

        return {
          statusCode: 404,
          body: {
            status: 'fail',
            message: 'Article not found'
          }
        };
      }
    }
  });
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// import { Meteor } from 'meteor/meteor';
// import { Mongo } from 'meteor/mongo';
// console.log("mongodb://" + mongo_user + ":" + mongo_pass + "@" +  mongo_ip + ":27017/cspace");
// db = new MongoInternals.RemoteCollectionDriver("mongodb://" + mongo_user + ":" + mongo_pass + "@" +  mongo_ip + ":27017/cspace");
// export const members = new Mongo.Collection("members", {_driver: db});
// export const activities = new Mongo.Collection("activities", {_driver: db});
date = new Date();
Meteor.startup(() => {
  // SSLProxy({
  //    port: 6000, //or 443 (normal port/requires sudo)
  //    ssl : {
  //         key: Assets.getText("server.key"),
  //         cert: Assets.getText("server.crt"),
  //         //Optional CA
  //         //Assets.getText("ca.pem")
  //    }
  // });
  // console.log(rests.findOne({}));
  // console.log(members.findOne({}));
  // code to run on server at startup
  requestDuration = 300000;
  Meteor.publish('userPresence', function () {
    // Setup some filter to find the users your user
    // cares about. It's unlikely that you want to publish the 
    // presences of _all_ the users in the system.
    // If for example we wanted to publish only logged in users we could apply:
    // filter = { userId: { $exists: true }};
    var filter = {};
    return Presences.find(filter, {
      fields: {
        state: true,
        userId: true,
        peerID: true
      }
    });
  });
  Meteor.methods({
    createMember: function (memId, name, zipcode) {
      members.insert({
        "MemberID": memId,
        "Name": name,
        "Zipcode": zipcode,
        "CreatedAt": new Date().getTime()
      });
      return name;
    },
    logActivity: function (memId, name, activity, locationID, location) {
      Meteor.call("logOut", memId);
      activities.insert({
        "LoggedIn": new Date().getTime(),
        "Name": name,
        "MemberID": memId,
        "CurrentActivity": activity,
        "Location": location,
        "locationID": locationID,
        "Status": "in"
      });
      return "logged";
    },
    clearCardUser: function (memId) {
      members.remove({
        "MemberID": memId
      });
      Meteor.call("logOut", memId);
      return "Card cleared";
    },
    logOut: function (memId) {
      activities.update({
        "MemberID": memId
      }, {
        $set: {
          "Status": "out",
          "LogOutTime": new Date().getTime()
        }
      }, {
        multi: true
      });
      return true;
    },
    checkLogins: function () {
      console.log("checking");
      timeOut = 18000000; // timeOut = 5000;

      activities.find({
        $and: [{
          "LoggedIn": {
            $lt: new Date().getTime() - timeOut
          }
        }, {
          "Status": "in"
        }]
      }).forEach(function (doc) {
        Meteor.call("logOut", doc.MemberID);
        console.log("logging out " + doc.MemberID);
      });
    },
    test: function (tex) {
      console.log(tex);
    },
    getLiveRequests: function (room) {
      // return helpRequests.find({$and: [{"room": Meteor.userId(), "requestCreated": {$gt: date.getTime() - 300000}}]});
      return null;
    },
    requestHelp: function (room, affinity, helpee) {
      // if (helpRequests.find({$and: [{"room": room, "affinity": affinity, "helpee": helpee, "requestCreated": {$gt: date.getTime() - requestDuration}}]}) == undefined) {
      console.log("adding request " + room + " " + affinity + " " + helpee);
      helpRequests.insert({
        "room": room,
        "affinity": affinity,
        "helpee": helpee,
        "requestCreated": new Date().getTime(),
        "resolved": false
      }); // }
      // else{
      //     console.log("not adding request");
      // }
    },
    resolveRequest: function (reqId, helperId, comments) {
      helperDeets = {};
      helper = smallGroups.findOne({
        "_id": helperId
      });

      if (helper != null) {
        helperDeets = {
          "name": helper.student,
          "team": helper.team,
          "affinities": helper.affinities
        };
      }

      helpRequests.update({
        "_id": reqId
      }, {
        $set: {
          "resolved": true,
          "helperId": helperId,
          "helperDetails": helperDeets,
          "comments": comments
        }
      });
    },
    addAffinity: function (room, affinity, faclass) {
      affinities.update({
        $and: [{
          "room": room
        }, {
          "affinity": affinity
        }]
      }, {
        "room": room,
        "affinity": affinity,
        "faclass": faclass
      }, {
        upsert: true
      });
    },
    addBoxPerson: function (room, team, student, affinities, visibility) {
      if (visibility == false) {
        smallGroups.update({
          $and: [{
            "room": room
          }, {
            "team": team
          }, {
            "student": student
          }]
        }, {
          $set: {
            "visibility": false
          }
        });
      } else {
        smallGroups.update({
          $and: [{
            "room": room
          }, {
            "team": team
          }, {
            "student": student
          }]
        }, {
          "room": room,
          "team": team,
          "student": student,
          "affinities": affinities,
          "visibility": true
        }, {
          upsert: true
        });
      } // smallGroups.update(
      //     {$and: [
      //         {"room": room}, 
      //         {"info": "boxList"}
      //     ]}, 
      //     {
      //         "room": room, 
      //         "info": "boxList", 
      //         // $addToSet: {"visibleBoxes": team}
      //     },
      //     {upsert: true}
      // );


      smallGroups.update({
        $and: [{
          "room": room
        }, {
          "info": "boxList"
        }]
      }, {
        $addToSet: {
          "existingBoxes": team
        }
      });
      smallGroups.update({
        $and: [{
          "room": room
        }, {
          "info": "boxList"
        }]
      }, {
        $addToSet: {
          "visibleBoxes": team
        }
      });
    },
    // updateVisibleBoxes
    setVisibleBoxes: function (uid, vboxes) {
      console.log(vboxes);

      if (vboxes.length == 0) {
        console.log("filling smallGroup"); // smallGroups.update({$and: [{"room": uid}, {"info": "boxList"}]}, {"room": uid, "info": "boxList", "visibleBoxes": vboxes}, {upsert: true});

        smallGroups.insert({
          "room": uid,
          "info": "boxList",
          "visibleBoxes": vboxes,
          "existingBoxes": []
        });
      } else if (vboxes.length > 0) {
        smallGroups.update({
          $and: [{
            "room": uid
          }, {
            "info": "boxList"
          }]
        }, {
          $set: {
            "visibleBoxes": vboxes
          }
        });
      }
    },
    setDisplaySpace: function (uid, space1, space2) {
      displaySpaces.update({
        "roomID": uid,
        "location": "space1"
      }, {
        "roomID": uid,
        "location": "space1",
        "spaceID": space1
      }, // {$setOnInsert: {"roomID": uid, "location": "space1"} },
      {
        upsert: true,
        multi: false
      });
      console.log(space1 + " " + uid);
      displaySpaces.update({
        "roomID": uid,
        "location": "space2"
      }, {
        "roomID": uid,
        "location": "space2",
        "spaceID": space2
      }, {
        upsert: true,
        multi: false
      });
    }
  }); // Meteor.setInterval(function () {
  //     Meteor.call('checkLogins');
  // }, 300000);
  // }, 1000);
});
Meteor.publish('members', function tasksPublication() {
  return members.find();
});
Accounts.onCreateUser(function (options, user) {
  // space1 = user._id;
  // console.log(Meteor.users);
  console.log(user._id); // space2 = Meteor.users.findOne()._id;
  // displaySpaces.update({
  //     $and: [{"roomID": user._id}, {"location": "space1"}]
  // },
  // {$set: {$"spaceID": space1} },
  // // {$setOnInsert: {"roomID": uid, "location": "space1"} },
  // {upsert: true} );
  // displaySpaces.update(
  //     {$and: [
  //         {"roomID": user._id}, 
  //         {"location": "space2"}
  //     ]},
  //     {$set: {$"spaceID": space2} },
  // // {$setOnInsert: {"roomID": uid, "location": "space1"} },
  //     {upsert: true}
  // );

  Meteor.call("setDisplaySpace", user._id, user._id, user._id);
  Meteor.call("setVisibleBoxes", user._id, []); // smallGroups.update({$and: [{"room": room}, {"info": "boxList"}]}

  return user;
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/at_config.js");
require("/lib/collections.js");
require("/lib/config.js");
require("/lib/logins.js");
require("/lib/routes.js");
require("/server/apisetup.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2F0X2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvY29uZmlnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbG9naW5zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvcm91dGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvYXBpc2V0dXAuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIkFjY291bnRzVGVtcGxhdGVzIiwiY29uZmlndXJlIiwiY29uZmlybVBhc3N3b3JkIiwib3ZlcnJpZGVMb2dpbkVycm9ycyIsImxvd2VyY2FzZVVzZXJuYW1lIiwic2hvd0ZvcmdvdFBhc3N3b3JkTGluayIsImhvbWVSb3V0ZVBhdGgiLCJNZXRlb3IiLCJpc1NlcnZlciIsIm1ldGhvZHMiLCJ1c2VybmFtZSIsInVzZXJzIiwiZmluZE9uZSIsImFkZEZpZWxkIiwiX2lkIiwidHlwZSIsImRpc3BsYXlOYW1lIiwicmVxdWlyZWQiLCJmdW5jIiwidmFsdWUiLCJpc0NsaWVudCIsImNvbnNvbGUiLCJsb2ciLCJzZWxmIiwiY2FsbCIsImVyciIsInVzZXJFeGlzdHMiLCJzZXRTdWNjZXNzIiwic2V0RXJyb3IiLCJzZXRWYWxpZGF0aW5nIiwiY29uZmlndXJlUm91dGUiLCJyZWRpcmVjdCIsIm1lbWJlcnMiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJhY3Rpdml0aWVzIiwiZGlzcGxheVNwYWNlcyIsInNtYWxsR3JvdXBzIiwiYWZmaW5pdGllcyIsImhlbHBSZXF1ZXN0cyIsInN0YXJ0dXAiLCJtb25nb191c2VyIiwibW9uZ29fcGFzcyIsIm1vbmdvX2lwIiwicGVlcktleSIsIlJvdXRlciIsInJvdXRlIiwiU2Vzc2lvbiIsInNldCIsInVuZGVmaW5lZCIsInVzZXIiLCJ1c2VySWQiLCJmaW5kIiwiZmV0Y2giLCJsZW5ndGgiLCJyZW5kZXIiLCJhbGxSb29tcyIsInJOYW1lIiwiU3RyaW5nIiwicGFyYW1zIiwicm9vbU5hbWUiLCJ0b0xvd2VyQ2FzZSIsInJvb21Vc2VyIiwicm9vbUlEIiwibWVtSWQiLCJtZW1pZCIsInN1YnNjcmliZSIsIndhaXQiLCJyZWFkeSIsImdvIiwibmV4dCIsImdldCIsImFsZXJ0IiwiQXBpIiwiUmVzdGl2dXMiLCJ1c2VEZWZhdWx0QXV0aCIsInByZXR0eUpzb24iLCJhZGRDb2xsZWN0aW9uIiwiZXhjbHVkZWRFbmRwb2ludHMiLCJyb3V0ZU9wdGlvbnMiLCJhdXRoUmVxdWlyZWQiLCJlbmRwb2ludHMiLCJwb3N0IiwiZGVsZXRlIiwicm9sZVJlcXVpcmVkIiwiYWRkUm91dGUiLCJBcnRpY2xlcyIsInVybFBhcmFtcyIsImlkIiwiYWN0aW9uIiwicmVtb3ZlIiwic3RhdHVzIiwiZGF0YSIsIm1lc3NhZ2UiLCJzdGF0dXNDb2RlIiwiYm9keSIsImRhdGUiLCJEYXRlIiwicmVxdWVzdER1cmF0aW9uIiwicHVibGlzaCIsImZpbHRlciIsIlByZXNlbmNlcyIsImZpZWxkcyIsInN0YXRlIiwicGVlcklEIiwiY3JlYXRlTWVtYmVyIiwibmFtZSIsInppcGNvZGUiLCJpbnNlcnQiLCJnZXRUaW1lIiwibG9nQWN0aXZpdHkiLCJhY3Rpdml0eSIsImxvY2F0aW9uSUQiLCJsb2NhdGlvbiIsImNsZWFyQ2FyZFVzZXIiLCJsb2dPdXQiLCJ1cGRhdGUiLCIkc2V0IiwibXVsdGkiLCJjaGVja0xvZ2lucyIsInRpbWVPdXQiLCIkYW5kIiwiJGx0IiwiZm9yRWFjaCIsImRvYyIsIk1lbWJlcklEIiwidGVzdCIsInRleCIsImdldExpdmVSZXF1ZXN0cyIsInJvb20iLCJyZXF1ZXN0SGVscCIsImFmZmluaXR5IiwiaGVscGVlIiwicmVzb2x2ZVJlcXVlc3QiLCJyZXFJZCIsImhlbHBlcklkIiwiY29tbWVudHMiLCJoZWxwZXJEZWV0cyIsImhlbHBlciIsInN0dWRlbnQiLCJ0ZWFtIiwiYWRkQWZmaW5pdHkiLCJmYWNsYXNzIiwidXBzZXJ0IiwiYWRkQm94UGVyc29uIiwidmlzaWJpbGl0eSIsIiRhZGRUb1NldCIsInNldFZpc2libGVCb3hlcyIsInVpZCIsInZib3hlcyIsInNldERpc3BsYXlTcGFjZSIsInNwYWNlMSIsInNwYWNlMiIsInRhc2tzUHVibGljYXRpb24iLCJBY2NvdW50cyIsIm9uQ3JlYXRlVXNlciIsIm9wdGlvbnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLGtCQUFrQkMsU0FBbEIsQ0FBNEI7QUFDM0JDLG1CQUFpQixLQURVO0FBRXhCQyx1QkFBcUIsS0FGRztBQUd4QkMscUJBQW1CLElBSEs7QUFJeEJDLDBCQUF3QixJQUpBO0FBS3hCQyxpQkFBZTtBQUxTLENBQTVCOztBQVFBLElBQUlDLE9BQU9DLFFBQVgsRUFBb0I7QUFDaEJELFNBQU9FLE9BQVAsQ0FBZTtBQUNYLGtCQUFjLFVBQVNDLFFBQVQsRUFBa0I7QUFDNUIsYUFBTyxDQUFDLENBQUNILE9BQU9JLEtBQVAsQ0FBYUMsT0FBYixDQUFxQjtBQUFDRixrQkFBVUE7QUFBWCxPQUFyQixDQUFUO0FBQ0g7QUFIVSxHQUFmO0FBS0g7O0FBRURWLGtCQUFrQmEsUUFBbEIsQ0FBMkI7QUFDdkJDLE9BQUssVUFEa0I7QUFFdkJDLFFBQU0sTUFGaUI7QUFHdkJDLGVBQWEsVUFIVTtBQUl2QkMsWUFBVSxJQUphO0FBS3ZCQyxRQUFNLFVBQVNDLEtBQVQsRUFBZTtBQUNqQixRQUFJWixPQUFPYSxRQUFYLEVBQXFCO0FBQ2pCQyxjQUFRQyxHQUFSLENBQVksd0JBQVo7QUFDQSxVQUFJQyxPQUFPLElBQVg7QUFDQWhCLGFBQU9pQixJQUFQLENBQVksWUFBWixFQUEwQkwsS0FBMUIsRUFBaUMsVUFBU00sR0FBVCxFQUFjQyxVQUFkLEVBQXlCO0FBQ3RELFlBQUksQ0FBQ0EsVUFBTCxFQUNJSCxLQUFLSSxVQUFMLEdBREosS0FHSUosS0FBS0ssUUFBTCxDQUFjRixVQUFkO0FBQ0pILGFBQUtNLGFBQUwsQ0FBbUIsS0FBbkI7QUFDSCxPQU5EO0FBT0E7QUFDSCxLQVpnQixDQWFqQjs7O0FBQ0EsV0FBT3RCLE9BQU9pQixJQUFQLENBQVksWUFBWixFQUEwQkwsS0FBMUIsQ0FBUDtBQUNIO0FBcEJzQixDQUEzQjtBQXVCQW5CLGtCQUFrQjhCLGNBQWxCLENBQWlDLFFBQWpDLEVBQTJDO0FBQ3pDQyxZQUFVO0FBRCtCLENBQTNDO0FBSUEvQixrQkFBa0I4QixjQUFsQixDQUFpQyxRQUFqQyxFQUEyQztBQUN6Q0MsWUFBVTtBQUQrQixDQUEzQyxFOzs7Ozs7Ozs7OztBQzNDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLFVBQVUsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixTQUFyQixDQUFWLEMsQ0FDQTs7QUFDQUMsYUFBYSxJQUFJRixNQUFNQyxVQUFWLENBQXFCLFlBQXJCLENBQWI7QUFFQUUsZ0JBQWdCLElBQUlILE1BQU1DLFVBQVYsQ0FBcUIsZUFBckIsQ0FBaEIsQyxDQUVBOztBQUVBRyxjQUFjLElBQUlKLE1BQU1DLFVBQVYsQ0FBcUIsYUFBckIsQ0FBZDtBQUVBSSxhQUFhLElBQUlMLE1BQU1DLFVBQVYsQ0FBcUIsWUFBckIsQ0FBYjtBQUVBSyxlQUFlLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsY0FBckIsQ0FBZixDOzs7Ozs7Ozs7OztBQ2xCQTNCLE9BQU9pQyxPQUFQLENBQWUsTUFBTSxDQUNwQjtBQUNBO0FBQ0E7QUFDQSxDQUpELEUsQ0FNQTtBQUNBLGlHOzs7Ozs7Ozs7OztBQ1BBQyxhQUFhLGNBQWI7QUFDQUMsYUFBYSw0QkFBYjtBQUNBQyxXQUFXLGNBQVg7QUFFQUMsVUFBVSxrQkFBVixDOzs7Ozs7Ozs7OztBQ0pBQyxPQUFPQyxLQUFQLENBQWEsR0FBYixFQUFrQixZQUFXO0FBQzVCQyxVQUFRQyxHQUFSLENBQVksUUFBWixFQUFzQixHQUF0QjtBQUNBRCxVQUFRQyxHQUFSLENBQVksTUFBWixFQUFvQkMsU0FBcEI7QUFDQUYsVUFBUUMsR0FBUixDQUFZLE1BQVosRUFBb0J6QyxPQUFPMkMsSUFBUCxFQUFwQjs7QUFDQSxNQUFHM0MsT0FBTzRDLE1BQVAsTUFBbUJGLFNBQW5CLElBQWdDWixZQUFZZSxJQUFaLEdBQW1CQyxLQUFuQixHQUEyQkMsTUFBM0IsR0FBb0MsQ0FBdkUsRUFBMEU7QUFDekU7QUFDQSxTQUFLQyxNQUFMLENBQVksTUFBWjtBQUNBLEdBSEQsTUFJSTtBQUNILFNBQUtBLE1BQUwsQ0FBWSxTQUFaO0FBQ0E7O0FBQ0RsQyxVQUFRQyxHQUFSLENBQVksTUFBWjtBQUNBLENBWkQ7QUFjQXVCLE9BQU9DLEtBQVAsQ0FBYSxVQUFiLEVBQXlCLFlBQVc7QUFDbkMsTUFBSXZDLE9BQU80QyxNQUFQLE1BQW1CRixTQUF2QixFQUFpQztBQUNoQyxTQUFLTSxNQUFMLENBQVksU0FBWjtBQUNBLEdBRkQsTUFHSTtBQUNILFNBQUtBLE1BQUwsQ0FBWSxTQUFaO0FBQ0E7QUFDRCxDQVBEO0FBU0FWLE9BQU9DLEtBQVAsQ0FBYSxvQkFBYixFQUFtQyxZQUFXO0FBQzdDLE1BQUlVLFdBQVcsQ0FBQyxZQUFELEVBQWUsY0FBZixDQUFmO0FBQ0EsTUFBSUMsUUFBUUMsT0FBTyxLQUFLQyxNQUFMLENBQVlDLFFBQW5CLEVBQTZCQyxXQUE3QixFQUFaO0FBQ0FDLGFBQVd2RCxPQUFPSSxLQUFQLENBQWFDLE9BQWIsQ0FBcUI7QUFBQyxnQkFBWTZDO0FBQWIsR0FBckIsQ0FBWDtBQUNBTSxXQUFTLElBQVQ7O0FBQ0EsTUFBSUQsWUFBWSxJQUFoQixFQUFzQjtBQUNyQkMsYUFBU0QsU0FBU2hELEdBQWxCO0FBQ0E7O0FBRUQsTUFBSWlELFVBQVUsSUFBZCxFQUFvQjtBQUNuQmhCLFlBQVFDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCZSxNQUF4QjtBQUNBLFNBQUtSLE1BQUwsQ0FBWSxTQUFaO0FBQ0EsR0FIRCxNQUlLO0FBQ0pSLFlBQVFDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCLElBQXhCO0FBQ0EsU0FBS08sTUFBTCxDQUFZLFNBQVo7QUFDQTtBQUNELENBakJEO0FBbUJBVixPQUFPQyxLQUFQLENBQWEsZ0JBQWIsRUFBK0IsWUFBWTtBQUMxQyxNQUFJa0IsUUFBUU4sT0FBTyxLQUFLQyxNQUFMLENBQVlNLEtBQW5CLENBQVo7QUFDQWxCLFVBQVFDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCZ0IsS0FBdEI7QUFDQSxPQUFLRSxTQUFMLENBQWUsU0FBZixFQUEwQixLQUFLUCxNQUFMLENBQVlLLEtBQXRDLEVBQTZDRyxJQUE3QztBQUNBOUMsVUFBUUMsR0FBUixDQUFZLEtBQUs4QyxLQUFMLEVBQVo7O0FBQ0EsTUFBSSxLQUFLQSxLQUFMLEVBQUosRUFBaUI7QUFDaEJ2QixXQUFPd0IsRUFBUCxDQUFVLGNBQVY7QUFDQSxHQUZELE1BR0k7QUFDSCxTQUFLZCxNQUFMLENBQVksU0FBWjtBQUNBLFNBQUtlLElBQUw7QUFDQTtBQUNELENBWkQ7QUFjQXpCLE9BQU9DLEtBQVAsQ0FBYSxjQUFiLEVBQTZCLFlBQVk7QUFDeENrQixVQUFRakIsUUFBUXdCLEdBQVIsQ0FBWSxRQUFaLENBQVI7QUFDQWxELFVBQVFDLEdBQVIsQ0FBWVUsUUFBUXBCLE9BQVIsRUFBWjs7QUFDQSxNQUFJb0IsUUFBUXBCLE9BQVIsQ0FBZ0I7QUFBQyxnQkFBWW9EO0FBQWIsR0FBaEIsS0FBd0NmLFNBQTVDLEVBQXNEO0FBQ3JESixXQUFPd0IsRUFBUCxDQUFVLFdBQVY7QUFDQSxHQUZELE1BR0s7QUFDSnhCLFdBQU93QixFQUFQLENBQVUsWUFBVjtBQUNBO0FBQ0QsQ0FURDtBQVlBeEIsT0FBT0MsS0FBUCxDQUFhLGVBQWIsRUFBOEIsWUFBWTtBQUN6QyxPQUFLUyxNQUFMLENBQVksc0JBQVo7O0FBQ0EsTUFBR2hELE9BQU80QyxNQUFQLE1BQW1CRixTQUF0QixFQUFpQztBQUNoQyxTQUFLTSxNQUFMLENBQVksa0JBQVo7QUFDQTtBQUNELENBTEQ7QUFPQVYsT0FBT0MsS0FBUCxDQUFhLFdBQWIsRUFBMEIsWUFBWTtBQUNyQyxNQUFHQyxRQUFRd0IsR0FBUixDQUFZLFFBQVosS0FBeUIsR0FBekIsSUFBZ0N4QixRQUFRd0IsR0FBUixDQUFZLFFBQVosS0FBeUJ0QixTQUE1RCxFQUFzRTtBQUNyRXVCLFVBQU0sNEJBQU47QUFDQTNCLFdBQU93QixFQUFQLENBQVUsR0FBVjtBQUNBLEdBSEQsTUFJSztBQUNKLFNBQUtkLE1BQUwsQ0FBWSxlQUFaO0FBQ0E7QUFDRCxDQVJEO0FBVUFWLE9BQU9DLEtBQVAsQ0FBYSxZQUFiLEVBQTJCLFlBQVc7QUFDckMsTUFBR0MsUUFBUXdCLEdBQVIsQ0FBWSxRQUFaLEtBQXlCLEdBQXpCLElBQWdDeEIsUUFBUXdCLEdBQVIsQ0FBWSxRQUFaLEtBQXlCdEIsU0FBNUQsRUFBc0U7QUFDckV1QixVQUFNLDRCQUFOO0FBQ0EzQixXQUFPd0IsRUFBUCxDQUFVLEdBQVY7QUFDQSxHQUhELE1BSUs7QUFDSixTQUFLZCxNQUFMLENBQVksUUFBWjtBQUNBO0FBQ0QsQ0FSRDtBQVVBVixPQUFPQyxLQUFQLENBQWEsUUFBYixFQUF1QixZQUFXO0FBQ2pDLE9BQUtTLE1BQUwsQ0FBWSxnQkFBWjs7QUFDQSxNQUFJaEQsT0FBTzRDLE1BQVAsTUFBbUJGLFNBQXZCLEVBQWtDO0FBQ2pDLFNBQUtNLE1BQUwsQ0FBWSxzQkFBWjtBQUNBO0FBQ0QsQ0FMRCxFOzs7Ozs7Ozs7OztBQy9GQSxJQUFJaEQsT0FBT0MsUUFBWCxFQUFxQjtBQUVuQjtBQUNBLE1BQUlpRSxNQUFNLElBQUlDLFFBQUosQ0FBYTtBQUNyQkMsb0JBQWdCLElBREs7QUFFckJDLGdCQUFZO0FBRlMsR0FBYixDQUFWLENBSG1CLENBUW5CO0FBQ0E7O0FBQ0FILE1BQUlJLGFBQUosQ0FBa0I3QyxPQUFsQjtBQUNBeUMsTUFBSUksYUFBSixDQUFrQjFDLFVBQWxCLEVBWG1CLENBYW5CO0FBQ0E7O0FBQ0FzQyxNQUFJSSxhQUFKLENBQWtCdEUsT0FBT0ksS0FBekIsRUFBZ0M7QUFDOUJtRSx1QkFBbUIsQ0FBQyxRQUFELEVBQVcsS0FBWCxDQURXO0FBRTlCQyxrQkFBYztBQUNaQyxvQkFBYztBQURGLEtBRmdCO0FBSzlCQyxlQUFXO0FBQ1RDLFlBQU07QUFDSkYsc0JBQWM7QUFEVixPQURHO0FBSVRHLGNBQVE7QUFDTkMsc0JBQWM7QUFEUjtBQUpDO0FBTG1CLEdBQWhDLEVBZm1CLENBOEJuQjs7QUFDQVgsTUFBSVksUUFBSixDQUFhLGNBQWIsRUFBNkI7QUFBQ0wsa0JBQWM7QUFBZixHQUE3QixFQUFtRDtBQUNqRFQsU0FBSyxZQUFZO0FBQ2YsYUFBT2UsU0FBUzFFLE9BQVQsQ0FBaUIsS0FBSzJFLFNBQUwsQ0FBZUMsRUFBaEMsQ0FBUDtBQUNELEtBSGdEO0FBSWpETCxZQUFRO0FBQ05DLG9CQUFjLENBQUMsUUFBRCxFQUFXLE9BQVgsQ0FEUjtBQUVOSyxjQUFRLFlBQVk7QUFDbEIsWUFBSUgsU0FBU0ksTUFBVCxDQUFnQixLQUFLSCxTQUFMLENBQWVDLEVBQS9CLENBQUosRUFBd0M7QUFDdEMsaUJBQU87QUFBQ0csb0JBQVEsU0FBVDtBQUFvQkMsa0JBQU07QUFBQ0MsdUJBQVM7QUFBVjtBQUExQixXQUFQO0FBQ0Q7O0FBQ0QsZUFBTztBQUNMQyxzQkFBWSxHQURQO0FBRUxDLGdCQUFNO0FBQUNKLG9CQUFRLE1BQVQ7QUFBaUJFLHFCQUFTO0FBQTFCO0FBRkQsU0FBUDtBQUlEO0FBVks7QUFKeUMsR0FBbkQ7QUFpQkQsQzs7Ozs7Ozs7Ozs7QUNoREQ7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUFHLE9BQU8sSUFBSUMsSUFBSixFQUFQO0FBRUExRixPQUFPaUMsT0FBUCxDQUFlLE1BQU07QUFFakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUg7QUFDQTtBQUNHO0FBRUEwRCxvQkFBa0IsTUFBbEI7QUFFQTNGLFNBQU80RixPQUFQLENBQWUsY0FBZixFQUErQixZQUFXO0FBQ3hDO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQSxRQUFJQyxTQUFTLEVBQWI7QUFFQSxXQUFPQyxVQUFVakQsSUFBVixDQUFlZ0QsTUFBZixFQUF1QjtBQUFFRSxjQUFRO0FBQUVDLGVBQU8sSUFBVDtBQUFlcEQsZ0JBQVEsSUFBdkI7QUFBNkJxRCxnQkFBUTtBQUFyQztBQUFWLEtBQXZCLENBQVA7QUFDRCxHQVZEO0FBYUFqRyxTQUFPRSxPQUFQLENBQWU7QUFDWGdHLGtCQUFjLFVBQVN6QyxLQUFULEVBQWdCMEMsSUFBaEIsRUFBc0JDLE9BQXRCLEVBQStCO0FBQ3pDM0UsY0FBUTRFLE1BQVIsQ0FBZTtBQUNYLG9CQUFZNUMsS0FERDtBQUVYLGdCQUFRMEMsSUFGRztBQUdYLG1CQUFXQyxPQUhBO0FBSVgscUJBQWMsSUFBSVYsSUFBSixFQUFELENBQWFZLE9BQWI7QUFKRixPQUFmO0FBTUEsYUFBT0gsSUFBUDtBQUNILEtBVFU7QUFXWEksaUJBQWEsVUFBUzlDLEtBQVQsRUFBZ0IwQyxJQUFoQixFQUFzQkssUUFBdEIsRUFBZ0NDLFVBQWhDLEVBQTRDQyxRQUE1QyxFQUFzRDtBQUMvRDFHLGFBQU9pQixJQUFQLENBQVksUUFBWixFQUFzQndDLEtBQXRCO0FBQ0E3QixpQkFBV3lFLE1BQVgsQ0FBa0I7QUFDZCxvQkFBYSxJQUFJWCxJQUFKLEVBQUQsQ0FBYVksT0FBYixFQURFO0FBRWQsZ0JBQVFILElBRk07QUFHZCxvQkFBWTFDLEtBSEU7QUFJZCwyQkFBbUIrQyxRQUpMO0FBS2Qsb0JBQVlFLFFBTEU7QUFNZCxzQkFBY0QsVUFOQTtBQU9kLGtCQUFVO0FBUEksT0FBbEI7QUFTQSxhQUFPLFFBQVA7QUFDSCxLQXZCVTtBQXlCWEUsbUJBQWUsVUFBVWxELEtBQVYsRUFBaUI7QUFDNUJoQyxjQUFRMEQsTUFBUixDQUFlO0FBQUMsb0JBQVkxQjtBQUFiLE9BQWY7QUFDQXpELGFBQU9pQixJQUFQLENBQVksUUFBWixFQUFzQndDLEtBQXRCO0FBQ0EsYUFBTyxjQUFQO0FBQ0gsS0E3QlU7QUErQlhtRCxZQUFRLFVBQVVuRCxLQUFWLEVBQWlCO0FBQ3JCN0IsaUJBQVdpRixNQUFYLENBQWtCO0FBQUMsb0JBQVlwRDtBQUFiLE9BQWxCLEVBQXVDO0FBQUNxRCxjQUFNO0FBQUMsb0JBQVUsS0FBWDtBQUFrQix3QkFBZSxJQUFJcEIsSUFBSixFQUFELENBQWFZLE9BQWI7QUFBaEM7QUFBUCxPQUF2QyxFQUF3RztBQUFDUyxlQUFPO0FBQVIsT0FBeEc7QUFDQSxhQUFPLElBQVA7QUFDSCxLQWxDVTtBQW9DWEMsaUJBQWEsWUFBWTtBQUNyQmxHLGNBQVFDLEdBQVIsQ0FBWSxVQUFaO0FBQ0FrRyxnQkFBVSxRQUFWLENBRnFCLENBR3JCOztBQUNBckYsaUJBQVdpQixJQUFYLENBQWdCO0FBQUNxRSxjQUFNLENBQUM7QUFBQyxzQkFBWTtBQUFDQyxpQkFBTyxJQUFJekIsSUFBSixFQUFELENBQWFZLE9BQWIsS0FBeUJXO0FBQWhDO0FBQWIsU0FBRCxFQUEwRDtBQUFDLG9CQUFVO0FBQVgsU0FBMUQ7QUFBUCxPQUFoQixFQUFxR0csT0FBckcsQ0FBNkcsVUFBVUMsR0FBVixFQUFlO0FBQ3hIckgsZUFBT2lCLElBQVAsQ0FBWSxRQUFaLEVBQXNCb0csSUFBSUMsUUFBMUI7QUFDQXhHLGdCQUFRQyxHQUFSLENBQVksaUJBQWlCc0csSUFBSUMsUUFBakM7QUFDSCxPQUhEO0FBSUgsS0E1Q1U7QUE4Q1hDLFVBQU0sVUFBVUMsR0FBVixFQUFlO0FBQ2pCMUcsY0FBUUMsR0FBUixDQUFZeUcsR0FBWjtBQUNILEtBaERVO0FBa0RYQyxxQkFBaUIsVUFBVUMsSUFBVixFQUFnQjtBQUM3QjtBQUNBLGFBQU8sSUFBUDtBQUNILEtBckRVO0FBdURYQyxpQkFBYSxVQUFVRCxJQUFWLEVBQWdCRSxRQUFoQixFQUEwQkMsTUFBMUIsRUFBa0M7QUFDM0M7QUFDSS9HLGNBQVFDLEdBQVIsQ0FBWSxvQkFBb0IyRyxJQUFwQixHQUEyQixHQUEzQixHQUFpQ0UsUUFBakMsR0FBNEMsR0FBNUMsR0FBa0RDLE1BQTlEO0FBQ0E3RixtQkFBYXFFLE1BQWIsQ0FBb0I7QUFDaEIsZ0JBQVFxQixJQURRO0FBRWhCLG9CQUFZRSxRQUZJO0FBR2hCLGtCQUFVQyxNQUhNO0FBSWhCLDBCQUFtQixJQUFJbkMsSUFBSixFQUFELENBQWFZLE9BQWIsRUFKRjtBQUtoQixvQkFBWTtBQUxJLE9BQXBCLEVBSHVDLENBVzNDO0FBQ0E7QUFDQTtBQUNBO0FBRUgsS0F2RVU7QUF5RVh3QixvQkFBZ0IsVUFBVUMsS0FBVixFQUFpQkMsUUFBakIsRUFBMkJDLFFBQTNCLEVBQXFDO0FBQ2pEQyxvQkFBYyxFQUFkO0FBQ0FDLGVBQVNyRyxZQUFZekIsT0FBWixDQUFvQjtBQUFDLGVBQU8ySDtBQUFSLE9BQXBCLENBQVQ7O0FBQ0EsVUFBSUcsVUFBVSxJQUFkLEVBQW9CO0FBQ2hCRCxzQkFBYztBQUFDLGtCQUFRQyxPQUFPQyxPQUFoQjtBQUF5QixrQkFBUUQsT0FBT0UsSUFBeEM7QUFBOEMsd0JBQWNGLE9BQU9wRztBQUFuRSxTQUFkO0FBQ0g7O0FBQ0RDLG1CQUFhNkUsTUFBYixDQUNJO0FBQUUsZUFBT2tCO0FBQVQsT0FESixFQUVJO0FBQUNqQixjQUFLO0FBQ0Ysc0JBQVksSUFEVjtBQUVGLHNCQUFZa0IsUUFGVjtBQUdGLDJCQUFpQkUsV0FIZjtBQUlGLHNCQUFZRDtBQUpWO0FBQU4sT0FGSjtBQVNILEtBeEZVO0FBMEZYSyxpQkFBYSxVQUFVWixJQUFWLEVBQWdCRSxRQUFoQixFQUEwQlcsT0FBMUIsRUFBbUM7QUFDNUN4RyxpQkFBVzhFLE1BQVgsQ0FBa0I7QUFDZEssY0FBSyxDQUNEO0FBQUMsa0JBQVFRO0FBQVQsU0FEQyxFQUVEO0FBQUMsc0JBQVlFO0FBQWIsU0FGQztBQURTLE9BQWxCLEVBS0c7QUFDQyxnQkFBUUYsSUFEVDtBQUVDLG9CQUFZRSxRQUZiO0FBR0MsbUJBQVdXO0FBSFosT0FMSCxFQVNHO0FBQ0NDLGdCQUFRO0FBRFQsT0FUSDtBQVlILEtBdkdVO0FBeUdYQyxrQkFBYyxVQUFVZixJQUFWLEVBQWdCVyxJQUFoQixFQUFzQkQsT0FBdEIsRUFBK0JyRyxVQUEvQixFQUEyQzJHLFVBQTNDLEVBQXVEO0FBQ2pFLFVBQUlBLGNBQWMsS0FBbEIsRUFBeUI7QUFDckI1RyxvQkFBWStFLE1BQVosQ0FBbUI7QUFDZkssZ0JBQ0ksQ0FBQztBQUFDLG9CQUFRUTtBQUFULFdBQUQsRUFDQTtBQUFDLG9CQUFRVztBQUFULFdBREEsRUFFQTtBQUFDLHVCQUFXRDtBQUFaLFdBRkE7QUFGVyxTQUFuQixFQUtHO0FBQ0N0QixnQkFBTTtBQUFDLDBCQUFjO0FBQWY7QUFEUCxTQUxIO0FBUUgsT0FURCxNQVVLO0FBQ0RoRixvQkFBWStFLE1BQVosQ0FBbUI7QUFDZkssZ0JBQ0ksQ0FBQztBQUFDLG9CQUFRUTtBQUFULFdBQUQsRUFDQTtBQUFDLG9CQUFRVztBQUFULFdBREEsRUFFQTtBQUFDLHVCQUFXRDtBQUFaLFdBRkE7QUFGVyxTQUFuQixFQUtHO0FBQ0Msa0JBQVFWLElBRFQ7QUFFQyxrQkFBUVcsSUFGVDtBQUdDLHFCQUFXRCxPQUhaO0FBSUMsd0JBQWNyRyxVQUpmO0FBS0Msd0JBQWM7QUFMZixTQUxILEVBV0c7QUFDQ3lHLGtCQUFRO0FBRFQsU0FYSDtBQWNILE9BMUJnRSxDQTJCakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTFHLGtCQUFZK0UsTUFBWixDQUFtQjtBQUFDSyxjQUFNLENBQUM7QUFBQyxrQkFBUVE7QUFBVCxTQUFELEVBQWlCO0FBQUMsa0JBQVE7QUFBVCxTQUFqQjtBQUFQLE9BQW5CLEVBQWtFO0FBQUNpQixtQkFBVztBQUFDLDJCQUFpQk47QUFBbEI7QUFBWixPQUFsRTtBQUNBdkcsa0JBQVkrRSxNQUFaLENBQW1CO0FBQUNLLGNBQU0sQ0FBQztBQUFDLGtCQUFRUTtBQUFULFNBQUQsRUFBaUI7QUFBQyxrQkFBUTtBQUFULFNBQWpCO0FBQVAsT0FBbkIsRUFBa0U7QUFBQ2lCLG1CQUFXO0FBQUMsMEJBQWdCTjtBQUFqQjtBQUFaLE9BQWxFO0FBRUgsS0FuSlU7QUFxSlg7QUFFQU8scUJBQWlCLFVBQVVDLEdBQVYsRUFBZUMsTUFBZixFQUF1QjtBQUNwQ2hJLGNBQVFDLEdBQVIsQ0FBWStILE1BQVo7O0FBQ0EsVUFBSUEsT0FBTy9GLE1BQVAsSUFBaUIsQ0FBckIsRUFBdUI7QUFDbkJqQyxnQkFBUUMsR0FBUixDQUFZLG9CQUFaLEVBRG1CLENBRW5COztBQUNBZSxvQkFBWXVFLE1BQVosQ0FBbUI7QUFBQyxrQkFBUXdDLEdBQVQ7QUFBYyxrQkFBUSxTQUF0QjtBQUFpQywwQkFBZ0JDLE1BQWpEO0FBQXlELDJCQUFpQjtBQUExRSxTQUFuQjtBQUNILE9BSkQsTUFLSyxJQUFJQSxPQUFPL0YsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUN4QmpCLG9CQUFZK0UsTUFBWixDQUFtQjtBQUFDSyxnQkFBTSxDQUFDO0FBQUMsb0JBQVEyQjtBQUFULFdBQUQsRUFBZ0I7QUFBQyxvQkFBUTtBQUFULFdBQWhCO0FBQVAsU0FBbkIsRUFBaUU7QUFBQy9CLGdCQUFNO0FBQUMsNEJBQWdCZ0M7QUFBakI7QUFBUCxTQUFqRTtBQUNIO0FBQ0osS0FqS1U7QUFtS1hDLHFCQUFpQixVQUFVRixHQUFWLEVBQWVHLE1BQWYsRUFBdUJDLE1BQXZCLEVBQStCO0FBQzVDcEgsb0JBQWNnRixNQUFkLENBQ0k7QUFBQyxrQkFBVWdDLEdBQVg7QUFBZ0Isb0JBQVk7QUFBNUIsT0FESixFQUVJO0FBQUMsa0JBQVVBLEdBQVg7QUFBZ0Isb0JBQVksUUFBNUI7QUFBc0MsbUJBQVdHO0FBQWpELE9BRkosRUFHSTtBQUNBO0FBQUNSLGdCQUFRLElBQVQ7QUFBZXpCLGVBQU07QUFBckIsT0FKSjtBQU1BakcsY0FBUUMsR0FBUixDQUFZaUksU0FBUyxHQUFULEdBQWVILEdBQTNCO0FBQ0FoSCxvQkFBY2dGLE1BQWQsQ0FDSTtBQUFDLGtCQUFVZ0MsR0FBWDtBQUFnQixvQkFBWTtBQUE1QixPQURKLEVBRUk7QUFBQyxrQkFBVUEsR0FBWDtBQUFnQixvQkFBWSxRQUE1QjtBQUFzQyxtQkFBV0k7QUFBakQsT0FGSixFQUdJO0FBQUNULGdCQUFRLElBQVQ7QUFBZXpCLGVBQU07QUFBckIsT0FISjtBQU1IO0FBakxVLEdBQWYsRUEvQmlCLENBbU5qQjtBQUNBO0FBQ0E7QUFDQTtBQUNILENBdk5EO0FBME5BL0csT0FBTzRGLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFNBQVNzRCxnQkFBVCxHQUE0QjtBQUNsRCxTQUFPekgsUUFBUW9CLElBQVIsRUFBUDtBQUNILENBRkQ7QUFJQXNHLFNBQVNDLFlBQVQsQ0FBc0IsVUFBVUMsT0FBVixFQUFtQjFHLElBQW5CLEVBQXlCO0FBQzNDO0FBQ0E7QUFDQTdCLFVBQVFDLEdBQVIsQ0FBWTRCLEtBQUtwQyxHQUFqQixFQUgyQyxDQUkzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQVAsU0FBT2lCLElBQVAsQ0FBWSxpQkFBWixFQUErQjBCLEtBQUtwQyxHQUFwQyxFQUF5Q29DLEtBQUtwQyxHQUE5QyxFQUFtRG9DLEtBQUtwQyxHQUF4RDtBQUNBUCxTQUFPaUIsSUFBUCxDQUFZLGlCQUFaLEVBQStCMEIsS0FBS3BDLEdBQXBDLEVBQXlDLEVBQXpDLEVBdkIyQyxDQXdCM0M7O0FBQ0EsU0FBT29DLElBQVA7QUFDSCxDQTFCRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJBY2NvdW50c1RlbXBsYXRlcy5jb25maWd1cmUoe1xuXHRjb25maXJtUGFzc3dvcmQ6IGZhbHNlLFxuICAgIG92ZXJyaWRlTG9naW5FcnJvcnM6IGZhbHNlLFxuICAgIGxvd2VyY2FzZVVzZXJuYW1lOiB0cnVlLFxuICAgIHNob3dGb3Jnb3RQYXNzd29yZExpbms6IHRydWUsXG4gICAgaG9tZVJvdXRlUGF0aDogJy8nXG59KTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcil7XG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgICAgICBcInVzZXJFeGlzdHNcIjogZnVuY3Rpb24odXNlcm5hbWUpe1xuICAgICAgICAgICAgcmV0dXJuICEhTWV0ZW9yLnVzZXJzLmZpbmRPbmUoe3VzZXJuYW1lOiB1c2VybmFtZX0pO1xuICAgICAgICB9LFxuICAgIH0pO1xufVxuXG5BY2NvdW50c1RlbXBsYXRlcy5hZGRGaWVsZCh7XG4gICAgX2lkOiAndXNlcm5hbWUnLFxuICAgIHR5cGU6ICd0ZXh0JyxcbiAgICBkaXNwbGF5TmFtZTogXCJMb2NhdGlvblwiLFxuICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgIGZ1bmM6IGZ1bmN0aW9uKHZhbHVlKXtcbiAgICAgICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0aW5nIGxvY2F0aW9uLi4uXCIpO1xuICAgICAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICAgICAgTWV0ZW9yLmNhbGwoXCJ1c2VyRXhpc3RzXCIsIHZhbHVlLCBmdW5jdGlvbihlcnIsIHVzZXJFeGlzdHMpe1xuICAgICAgICAgICAgICAgIGlmICghdXNlckV4aXN0cylcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5zZXRTdWNjZXNzKCk7XG4gICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICBzZWxmLnNldEVycm9yKHVzZXJFeGlzdHMpO1xuICAgICAgICAgICAgICAgIHNlbGYuc2V0VmFsaWRhdGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBTZXJ2ZXJcbiAgICAgICAgcmV0dXJuIE1ldGVvci5jYWxsKFwidXNlckV4aXN0c1wiLCB2YWx1ZSk7XG4gICAgfSxcbn0pO1xuXG5BY2NvdW50c1RlbXBsYXRlcy5jb25maWd1cmVSb3V0ZSgnc2lnbkluJywge1xuICByZWRpcmVjdDogJy8nLFxufSk7XG5cbkFjY291bnRzVGVtcGxhdGVzLmNvbmZpZ3VyZVJvdXRlKCdzaWduVXAnLCB7XG4gIHJlZGlyZWN0OiAnLycsXG59KTsiLCIvLyBpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbi8vIGlmIChNZXRlb3IuaXNTZXJ2ZXIpe1xuLy8gXHRkYiA9IG5ldyBNb25nb0ludGVybmFscy5SZW1vdGVDb2xsZWN0aW9uRHJpdmVyKFwibW9uZ29kYjovL1wiICsgbW9uZ29fdXNlciArIFwiOlwiICsgbW9uZ29fcGFzcyArIFwiQFwiICsgIG1vbmdvX2lwICsgXCI6MjcwMTcvY3NwYWNlXCIpO1xuLy8gfVxuLy8gbWVtYmVycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwibWVtYmVyc1wiLCB7X2RyaXZlcjogZGJ9KTtcbm1lbWJlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcIm1lbWJlcnNcIik7XG4vLyBjb25zb2xlLmxvZyhtZW1iZXJzLmZpbmRPbmUoKSk7XG5hY3Rpdml0aWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJhY3Rpdml0aWVzXCIpO1xuXG5kaXNwbGF5U3BhY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJkaXNwbGF5U3BhY2VzXCIpO1xuXG4vLyBwcmVzZW5jZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInByZXNlbmNlc1wiKTtcblxuc21hbGxHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInNtYWxsR3JvdXBzXCIpO1xuXG5hZmZpbml0aWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJhZmZpbml0aWVzXCIpO1xuXG5oZWxwUmVxdWVzdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcImhlbHBSZXF1ZXN0c1wiKTtcbiIsIk1ldGVvci5zdGFydHVwKCgpID0+IHtcblx0Ly8gY29uc29sZS5sb2cocHJvY2Vzcy5lbnYuTU9OR09fVVJMKTtcblx0Ly8gZXhwb3J0IE1PTkdPX1VSTCA9IFwibW9uZ29kYjovL1wiICsgbW9uZ29fdXNlciArIFwiOlwiICsgbW9uZ29fcGFzcyArIFwiQFwiICsgIG1vbmdvX2lwICsgXCI6MjcwMTcvY3NwYWNlXCI7XG5cdC8vIHByb2Nlc3MuZW52Lk1PTkdPX1VSTCA9IFwibW9uZ29kYjovL1wiICsgbW9uZ29fdXNlciArIFwiOlwiICsgbW9uZ29fcGFzcyArIFwiQFwiICsgIG1vbmdvX2lwICsgXCI6MjcwMTcvY3NwYWNlXCI7XG59KTtcblxuLy8gcmVzdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInJlc3RhdXJhbnRzXCIpO1xuLy8gY29uc29sZS5sb2coXCJtb25nb2RiOi8vXCIgKyBtb25nb191c2VyICsgXCI6XCIgKyBtb25nb19wYXNzICsgXCJAXCIgKyAgbW9uZ29faXAgKyBcIjoyNzAxNy9jc3BhY2VcIik7XG4iLCJtb25nb191c2VyID0gXCJtZXRlb3JSZWFkZXJcIlxubW9uZ29fcGFzcyA9IFwiYm90dGxlLXBsb3QtZ3JhbmdlLWNvY2hsZWFcIlxubW9uZ29faXAgPSBcIjUyLjQxLjI0LjIyNFwiXG5cbnBlZXJLZXkgPSBcInJ3Y3dvbG9uYnc4aHlxZnJcIlxuXG4iLCJSb3V0ZXIucm91dGUoJy8nLCBmdW5jdGlvbigpIHtcblx0U2Vzc2lvbi5zZXQoXCJNZW1iZXJcIiwgXCIwXCIpO1xuXHRTZXNzaW9uLnNldChcIk5hbWVcIiwgdW5kZWZpbmVkKTtcblx0U2Vzc2lvbi5zZXQoXCJVc2VyXCIsIE1ldGVvci51c2VyKCkpO1xuXHRpZihNZXRlb3IudXNlcklkKCkgIT0gdW5kZWZpbmVkICYmIHNtYWxsR3JvdXBzLmZpbmQoKS5mZXRjaCgpLmxlbmd0aCA+IDApIHtcblx0XHQvLyBjb25zb2xlLmxvZyhzbWFsbEdyb3Vwcy5maW5kKCkuZmV0Y2goKSk7XG5cdFx0dGhpcy5yZW5kZXIoJ2hvbWUnKTtcblx0fVxuXHRlbHNle1xuXHRcdHRoaXMucmVuZGVyKCdsb2FkaW5nJyk7XG5cdH1cblx0Y29uc29sZS5sb2coXCJob21lXCIpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL2Fza0hlbHAnLCBmdW5jdGlvbigpIHtcblx0aWYgKE1ldGVvci51c2VySWQoKSAhPSB1bmRlZmluZWQpe1xuXHRcdHRoaXMucmVuZGVyKFwiYXNrSGVscFwiKTtcblx0fVxuXHRlbHNle1xuXHRcdHRoaXMucmVuZGVyKFwibG9hZGluZ1wiKTtcblx0fVxufSk7XG5cblJvdXRlci5yb3V0ZSgnL2Fza0hlbHAvOnJvb21OYW1lJywgZnVuY3Rpb24oKSB7XG5cdHZhciBhbGxSb29tcyA9IFtcIm1hbGRlbmVuZ2dcIiwgXCJtYWxkZW5kZXNpZ25cIl07XG5cdHZhciByTmFtZSA9IFN0cmluZyh0aGlzLnBhcmFtcy5yb29tTmFtZSkudG9Mb3dlckNhc2UoKTtcblx0cm9vbVVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7XCJ1c2VybmFtZVwiOiByTmFtZX0pO1xuXHRyb29tSUQgPSBudWxsO1xuXHRpZiAocm9vbVVzZXIgIT0gbnVsbCkge1xuXHRcdHJvb21JRCA9IHJvb21Vc2VyLl9pZDtcblx0fVxuXHRcblx0aWYgKHJvb21JRCAhPSBudWxsKSB7XG5cdFx0U2Vzc2lvbi5zZXQoXCJoZWxwUm9vbVwiLCByb29tSUQpO1xuXHRcdHRoaXMucmVuZGVyKFwiYXNrSGVscFwiKTtcblx0fVxuXHRlbHNlIHtcblx0XHRTZXNzaW9uLnNldChcImhlbHBSb29tXCIsIG51bGwpO1xuXHRcdHRoaXMucmVuZGVyKFwibG9hZGluZ1wiKTtcblx0fVxufSk7XG5cblJvdXRlci5yb3V0ZSgnL21lbWJlci86bWVtaWQnLCBmdW5jdGlvbiAoKSB7XG5cdHZhciBtZW1JZCA9IFN0cmluZyh0aGlzLnBhcmFtcy5tZW1pZCk7XG5cdFNlc3Npb24uc2V0KFwiTWVtYmVyXCIsIG1lbUlkKTtcblx0dGhpcy5zdWJzY3JpYmUoJ21lbWJlcnMnLCB0aGlzLnBhcmFtcy5tZW1JZCkud2FpdCgpO1xuXHRjb25zb2xlLmxvZyh0aGlzLnJlYWR5KCkpO1xuXHRpZiAodGhpcy5yZWFkeSgpKXtcblx0XHRSb3V0ZXIuZ28oJy9tZW1iZXJDaGVjaycpO1xuXHR9XG5cdGVsc2V7XG5cdFx0dGhpcy5yZW5kZXIoXCJsb2FkaW5nXCIpO1xuXHRcdHRoaXMubmV4dCgpO1xuXHR9XG59KTtcblxuUm91dGVyLnJvdXRlKCcvbWVtYmVyQ2hlY2snLCBmdW5jdGlvbiAoKSB7XG5cdG1lbUlkID0gU2Vzc2lvbi5nZXQoXCJNZW1iZXJcIik7XG5cdGNvbnNvbGUubG9nKG1lbWJlcnMuZmluZE9uZSgpKTtcblx0aWYgKG1lbWJlcnMuZmluZE9uZSh7XCJNZW1iZXJJRFwiOiBtZW1JZH0pICE9IHVuZGVmaW5lZCl7XG5cdFx0Um91dGVyLmdvKCcvYWN0aXRvdXQnKTtcblx0fVxuXHRlbHNlIHtcblx0XHRSb3V0ZXIuZ28oJy9uZXdNZW1iZXInKTtcblx0fVxufSlcblxuXG5Sb3V0ZXIucm91dGUoJy9zZXRMb2NhdGlvbi8nLCBmdW5jdGlvbiAoKSB7XG5cdHRoaXMucmVuZGVyKFwibG9jYXRpb25SZWdpc3RyYXRpb25cIik7XG5cdGlmKE1ldGVvci51c2VySWQoKSAhPSB1bmRlZmluZWQpIHtcblx0XHR0aGlzLnJlbmRlcihcImxvY2F0aW9uU2V0dGluZ3NcIik7XG5cdH1cbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9hY3RpdG91dCcsIGZ1bmN0aW9uICgpIHtcblx0aWYoU2Vzc2lvbi5nZXQoXCJNZW1iZXJcIikgPT0gXCIwXCIgfHwgU2Vzc2lvbi5nZXQoXCJNZW1iZXJcIikgPT0gdW5kZWZpbmVkKXtcblx0XHRhbGVydChcIllvdSBoYXZlbid0IHRhcHBlZCBhIGNhcmQhXCIpO1xuXHRcdFJvdXRlci5nbygnLycpO1xuXHR9XG5cdGVsc2Uge1xuXHRcdHRoaXMucmVuZGVyKCdhY3Rpdml0eUVudHJ5Jyk7XG5cdH1cbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9uZXdNZW1iZXInLCBmdW5jdGlvbigpIHtcblx0aWYoU2Vzc2lvbi5nZXQoXCJNZW1iZXJcIikgPT0gXCIwXCIgfHwgU2Vzc2lvbi5nZXQoXCJNZW1iZXJcIikgPT0gdW5kZWZpbmVkKXtcblx0XHRhbGVydChcIllvdSBoYXZlbid0IHRhcHBlZCBhIGNhcmQhXCIpO1xuXHRcdFJvdXRlci5nbygnLycpO1x0XHRcblx0fVxuXHRlbHNlIHtcblx0XHR0aGlzLnJlbmRlcignc2lnblVwJyk7XG5cdH1cbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9hZG1pbicsIGZ1bmN0aW9uKCkge1xuXHR0aGlzLnJlbmRlcihcImFkbWluaXN0cmF0aW9uXCIpO1xuXHRpZiAoTWV0ZW9yLnVzZXJJZCgpID09IHVuZGVmaW5lZCkge1xuXHRcdHRoaXMucmVuZGVyKFwibG9jYXRpb25SZWdpc3RyYXRpb25cIik7XG5cdH1cbn0pOyIsImlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuICAvLyBHbG9iYWwgQVBJIGNvbmZpZ3VyYXRpb25cbiAgdmFyIEFwaSA9IG5ldyBSZXN0aXZ1cyh7XG4gICAgdXNlRGVmYXVsdEF1dGg6IHRydWUsXG4gICAgcHJldHR5SnNvbjogdHJ1ZVxuICB9KTtcblxuICAvLyBHZW5lcmF0ZXM6IEdFVCwgUE9TVCBvbiAvYXBpL2l0ZW1zIGFuZCBHRVQsIFBVVCwgUEFUQ0gsIERFTEVURSBvblxuICAvLyAvYXBpL2l0ZW1zLzppZCBmb3IgdGhlIEl0ZW1zIGNvbGxlY3Rpb25cbiAgQXBpLmFkZENvbGxlY3Rpb24obWVtYmVycyk7XG4gIEFwaS5hZGRDb2xsZWN0aW9uKGFjdGl2aXRpZXMpO1xuXG4gIC8vIEdlbmVyYXRlczogUE9TVCBvbiAvYXBpL3VzZXJzIGFuZCBHRVQsIERFTEVURSAvYXBpL3VzZXJzLzppZCBmb3JcbiAgLy8gTWV0ZW9yLnVzZXJzIGNvbGxlY3Rpb25cbiAgQXBpLmFkZENvbGxlY3Rpb24oTWV0ZW9yLnVzZXJzLCB7XG4gICAgZXhjbHVkZWRFbmRwb2ludHM6IFsnZ2V0QWxsJywgJ3B1dCddLFxuICAgIHJvdXRlT3B0aW9uczoge1xuICAgICAgYXV0aFJlcXVpcmVkOiB0cnVlXG4gICAgfSxcbiAgICBlbmRwb2ludHM6IHtcbiAgICAgIHBvc3Q6IHtcbiAgICAgICAgYXV0aFJlcXVpcmVkOiBmYWxzZVxuICAgICAgfSxcbiAgICAgIGRlbGV0ZToge1xuICAgICAgICByb2xlUmVxdWlyZWQ6ICdhZG1pbidcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gIC8vIE1hcHMgdG86IC9hcGkvYXJ0aWNsZXMvOmlkXG4gIEFwaS5hZGRSb3V0ZSgnYXJ0aWNsZXMvOmlkJywge2F1dGhSZXF1aXJlZDogdHJ1ZX0sIHtcbiAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBBcnRpY2xlcy5maW5kT25lKHRoaXMudXJsUGFyYW1zLmlkKTtcbiAgICB9LFxuICAgIGRlbGV0ZToge1xuICAgICAgcm9sZVJlcXVpcmVkOiBbJ2F1dGhvcicsICdhZG1pbiddLFxuICAgICAgYWN0aW9uOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmIChBcnRpY2xlcy5yZW1vdmUodGhpcy51cmxQYXJhbXMuaWQpKSB7XG4gICAgICAgICAgcmV0dXJuIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YToge21lc3NhZ2U6ICdBcnRpY2xlIHJlbW92ZWQnfX07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA0MDQsXG4gICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnQXJ0aWNsZSBub3QgZm91bmQnfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG59IiwiLy8gaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG4vLyBpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cblxuLy8gY29uc29sZS5sb2coXCJtb25nb2RiOi8vXCIgKyBtb25nb191c2VyICsgXCI6XCIgKyBtb25nb19wYXNzICsgXCJAXCIgKyAgbW9uZ29faXAgKyBcIjoyNzAxNy9jc3BhY2VcIik7XG4vLyBkYiA9IG5ldyBNb25nb0ludGVybmFscy5SZW1vdGVDb2xsZWN0aW9uRHJpdmVyKFwibW9uZ29kYjovL1wiICsgbW9uZ29fdXNlciArIFwiOlwiICsgbW9uZ29fcGFzcyArIFwiQFwiICsgIG1vbmdvX2lwICsgXCI6MjcwMTcvY3NwYWNlXCIpO1xuLy8gZXhwb3J0IGNvbnN0IG1lbWJlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcIm1lbWJlcnNcIiwge19kcml2ZXI6IGRifSk7XG4vLyBleHBvcnQgY29uc3QgYWN0aXZpdGllcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiYWN0aXZpdGllc1wiLCB7X2RyaXZlcjogZGJ9KTtcblxuZGF0ZSA9IG5ldyBEYXRlKCk7XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcblxuICAgIC8vIFNTTFByb3h5KHtcbiAgICAvLyAgICBwb3J0OiA2MDAwLCAvL29yIDQ0MyAobm9ybWFsIHBvcnQvcmVxdWlyZXMgc3VkbylcbiAgICAvLyAgICBzc2wgOiB7XG4gICAgLy8gICAgICAgICBrZXk6IEFzc2V0cy5nZXRUZXh0KFwic2VydmVyLmtleVwiKSxcbiAgICAvLyAgICAgICAgIGNlcnQ6IEFzc2V0cy5nZXRUZXh0KFwic2VydmVyLmNydFwiKSxcbiAgICAvLyAgICAgICAgIC8vT3B0aW9uYWwgQ0FcbiAgICAvLyAgICAgICAgIC8vQXNzZXRzLmdldFRleHQoXCJjYS5wZW1cIilcbiAgICAvLyAgICB9XG4gICAgLy8gfSk7XG5cblx0Ly8gY29uc29sZS5sb2cocmVzdHMuZmluZE9uZSh7fSkpO1xuXHQvLyBjb25zb2xlLmxvZyhtZW1iZXJzLmZpbmRPbmUoe30pKTtcbiAgICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxuXG4gICAgcmVxdWVzdER1cmF0aW9uID0gMzAwMDAwO1xuXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3VzZXJQcmVzZW5jZScsIGZ1bmN0aW9uKCkge1xuICAgICAgLy8gU2V0dXAgc29tZSBmaWx0ZXIgdG8gZmluZCB0aGUgdXNlcnMgeW91ciB1c2VyXG4gICAgICAvLyBjYXJlcyBhYm91dC4gSXQncyB1bmxpa2VseSB0aGF0IHlvdSB3YW50IHRvIHB1Ymxpc2ggdGhlIFxuICAgICAgLy8gcHJlc2VuY2VzIG9mIF9hbGxfIHRoZSB1c2VycyBpbiB0aGUgc3lzdGVtLlxuXG4gICAgICAvLyBJZiBmb3IgZXhhbXBsZSB3ZSB3YW50ZWQgdG8gcHVibGlzaCBvbmx5IGxvZ2dlZCBpbiB1c2VycyB3ZSBjb3VsZCBhcHBseTpcbiAgICAgIC8vIGZpbHRlciA9IHsgdXNlcklkOiB7ICRleGlzdHM6IHRydWUgfX07XG4gICAgICB2YXIgZmlsdGVyID0ge307IFxuXG4gICAgICByZXR1cm4gUHJlc2VuY2VzLmZpbmQoZmlsdGVyLCB7IGZpZWxkczogeyBzdGF0ZTogdHJ1ZSwgdXNlcklkOiB0cnVlLCBwZWVySUQ6IHRydWUgfX0pO1xuICAgIH0pO1xuXG5cbiAgICBNZXRlb3IubWV0aG9kcyh7XG4gICAgICAgIGNyZWF0ZU1lbWJlcjogZnVuY3Rpb24obWVtSWQsIG5hbWUsIHppcGNvZGUpIHtcbiAgICAgICAgICAgIG1lbWJlcnMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICBcIk1lbWJlcklEXCI6IG1lbUlkLFxuICAgICAgICAgICAgICAgIFwiTmFtZVwiOiBuYW1lLFxuICAgICAgICAgICAgICAgIFwiWmlwY29kZVwiOiB6aXBjb2RlLFxuICAgICAgICAgICAgICAgIFwiQ3JlYXRlZEF0XCI6IChuZXcgRGF0ZSgpKS5nZXRUaW1lKClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIG5hbWU7XG4gICAgICAgIH0sXG5cbiAgICAgICAgbG9nQWN0aXZpdHk6IGZ1bmN0aW9uKG1lbUlkLCBuYW1lLCBhY3Rpdml0eSwgbG9jYXRpb25JRCwgbG9jYXRpb24pIHtcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKFwibG9nT3V0XCIsIG1lbUlkKTtcbiAgICAgICAgICAgIGFjdGl2aXRpZXMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICBcIkxvZ2dlZEluXCI6IChuZXcgRGF0ZSgpKS5nZXRUaW1lKCksXG4gICAgICAgICAgICAgICAgXCJOYW1lXCI6IG5hbWUsXG4gICAgICAgICAgICAgICAgXCJNZW1iZXJJRFwiOiBtZW1JZCxcbiAgICAgICAgICAgICAgICBcIkN1cnJlbnRBY3Rpdml0eVwiOiBhY3Rpdml0eSxcbiAgICAgICAgICAgICAgICBcIkxvY2F0aW9uXCI6IGxvY2F0aW9uLFxuICAgICAgICAgICAgICAgIFwibG9jYXRpb25JRFwiOiBsb2NhdGlvbklELFxuICAgICAgICAgICAgICAgIFwiU3RhdHVzXCI6IFwiaW5cIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4gXCJsb2dnZWRcIjtcbiAgICAgICAgfSxcblxuICAgICAgICBjbGVhckNhcmRVc2VyOiBmdW5jdGlvbiAobWVtSWQpIHtcbiAgICAgICAgICAgIG1lbWJlcnMucmVtb3ZlKHtcIk1lbWJlcklEXCI6IG1lbUlkfSk7XG4gICAgICAgICAgICBNZXRlb3IuY2FsbChcImxvZ091dFwiLCBtZW1JZCk7XG4gICAgICAgICAgICByZXR1cm4gXCJDYXJkIGNsZWFyZWRcIjtcbiAgICAgICAgfSxcblxuICAgICAgICBsb2dPdXQ6IGZ1bmN0aW9uIChtZW1JZCkge1xuICAgICAgICAgICAgYWN0aXZpdGllcy51cGRhdGUoe1wiTWVtYmVySURcIjogbWVtSWR9LCB7JHNldDoge1wiU3RhdHVzXCI6IFwib3V0XCIsIFwiTG9nT3V0VGltZVwiOiAobmV3IERhdGUoKSkuZ2V0VGltZSgpfX0sIHttdWx0aTogdHJ1ZX0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG5cbiAgICAgICAgY2hlY2tMb2dpbnM6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY2hlY2tpbmdcIilcbiAgICAgICAgICAgIHRpbWVPdXQgPSAxODAwMDAwMDtcbiAgICAgICAgICAgIC8vIHRpbWVPdXQgPSA1MDAwO1xuICAgICAgICAgICAgYWN0aXZpdGllcy5maW5kKHskYW5kOiBbe1wiTG9nZ2VkSW5cIjogeyRsdDogKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCkgLSB0aW1lT3V0KX19LCB7XCJTdGF0dXNcIjogXCJpblwifV19KS5mb3JFYWNoKGZ1bmN0aW9uIChkb2MpIHtcbiAgICAgICAgICAgICAgICBNZXRlb3IuY2FsbChcImxvZ091dFwiLCBkb2MuTWVtYmVySUQpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibG9nZ2luZyBvdXQgXCIgKyBkb2MuTWVtYmVySUQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgdGVzdDogZnVuY3Rpb24gKHRleCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2codGV4KTtcbiAgICAgICAgfSxcblxuICAgICAgICBnZXRMaXZlUmVxdWVzdHM6IGZ1bmN0aW9uIChyb29tKSB7XG4gICAgICAgICAgICAvLyByZXR1cm4gaGVscFJlcXVlc3RzLmZpbmQoeyRhbmQ6IFt7XCJyb29tXCI6IE1ldGVvci51c2VySWQoKSwgXCJyZXF1ZXN0Q3JlYXRlZFwiOiB7JGd0OiBkYXRlLmdldFRpbWUoKSAtIDMwMDAwMH19XX0pO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVxdWVzdEhlbHA6IGZ1bmN0aW9uIChyb29tLCBhZmZpbml0eSwgaGVscGVlKSB7XG4gICAgICAgICAgICAvLyBpZiAoaGVscFJlcXVlc3RzLmZpbmQoeyRhbmQ6IFt7XCJyb29tXCI6IHJvb20sIFwiYWZmaW5pdHlcIjogYWZmaW5pdHksIFwiaGVscGVlXCI6IGhlbHBlZSwgXCJyZXF1ZXN0Q3JlYXRlZFwiOiB7JGd0OiBkYXRlLmdldFRpbWUoKSAtIHJlcXVlc3REdXJhdGlvbn19XX0pID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWRkaW5nIHJlcXVlc3QgXCIgKyByb29tICsgXCIgXCIgKyBhZmZpbml0eSArIFwiIFwiICsgaGVscGVlKTtcbiAgICAgICAgICAgICAgICBoZWxwUmVxdWVzdHMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgXCJyb29tXCI6IHJvb20sXG4gICAgICAgICAgICAgICAgICAgIFwiYWZmaW5pdHlcIjogYWZmaW5pdHksXG4gICAgICAgICAgICAgICAgICAgIFwiaGVscGVlXCI6IGhlbHBlZSxcbiAgICAgICAgICAgICAgICAgICAgXCJyZXF1ZXN0Q3JlYXRlZFwiOiAobmV3IERhdGUoKSkuZ2V0VGltZSgpLFxuICAgICAgICAgICAgICAgICAgICBcInJlc29sdmVkXCI6IGZhbHNlXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICAvLyBlbHNle1xuICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKFwibm90IGFkZGluZyByZXF1ZXN0XCIpO1xuICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgXG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVzb2x2ZVJlcXVlc3Q6IGZ1bmN0aW9uIChyZXFJZCwgaGVscGVySWQsIGNvbW1lbnRzKSB7XG4gICAgICAgICAgICBoZWxwZXJEZWV0cyA9IHt9O1xuICAgICAgICAgICAgaGVscGVyID0gc21hbGxHcm91cHMuZmluZE9uZSh7XCJfaWRcIjogaGVscGVySWR9KTtcbiAgICAgICAgICAgIGlmIChoZWxwZXIgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIGhlbHBlckRlZXRzID0ge1wibmFtZVwiOiBoZWxwZXIuc3R1ZGVudCwgXCJ0ZWFtXCI6IGhlbHBlci50ZWFtLCBcImFmZmluaXRpZXNcIjogaGVscGVyLmFmZmluaXRpZXN9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaGVscFJlcXVlc3RzLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IFwiX2lkXCI6IHJlcUlkIH0sXG4gICAgICAgICAgICAgICAgeyRzZXQ6e1xuICAgICAgICAgICAgICAgICAgICBcInJlc29sdmVkXCI6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIFwiaGVscGVySWRcIjogaGVscGVySWQsXG4gICAgICAgICAgICAgICAgICAgIFwiaGVscGVyRGV0YWlsc1wiOiBoZWxwZXJEZWV0cyxcbiAgICAgICAgICAgICAgICAgICAgXCJjb21tZW50c1wiOiBjb21tZW50c1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICApXG4gICAgICAgIH0sXG5cbiAgICAgICAgYWRkQWZmaW5pdHk6IGZ1bmN0aW9uIChyb29tLCBhZmZpbml0eSwgZmFjbGFzcykge1xuICAgICAgICAgICAgYWZmaW5pdGllcy51cGRhdGUoe1xuICAgICAgICAgICAgICAgICRhbmQ6W1xuICAgICAgICAgICAgICAgICAgICB7XCJyb29tXCI6IHJvb219LFxuICAgICAgICAgICAgICAgICAgICB7XCJhZmZpbml0eVwiOiBhZmZpbml0eX1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgXCJyb29tXCI6IHJvb20sXG4gICAgICAgICAgICAgICAgXCJhZmZpbml0eVwiOiBhZmZpbml0eSxcbiAgICAgICAgICAgICAgICBcImZhY2xhc3NcIjogZmFjbGFzc1xuICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgIHVwc2VydDogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgYWRkQm94UGVyc29uOiBmdW5jdGlvbiAocm9vbSwgdGVhbSwgc3R1ZGVudCwgYWZmaW5pdGllcywgdmlzaWJpbGl0eSkge1xuICAgICAgICAgICAgaWYgKHZpc2liaWxpdHkgPT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICBzbWFsbEdyb3Vwcy51cGRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAkYW5kOiBcbiAgICAgICAgICAgICAgICAgICAgICAgIFt7XCJyb29tXCI6IHJvb219LCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcInRlYW1cIjogdGVhbX0sIFxuICAgICAgICAgICAgICAgICAgICAgICAge1wic3R1ZGVudFwiOiBzdHVkZW50fV1cbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6IHtcInZpc2liaWxpdHlcIjogZmFsc2V9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNtYWxsR3JvdXBzLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICRhbmQ6IFxuICAgICAgICAgICAgICAgICAgICAgICAgW3tcInJvb21cIjogcm9vbX0sIFxuICAgICAgICAgICAgICAgICAgICAgICAge1widGVhbVwiOiB0ZWFtfSwgXG4gICAgICAgICAgICAgICAgICAgICAgICB7XCJzdHVkZW50XCI6IHN0dWRlbnR9XVxuICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgXCJyb29tXCI6IHJvb20sIFxuICAgICAgICAgICAgICAgICAgICBcInRlYW1cIjogdGVhbSwgXG4gICAgICAgICAgICAgICAgICAgIFwic3R1ZGVudFwiOiBzdHVkZW50LCBcbiAgICAgICAgICAgICAgICAgICAgXCJhZmZpbml0aWVzXCI6IGFmZmluaXRpZXMsXG4gICAgICAgICAgICAgICAgICAgIFwidmlzaWJpbGl0eVwiOiB0cnVlXG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICB1cHNlcnQ6IHRydWVcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIHNtYWxsR3JvdXBzLnVwZGF0ZShcbiAgICAgICAgICAgIC8vICAgICB7JGFuZDogW1xuICAgICAgICAgICAgLy8gICAgICAgICB7XCJyb29tXCI6IHJvb219LCBcbiAgICAgICAgICAgIC8vICAgICAgICAge1wiaW5mb1wiOiBcImJveExpc3RcIn1cbiAgICAgICAgICAgIC8vICAgICBdfSwgXG4gICAgICAgICAgICAvLyAgICAge1xuICAgICAgICAgICAgLy8gICAgICAgICBcInJvb21cIjogcm9vbSwgXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiaW5mb1wiOiBcImJveExpc3RcIiwgXG4gICAgICAgICAgICAvLyAgICAgICAgIC8vICRhZGRUb1NldDoge1widmlzaWJsZUJveGVzXCI6IHRlYW19XG4gICAgICAgICAgICAvLyAgICAgfSxcbiAgICAgICAgICAgIC8vICAgICB7dXBzZXJ0OiB0cnVlfVxuICAgICAgICAgICAgLy8gKTtcbiAgICAgICAgICAgIHNtYWxsR3JvdXBzLnVwZGF0ZSh7JGFuZDogW3tcInJvb21cIjogcm9vbX0sIHtcImluZm9cIjogXCJib3hMaXN0XCJ9XX0sIHskYWRkVG9TZXQ6IHtcImV4aXN0aW5nQm94ZXNcIjogdGVhbX19KTtcbiAgICAgICAgICAgIHNtYWxsR3JvdXBzLnVwZGF0ZSh7JGFuZDogW3tcInJvb21cIjogcm9vbX0sIHtcImluZm9cIjogXCJib3hMaXN0XCJ9XX0sIHskYWRkVG9TZXQ6IHtcInZpc2libGVCb3hlc1wiOiB0ZWFtfX0pO1xuXG4gICAgICAgIH0sXG5cbiAgICAgICAgLy8gdXBkYXRlVmlzaWJsZUJveGVzXG5cbiAgICAgICAgc2V0VmlzaWJsZUJveGVzOiBmdW5jdGlvbiAodWlkLCB2Ym94ZXMpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHZib3hlcyk7XG4gICAgICAgICAgICBpZiAodmJveGVzLmxlbmd0aCA9PSAwKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImZpbGxpbmcgc21hbGxHcm91cFwiKTtcbiAgICAgICAgICAgICAgICAvLyBzbWFsbEdyb3Vwcy51cGRhdGUoeyRhbmQ6IFt7XCJyb29tXCI6IHVpZH0sIHtcImluZm9cIjogXCJib3hMaXN0XCJ9XX0sIHtcInJvb21cIjogdWlkLCBcImluZm9cIjogXCJib3hMaXN0XCIsIFwidmlzaWJsZUJveGVzXCI6IHZib3hlc30sIHt1cHNlcnQ6IHRydWV9KTtcbiAgICAgICAgICAgICAgICBzbWFsbEdyb3Vwcy5pbnNlcnQoe1wicm9vbVwiOiB1aWQsIFwiaW5mb1wiOiBcImJveExpc3RcIiwgXCJ2aXNpYmxlQm94ZXNcIjogdmJveGVzLCBcImV4aXN0aW5nQm94ZXNcIjogW119KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHZib3hlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgc21hbGxHcm91cHMudXBkYXRlKHskYW5kOiBbe1wicm9vbVwiOiB1aWR9LCB7XCJpbmZvXCI6IFwiYm94TGlzdFwifV19LCB7JHNldDoge1widmlzaWJsZUJveGVzXCI6IHZib3hlc319KTsgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcblxuICAgICAgICBzZXREaXNwbGF5U3BhY2U6IGZ1bmN0aW9uICh1aWQsIHNwYWNlMSwgc3BhY2UyKSB7XG4gICAgICAgICAgICBkaXNwbGF5U3BhY2VzLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XCJyb29tSURcIjogdWlkLCBcImxvY2F0aW9uXCI6IFwic3BhY2UxXCJ9LFxuICAgICAgICAgICAgICAgIHtcInJvb21JRFwiOiB1aWQsIFwibG9jYXRpb25cIjogXCJzcGFjZTFcIiwgXCJzcGFjZUlEXCI6IHNwYWNlMX0sXG4gICAgICAgICAgICAgICAgLy8geyRzZXRPbkluc2VydDoge1wicm9vbUlEXCI6IHVpZCwgXCJsb2NhdGlvblwiOiBcInNwYWNlMVwifSB9LFxuICAgICAgICAgICAgICAgIHt1cHNlcnQ6IHRydWUsIG11bHRpOmZhbHNlfSBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhzcGFjZTEgKyBcIiBcIiArIHVpZCk7XG4gICAgICAgICAgICBkaXNwbGF5U3BhY2VzLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XCJyb29tSURcIjogdWlkLCBcImxvY2F0aW9uXCI6IFwic3BhY2UyXCJ9LFxuICAgICAgICAgICAgICAgIHtcInJvb21JRFwiOiB1aWQsIFwibG9jYXRpb25cIjogXCJzcGFjZTJcIiwgXCJzcGFjZUlEXCI6IHNwYWNlMn0sXG4gICAgICAgICAgICAgICAge3Vwc2VydDogdHJ1ZSwgbXVsdGk6ZmFsc2V9XG4gICAgICAgICAgICApO1xuXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbiAoKSB7XG4gICAgLy8gICAgIE1ldGVvci5jYWxsKCdjaGVja0xvZ2lucycpO1xuICAgIC8vIH0sIDMwMDAwMCk7XG4gICAgLy8gfSwgMTAwMCk7XG59KTtcblxuXG5NZXRlb3IucHVibGlzaCgnbWVtYmVycycsIGZ1bmN0aW9uIHRhc2tzUHVibGljYXRpb24oKSB7XG4gICAgcmV0dXJuIG1lbWJlcnMuZmluZCgpO1xufSk7XG5cbkFjY291bnRzLm9uQ3JlYXRlVXNlcihmdW5jdGlvbiAob3B0aW9ucywgdXNlcikge1xuICAgIC8vIHNwYWNlMSA9IHVzZXIuX2lkO1xuICAgIC8vIGNvbnNvbGUubG9nKE1ldGVvci51c2Vycyk7XG4gICAgY29uc29sZS5sb2codXNlci5faWQpOyBcbiAgICAvLyBzcGFjZTIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSgpLl9pZDtcbiAgICAvLyBkaXNwbGF5U3BhY2VzLnVwZGF0ZSh7XG4gICAgLy8gICAgICRhbmQ6IFt7XCJyb29tSURcIjogdXNlci5faWR9LCB7XCJsb2NhdGlvblwiOiBcInNwYWNlMVwifV1cbiAgICAvLyB9LFxuICAgIC8vIHskc2V0OiB7JFwic3BhY2VJRFwiOiBzcGFjZTF9IH0sXG4gICAgLy8gLy8geyRzZXRPbkluc2VydDoge1wicm9vbUlEXCI6IHVpZCwgXCJsb2NhdGlvblwiOiBcInNwYWNlMVwifSB9LFxuICAgIC8vIHt1cHNlcnQ6IHRydWV9ICk7XG4gICAgXG4gICAgLy8gZGlzcGxheVNwYWNlcy51cGRhdGUoXG4gICAgLy8gICAgIHskYW5kOiBbXG4gICAgLy8gICAgICAgICB7XCJyb29tSURcIjogdXNlci5faWR9LCBcbiAgICAvLyAgICAgICAgIHtcImxvY2F0aW9uXCI6IFwic3BhY2UyXCJ9XG4gICAgLy8gICAgIF19LFxuICAgIC8vICAgICB7JHNldDogeyRcInNwYWNlSURcIjogc3BhY2UyfSB9LFxuICAgIC8vIC8vIHskc2V0T25JbnNlcnQ6IHtcInJvb21JRFwiOiB1aWQsIFwibG9jYXRpb25cIjogXCJzcGFjZTFcIn0gfSxcbiAgICAvLyAgICAge3Vwc2VydDogdHJ1ZX1cbiAgICAvLyApO1xuXG4gICAgTWV0ZW9yLmNhbGwoXCJzZXREaXNwbGF5U3BhY2VcIiwgdXNlci5faWQsIHVzZXIuX2lkLCB1c2VyLl9pZCk7XG4gICAgTWV0ZW9yLmNhbGwoXCJzZXRWaXNpYmxlQm94ZXNcIiwgdXNlci5faWQsIFtdKTtcbiAgICAvLyBzbWFsbEdyb3Vwcy51cGRhdGUoeyRhbmQ6IFt7XCJyb29tXCI6IHJvb219LCB7XCJpbmZvXCI6IFwiYm94TGlzdFwifV19XG4gICAgcmV0dXJuIHVzZXI7XG59KTsiXX0=
