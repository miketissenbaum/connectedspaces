(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;
var RestMiddleware = Package['simple:json-routes'].RestMiddleware;
var Accounts = Package['accounts-base'].Accounts;

/* Package-scope variables */
var __coffeescriptShare, ironRouterSendErrorToResponse, msg, Restivus;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble_restivus/lib/auth.coffee.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var getUserQuerySelector, userValidator;

this.Auth || (this.Auth = {});


/*
  A valid user will have exactly one of the following identification fields: id, username, or email
 */

userValidator = Match.Where(function(user) {
  check(user, {
    id: Match.Optional(String),
    username: Match.Optional(String),
    email: Match.Optional(String)
  });
  if (_.keys(user).length === !1) {
    throw new Match.Error('User must have exactly one identifier field');
  }
  return true;
});


/*
  Return a MongoDB query selector for finding the given user
 */

getUserQuerySelector = function(user) {
  if (user.id) {
    return {
      '_id': user.id
    };
  } else if (user.username) {
    return {
      'username': user.username
    };
  } else if (user.email) {
    return {
      'emails.address': user.email
    };
  }
  throw new Error('Cannot create selector from invalid user');
};


/*
  Log a user in with their password
 */

this.Auth.loginWithPassword = function(user, password) {
  var authToken, authenticatingUser, authenticatingUserSelector, hashedToken, passwordVerification, ref;
  if (!user || !password) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  check(user, userValidator);
  check(password, String);
  authenticatingUserSelector = getUserQuerySelector(user);
  authenticatingUser = Meteor.users.findOne(authenticatingUserSelector);
  if (!authenticatingUser) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  if (!((ref = authenticatingUser.services) != null ? ref.password : void 0)) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  passwordVerification = Accounts._checkPassword(authenticatingUser, password);
  if (passwordVerification.error) {
    throw new Meteor.Error(401, 'Unauthorized');
  }
  authToken = Accounts._generateStampedLoginToken();
  hashedToken = Accounts._hashLoginToken(authToken.token);
  Accounts._insertHashedLoginToken(authenticatingUser._id, {
    hashedToken: hashedToken
  });
  return {
    authToken: authToken.token,
    userId: authenticatingUser._id
  };
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble_restivus/lib/iron-router-error-to-response.js                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// We need a function that treats thrown errors exactly like Iron Router would.
// This file is written in JavaScript to enable copy-pasting Iron Router code.

// Taken from: https://github.com/iron-meteor/iron-router/blob/9c369499c98af9fd12ef9e68338dee3b1b1276aa/lib/router_server.js#L3
var env = process.env.NODE_ENV || 'development';

// Taken from: https://github.com/iron-meteor/iron-router/blob/9c369499c98af9fd12ef9e68338dee3b1b1276aa/lib/router_server.js#L47
ironRouterSendErrorToResponse = function (err, req, res) {
  if (res.statusCode < 400)
    res.statusCode = 500;

  if (err.status)
    res.statusCode = err.status;

  if (env === 'development')
    msg = (err.stack || err.toString()) + '\n';
  else
    //XXX get this from standard dict of error messages?
    msg = 'Server error.';

  console.error(err.stack || err.toString());

  if (res.headersSent)
    return req.socket.destroy();

  res.setHeader('Content-Type', 'text/html');
  res.setHeader('Content-Length', Buffer.byteLength(msg));
  if (req.method === 'HEAD')
    return res.end();
  res.end(msg);
  return;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble_restivus/lib/route.coffee.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.Route = (function() {
  function Route(api, path, options, endpoints1) {
    this.api = api;
    this.path = path;
    this.options = options;
    this.endpoints = endpoints1;
    if (!this.endpoints) {
      this.endpoints = this.options;
      this.options = {};
    }
  }

  Route.prototype.addToApi = (function() {
    var availableMethods;
    availableMethods = ['get', 'post', 'put', 'patch', 'delete', 'options'];
    return function() {
      var allowedMethods, fullPath, rejectedMethods, self;
      self = this;
      if (_.contains(this.api._config.paths, this.path)) {
        throw new Error("Cannot add a route at an existing path: " + this.path);
      }
      this.endpoints = _.extend({
        options: this.api._config.defaultOptionsEndpoint
      }, this.endpoints);
      this._resolveEndpoints();
      this._configureEndpoints();
      this.api._config.paths.push(this.path);
      allowedMethods = _.filter(availableMethods, function(method) {
        return _.contains(_.keys(self.endpoints), method);
      });
      rejectedMethods = _.reject(availableMethods, function(method) {
        return _.contains(_.keys(self.endpoints), method);
      });
      fullPath = this.api._config.apiPath + this.path;
      _.each(allowedMethods, function(method) {
        var endpoint;
        endpoint = self.endpoints[method];
        return JsonRoutes.add(method, fullPath, function(req, res) {
          var doneFunc, endpointContext, error, responseData, responseInitiated;
          responseInitiated = false;
          doneFunc = function() {
            return responseInitiated = true;
          };
          endpointContext = {
            urlParams: req.params,
            queryParams: req.query,
            bodyParams: req.body,
            request: req,
            response: res,
            done: doneFunc
          };
          _.extend(endpointContext, endpoint);
          responseData = null;
          try {
            responseData = self._callEndpoint(endpointContext, endpoint);
          } catch (_error) {
            error = _error;
            ironRouterSendErrorToResponse(error, req, res);
            return;
          }
          if (responseInitiated) {
            res.end();
            return;
          } else {
            if (res.headersSent) {
              throw new Error("Must call this.done() after handling endpoint response manually: " + method + " " + fullPath);
            } else if (responseData === null || responseData === void 0) {
              throw new Error("Cannot return null or undefined from an endpoint: " + method + " " + fullPath);
            }
          }
          if (responseData.body && (responseData.statusCode || responseData.headers)) {
            return self._respond(res, responseData.body, responseData.statusCode, responseData.headers);
          } else {
            return self._respond(res, responseData);
          }
        });
      });
      return _.each(rejectedMethods, function(method) {
        return JsonRoutes.add(method, fullPath, function(req, res) {
          var headers, responseData;
          responseData = {
            status: 'error',
            message: 'API endpoint does not exist'
          };
          headers = {
            'Allow': allowedMethods.join(', ').toUpperCase()
          };
          return self._respond(res, responseData, 405, headers);
        });
      });
    };
  })();


  /*
    Convert all endpoints on the given route into our expected endpoint object if it is a bare
    function
  
    @param {Route} route The route the endpoints belong to
   */

  Route.prototype._resolveEndpoints = function() {
    _.each(this.endpoints, function(endpoint, method, endpoints) {
      if (_.isFunction(endpoint)) {
        return endpoints[method] = {
          action: endpoint
        };
      }
    });
  };


  /*
    Configure the authentication and role requirement on all endpoints (except OPTIONS, which must
    be configured directly on the endpoint)
  
    Authentication can be required on an entire route or individual endpoints. If required on an
    entire route, that serves as the default. If required in any individual endpoints, that will
    override the default.
  
    After the endpoint is configured, all authentication and role requirements of an endpoint can be
    accessed at <code>endpoint.authRequired</code> and <code>endpoint.roleRequired</code>,
    respectively.
  
    @param {Route} route The route the endpoints belong to
    @param {Endpoint} endpoint The endpoint to configure
   */

  Route.prototype._configureEndpoints = function() {
    _.each(this.endpoints, function(endpoint, method) {
      var ref, ref1;
      if (method !== 'options') {
        if (!((ref = this.options) != null ? ref.roleRequired : void 0)) {
          this.options.roleRequired = [];
        }
        if (!endpoint.roleRequired) {
          endpoint.roleRequired = [];
        }
        endpoint.roleRequired = _.union(endpoint.roleRequired, this.options.roleRequired);
        if (_.isEmpty(endpoint.roleRequired)) {
          endpoint.roleRequired = false;
        }
        if (endpoint.authRequired === void 0) {
          if (((ref1 = this.options) != null ? ref1.authRequired : void 0) || endpoint.roleRequired) {
            endpoint.authRequired = true;
          } else {
            endpoint.authRequired = false;
          }
        }
      }
    }, this);
  };


  /*
    Authenticate an endpoint if required, and return the result of calling it
  
    @returns The endpoint response or a 401 if authentication fails
   */

  Route.prototype._callEndpoint = function(endpointContext, endpoint) {
    if (this._authAccepted(endpointContext, endpoint)) {
      if (this._roleAccepted(endpointContext, endpoint)) {
        return endpoint.action.call(endpointContext);
      } else {
        return {
          statusCode: 403,
          body: {
            status: 'error',
            message: 'You do not have permission to do this.'
          }
        };
      }
    } else {
      return {
        statusCode: 401,
        body: {
          status: 'error',
          message: 'You must be logged in to do this.'
        }
      };
    }
  };


  /*
    Authenticate the given endpoint if required
  
    Once it's globally configured in the API, authentication can be required on an entire route or
    individual endpoints. If required on an entire endpoint, that serves as the default. If required
    in any individual endpoints, that will override the default.
  
    @returns False if authentication fails, and true otherwise
   */

  Route.prototype._authAccepted = function(endpointContext, endpoint) {
    if (endpoint.authRequired) {
      return this._authenticate(endpointContext);
    } else {
      return true;
    }
  };


  /*
    Verify the request is being made by an actively logged in user
  
    If verified, attach the authenticated user to the context.
  
    @returns {Boolean} True if the authentication was successful
   */

  Route.prototype._authenticate = function(endpointContext) {
    var auth, userSelector;
    auth = this.api._config.auth.user.call(endpointContext);
    if ((auth != null ? auth.userId : void 0) && (auth != null ? auth.token : void 0) && !(auth != null ? auth.user : void 0)) {
      userSelector = {};
      userSelector._id = auth.userId;
      userSelector[this.api._config.auth.token] = auth.token;
      auth.user = Meteor.users.findOne(userSelector);
    }
    if (auth != null ? auth.user : void 0) {
      endpointContext.user = auth.user;
      endpointContext.userId = auth.user._id;
      return true;
    } else {
      return false;
    }
  };


  /*
    Authenticate the user role if required
  
    Must be called after _authAccepted().
  
    @returns True if the authenticated user belongs to <i>any</i> of the acceptable roles on the
             endpoint
   */

  Route.prototype._roleAccepted = function(endpointContext, endpoint) {
    if (endpoint.roleRequired) {
      if (_.isEmpty(_.intersection(endpoint.roleRequired, endpointContext.user.roles))) {
        return false;
      }
    }
    return true;
  };


  /*
    Respond to an HTTP request
   */

  Route.prototype._respond = function(response, body, statusCode, headers) {
    var defaultHeaders, delayInMilliseconds, minimumDelayInMilliseconds, randomMultiplierBetweenOneAndTwo, sendResponse;
    if (statusCode == null) {
      statusCode = 200;
    }
    if (headers == null) {
      headers = {};
    }
    defaultHeaders = this._lowerCaseKeys(this.api._config.defaultHeaders);
    headers = this._lowerCaseKeys(headers);
    headers = _.extend(defaultHeaders, headers);
    if (headers['content-type'].match(/json|javascript/) !== null) {
      if (this.api._config.prettyJson) {
        body = JSON.stringify(body, void 0, 2);
      } else {
        body = JSON.stringify(body);
      }
    }
    sendResponse = function() {
      response.writeHead(statusCode, headers);
      response.write(body);
      return response.end();
    };
    if (statusCode === 401 || statusCode === 403) {
      minimumDelayInMilliseconds = 500;
      randomMultiplierBetweenOneAndTwo = 1 + Math.random();
      delayInMilliseconds = minimumDelayInMilliseconds * randomMultiplierBetweenOneAndTwo;
      return Meteor.setTimeout(sendResponse, delayInMilliseconds);
    } else {
      return sendResponse();
    }
  };


  /*
    Return the object with all of the keys converted to lowercase
   */

  Route.prototype._lowerCaseKeys = function(object) {
    return _.chain(object).pairs().map(function(attr) {
      return [attr[0].toLowerCase(), attr[1]];
    }).object().value();
  };

  return Route;

})();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble_restivus/lib/restivus.coffee.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var          
  indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

this.Restivus = (function() {
  function Restivus(options) {
    var corsHeaders;
    this._routes = [];
    this._config = {
      paths: [],
      useDefaultAuth: false,
      apiPath: 'api/',
      version: null,
      prettyJson: false,
      auth: {
        token: 'services.resume.loginTokens.hashedToken',
        user: function() {
          var token;
          if (this.request.headers['x-auth-token']) {
            token = Accounts._hashLoginToken(this.request.headers['x-auth-token']);
          }
          return {
            userId: this.request.headers['x-user-id'],
            token: token
          };
        }
      },
      defaultHeaders: {
        'Content-Type': 'application/json'
      },
      enableCors: true
    };
    _.extend(this._config, options);
    if (this._config.enableCors) {
      corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'
      };
      if (this._config.useDefaultAuth) {
        corsHeaders['Access-Control-Allow-Headers'] += ', X-User-Id, X-Auth-Token';
      }
      _.extend(this._config.defaultHeaders, corsHeaders);
      if (!this._config.defaultOptionsEndpoint) {
        this._config.defaultOptionsEndpoint = function() {
          this.response.writeHead(200, corsHeaders);
          return this.done();
        };
      }
    }
    if (this._config.apiPath[0] === '/') {
      this._config.apiPath = this._config.apiPath.slice(1);
    }
    if (_.last(this._config.apiPath) !== '/') {
      this._config.apiPath = this._config.apiPath + '/';
    }
    if (this._config.version) {
      this._config.apiPath += this._config.version + '/';
    }
    if (this._config.useDefaultAuth) {
      this._initAuth();
    } else if (this._config.useAuth) {
      this._initAuth();
      console.warn('Warning: useAuth API config option will be removed in Restivus v1.0 ' + '\n    Use the useDefaultAuth option instead');
    }
    return this;
  }


  /**
    Add endpoints for the given HTTP methods at the given path
  
    @param path {String} The extended URL path (will be appended to base path of the API)
    @param options {Object} Route configuration options
    @param options.authRequired {Boolean} The default auth requirement for each endpoint on the route
    @param options.roleRequired {String or String[]} The default role required for each endpoint on the route
    @param endpoints {Object} A set of endpoints available on the new route (get, post, put, patch, delete, options)
    @param endpoints.<method> {Function or Object} If a function is provided, all default route
        configuration options will be applied to the endpoint. Otherwise an object with an `action`
        and all other route config options available. An `action` must be provided with the object.
   */

  Restivus.prototype.addRoute = function(path, options, endpoints) {
    var route;
    route = new share.Route(this, path, options, endpoints);
    this._routes.push(route);
    route.addToApi();
    return this;
  };


  /**
    Generate routes for the Meteor Collection with the given name
   */

  Restivus.prototype.addCollection = function(collection, options) {
    var collectionEndpoints, collectionRouteEndpoints, endpointsAwaitingConfiguration, entityRouteEndpoints, excludedEndpoints, methods, methodsOnCollection, path, routeOptions;
    if (options == null) {
      options = {};
    }
    methods = ['get', 'post', 'put', 'delete', 'getAll'];
    methodsOnCollection = ['post', 'getAll'];
    if (collection === Meteor.users) {
      collectionEndpoints = this._userCollectionEndpoints;
    } else {
      collectionEndpoints = this._collectionEndpoints;
    }
    endpointsAwaitingConfiguration = options.endpoints || {};
    routeOptions = options.routeOptions || {};
    excludedEndpoints = options.excludedEndpoints || [];
    path = options.path || collection._name;
    collectionRouteEndpoints = {};
    entityRouteEndpoints = {};
    if (_.isEmpty(endpointsAwaitingConfiguration) && _.isEmpty(excludedEndpoints)) {
      _.each(methods, function(method) {
        if (indexOf.call(methodsOnCollection, method) >= 0) {
          _.extend(collectionRouteEndpoints, collectionEndpoints[method].call(this, collection));
        } else {
          _.extend(entityRouteEndpoints, collectionEndpoints[method].call(this, collection));
        }
      }, this);
    } else {
      _.each(methods, function(method) {
        var configuredEndpoint, endpointOptions;
        if (indexOf.call(excludedEndpoints, method) < 0 && endpointsAwaitingConfiguration[method] !== false) {
          endpointOptions = endpointsAwaitingConfiguration[method];
          configuredEndpoint = {};
          _.each(collectionEndpoints[method].call(this, collection), function(action, methodType) {
            return configuredEndpoint[methodType] = _.chain(action).clone().extend(endpointOptions).value();
          });
          if (indexOf.call(methodsOnCollection, method) >= 0) {
            _.extend(collectionRouteEndpoints, configuredEndpoint);
          } else {
            _.extend(entityRouteEndpoints, configuredEndpoint);
          }
        }
      }, this);
    }
    this.addRoute(path, routeOptions, collectionRouteEndpoints);
    this.addRoute(path + "/:id", routeOptions, entityRouteEndpoints);
    return this;
  };


  /**
    A set of endpoints that can be applied to a Collection Route
   */

  Restivus.prototype._collectionEndpoints = {
    get: function(collection) {
      return {
        get: {
          action: function() {
            var entity;
            entity = collection.findOne(this.urlParams.id);
            if (entity) {
              return {
                status: 'success',
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Item not found'
                }
              };
            }
          }
        }
      };
    },
    put: function(collection) {
      return {
        put: {
          action: function() {
            var entity, entityIsUpdated;
            entityIsUpdated = collection.update(this.urlParams.id, this.bodyParams);
            if (entityIsUpdated) {
              entity = collection.findOne(this.urlParams.id);
              return {
                status: 'success',
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Item not found'
                }
              };
            }
          }
        }
      };
    },
    "delete": function(collection) {
      return {
        "delete": {
          action: function() {
            if (collection.remove(this.urlParams.id)) {
              return {
                status: 'success',
                data: {
                  message: 'Item removed'
                }
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Item not found'
                }
              };
            }
          }
        }
      };
    },
    post: function(collection) {
      return {
        post: {
          action: function() {
            var entity, entityId;
            entityId = collection.insert(this.bodyParams);
            entity = collection.findOne(entityId);
            if (entity) {
              return {
                statusCode: 201,
                body: {
                  status: 'success',
                  data: entity
                }
              };
            } else {
              return {
                statusCode: 400,
                body: {
                  status: 'fail',
                  message: 'No item added'
                }
              };
            }
          }
        }
      };
    },
    getAll: function(collection) {
      return {
        get: {
          action: function() {
            var entities;
            entities = collection.find().fetch();
            if (entities) {
              return {
                status: 'success',
                data: entities
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Unable to retrieve items from collection'
                }
              };
            }
          }
        }
      };
    }
  };


  /**
    A set of endpoints that can be applied to a Meteor.users Collection Route
   */

  Restivus.prototype._userCollectionEndpoints = {
    get: function(collection) {
      return {
        get: {
          action: function() {
            var entity;
            entity = collection.findOne(this.urlParams.id, {
              fields: {
                profile: 1
              }
            });
            if (entity) {
              return {
                status: 'success',
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'User not found'
                }
              };
            }
          }
        }
      };
    },
    put: function(collection) {
      return {
        put: {
          action: function() {
            var entity, entityIsUpdated;
            entityIsUpdated = collection.update(this.urlParams.id, {
              $set: {
                profile: this.bodyParams
              }
            });
            if (entityIsUpdated) {
              entity = collection.findOne(this.urlParams.id, {
                fields: {
                  profile: 1
                }
              });
              return {
                status: "success",
                data: entity
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'User not found'
                }
              };
            }
          }
        }
      };
    },
    "delete": function(collection) {
      return {
        "delete": {
          action: function() {
            if (collection.remove(this.urlParams.id)) {
              return {
                status: 'success',
                data: {
                  message: 'User removed'
                }
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'User not found'
                }
              };
            }
          }
        }
      };
    },
    post: function(collection) {
      return {
        post: {
          action: function() {
            var entity, entityId;
            entityId = Accounts.createUser(this.bodyParams);
            entity = collection.findOne(entityId, {
              fields: {
                profile: 1
              }
            });
            if (entity) {
              return {
                statusCode: 201,
                body: {
                  status: 'success',
                  data: entity
                }
              };
            } else {
              ({
                statusCode: 400
              });
              return {
                status: 'fail',
                message: 'No user added'
              };
            }
          }
        }
      };
    },
    getAll: function(collection) {
      return {
        get: {
          action: function() {
            var entities;
            entities = collection.find({}, {
              fields: {
                profile: 1
              }
            }).fetch();
            if (entities) {
              return {
                status: 'success',
                data: entities
              };
            } else {
              return {
                statusCode: 404,
                body: {
                  status: 'fail',
                  message: 'Unable to retrieve users'
                }
              };
            }
          }
        }
      };
    }
  };


  /*
    Add /login and /logout endpoints to the API
   */

  Restivus.prototype._initAuth = function() {
    var logout, self;
    self = this;

    /*
      Add a login endpoint to the API
    
      After the user is logged in, the onLoggedIn hook is called (see Restfully.configure() for
      adding hook).
     */
    this.addRoute('login', {
      authRequired: false
    }, {
      post: function() {
        var auth, e, extraData, ref, ref1, response, searchQuery, user;
        user = {};
        if (this.bodyParams.user) {
          if (this.bodyParams.user.indexOf('@') === -1) {
            user.username = this.bodyParams.user;
          } else {
            user.email = this.bodyParams.user;
          }
        } else if (this.bodyParams.username) {
          user.username = this.bodyParams.username;
        } else if (this.bodyParams.email) {
          user.email = this.bodyParams.email;
        }
        try {
          auth = Auth.loginWithPassword(user, this.bodyParams.password);
        } catch (_error) {
          e = _error;
          return {
            statusCode: e.error,
            body: {
              status: 'error',
              message: e.reason
            }
          };
        }
        if (auth.userId && auth.authToken) {
          searchQuery = {};
          searchQuery[self._config.auth.token] = Accounts._hashLoginToken(auth.authToken);
          this.user = Meteor.users.findOne({
            '_id': auth.userId
          }, searchQuery);
          this.userId = (ref = this.user) != null ? ref._id : void 0;
        }
        response = {
          status: 'success',
          data: auth
        };
        extraData = (ref1 = self._config.onLoggedIn) != null ? ref1.call(this) : void 0;
        if (extraData != null) {
          _.extend(response.data, {
            extra: extraData
          });
        }
        return response;
      }
    });
    logout = function() {
      var authToken, extraData, hashedToken, index, ref, response, tokenFieldName, tokenLocation, tokenPath, tokenRemovalQuery, tokenToRemove;
      authToken = this.request.headers['x-auth-token'];
      hashedToken = Accounts._hashLoginToken(authToken);
      tokenLocation = self._config.auth.token;
      index = tokenLocation.lastIndexOf('.');
      tokenPath = tokenLocation.substring(0, index);
      tokenFieldName = tokenLocation.substring(index + 1);
      tokenToRemove = {};
      tokenToRemove[tokenFieldName] = hashedToken;
      tokenRemovalQuery = {};
      tokenRemovalQuery[tokenPath] = tokenToRemove;
      Meteor.users.update(this.user._id, {
        $pull: tokenRemovalQuery
      });
      response = {
        status: 'success',
        data: {
          message: 'You\'ve been logged out!'
        }
      };
      extraData = (ref = self._config.onLoggedOut) != null ? ref.call(this) : void 0;
      if (extraData != null) {
        _.extend(response.data, {
          extra: extraData
        });
      }
      return response;
    };

    /*
      Add a logout endpoint to the API
    
      After the user is logged out, the onLoggedOut hook is called (see Restfully.configure() for
      adding hook).
     */
    return this.addRoute('logout', {
      authRequired: true
    }, {
      get: function() {
        console.warn("Warning: Default logout via GET will be removed in Restivus v1.0. Use POST instead.");
        console.warn("    See https://github.com/kahmali/meteor-restivus/issues/100");
        return logout.call(this);
      },
      post: logout
    });
  };

  return Restivus;

})();

Restivus = this.Restivus;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("nimble:restivus", {
  Restivus: Restivus
});

})();

//# sourceURL=meteor://💻app/packages/nimble_restivus.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbmltYmxlX3Jlc3RpdnVzL2xpYi9hdXRoLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbmltYmxlX3Jlc3RpdnVzL2xpYi9yb3V0ZS5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL25pbWJsZV9yZXN0aXZ1cy9saWIvcmVzdGl2dXMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFBQSxJQUFDLFVBQUQsSUFBQyxRQUFTLEdBQVY7O0FBRUE7QUFBQTs7R0FGQTs7QUFBQSxhQUtBLEdBQWdCLEtBQUssQ0FBQyxLQUFOLENBQVksU0FBQyxJQUFEO0FBQzFCLFFBQU0sSUFBTixFQUNFO0FBQUEsUUFBSSxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FBSjtBQUFBLElBQ0EsVUFBVSxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FEVjtBQUFBLElBRUEsT0FBTyxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FGUDtHQURGO0FBS0EsTUFBRyxDQUFDLENBQUMsSUFBRixDQUFPLElBQVAsQ0FBWSxDQUFDLE1BQWIsS0FBdUIsRUFBMUI7QUFDRSxVQUFVLFNBQUssQ0FBQyxLQUFOLENBQVksNkNBQVosQ0FBVixDQURGO0dBTEE7QUFRQSxTQUFPLElBQVAsQ0FUMEI7QUFBQSxDQUFaLENBTGhCOztBQWlCQTtBQUFBOztHQWpCQTs7QUFBQSxvQkFvQkEsR0FBdUIsU0FBQyxJQUFEO0FBQ3JCLE1BQUcsSUFBSSxDQUFDLEVBQVI7QUFDRSxXQUFPO0FBQUEsTUFBQyxPQUFPLElBQUksQ0FBQyxFQUFiO0tBQVAsQ0FERjtHQUFBLE1BRUssSUFBRyxJQUFJLENBQUMsUUFBUjtBQUNILFdBQU87QUFBQSxNQUFDLFlBQVksSUFBSSxDQUFDLFFBQWxCO0tBQVAsQ0FERztHQUFBLE1BRUEsSUFBRyxJQUFJLENBQUMsS0FBUjtBQUNILFdBQU87QUFBQSxNQUFDLGtCQUFrQixJQUFJLENBQUMsS0FBeEI7S0FBUCxDQURHO0dBSkw7QUFRQSxRQUFVLFVBQU0sMENBQU4sQ0FBVixDQVRxQjtBQUFBLENBcEJ2Qjs7QUFnQ0E7QUFBQTs7R0FoQ0E7O0FBQUEsSUFtQ0MsS0FBSSxDQUFDLGlCQUFOLEdBQTBCLFNBQUMsSUFBRCxFQUFPLFFBQVA7QUFDeEI7QUFBQSxNQUFHLFNBQVksU0FBZjtBQUNFLFVBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLGNBQWxCLENBQVYsQ0FERjtHQUFBO0FBQUEsRUFJQSxNQUFNLElBQU4sRUFBWSxhQUFaLENBSkE7QUFBQSxFQUtBLE1BQU0sUUFBTixFQUFnQixNQUFoQixDQUxBO0FBQUEsRUFRQSw2QkFBNkIscUJBQXFCLElBQXJCLENBUjdCO0FBQUEsRUFTQSxxQkFBcUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFiLENBQXFCLDBCQUFyQixDQVRyQjtBQVdBLE1BQUcsbUJBQUg7QUFDRSxVQUFVLFVBQU0sQ0FBQyxLQUFQLENBQWEsR0FBYixFQUFrQixjQUFsQixDQUFWLENBREY7R0FYQTtBQWFBLE1BQUcsbURBQStCLENBQUUsa0JBQXBDO0FBQ0UsVUFBVSxVQUFNLENBQUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsY0FBbEIsQ0FBVixDQURGO0dBYkE7QUFBQSxFQWlCQSx1QkFBdUIsUUFBUSxDQUFDLGNBQVQsQ0FBd0Isa0JBQXhCLEVBQTRDLFFBQTVDLENBakJ2QjtBQWtCQSxNQUFHLG9CQUFvQixDQUFDLEtBQXhCO0FBQ0UsVUFBVSxVQUFNLENBQUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsY0FBbEIsQ0FBVixDQURGO0dBbEJBO0FBQUEsRUFzQkEsWUFBWSxRQUFRLENBQUMsMEJBQVQsRUF0Qlo7QUFBQSxFQXVCQSxjQUFjLFFBQVEsQ0FBQyxlQUFULENBQXlCLFNBQVMsQ0FBQyxLQUFuQyxDQXZCZDtBQUFBLEVBd0JBLFFBQVEsQ0FBQyx1QkFBVCxDQUFpQyxrQkFBa0IsQ0FBQyxHQUFwRCxFQUF5RDtBQUFBLElBQUMsd0JBQUQ7R0FBekQsQ0F4QkE7QUEwQkEsU0FBTztBQUFBLElBQUMsV0FBVyxTQUFTLENBQUMsS0FBdEI7QUFBQSxJQUE2QixRQUFRLGtCQUFrQixDQUFDLEdBQXhEO0dBQVAsQ0EzQndCO0FBQUEsQ0FuQzFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsS0FBVyxDQUFDO0FBRUcsaUJBQUMsR0FBRCxFQUFPLElBQVAsRUFBYyxPQUFkLEVBQXdCLFVBQXhCO0FBRVgsSUFGWSxJQUFDLE9BQUQsR0FFWjtBQUFBLElBRmtCLElBQUMsUUFBRCxJQUVsQjtBQUFBLElBRnlCLElBQUMsV0FBRCxPQUV6QjtBQUFBLElBRm1DLElBQUMsYUFBRCxVQUVuQztBQUFBLFFBQUcsS0FBSyxVQUFSO0FBQ0UsVUFBQyxVQUFELEdBQWEsSUFBQyxRQUFkO0FBQUEsTUFDQSxJQUFDLFFBQUQsR0FBVyxFQURYLENBREY7S0FGVztFQUFBLENBQWI7O0FBQUEsa0JBT0EsV0FBYTtBQUNYO0FBQUEsdUJBQW1CLENBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsS0FBaEIsRUFBdUIsT0FBdkIsRUFBZ0MsUUFBaEMsRUFBMEMsU0FBMUMsQ0FBbkI7QUFFQSxXQUFPO0FBQ0w7QUFBQSxhQUFPLElBQVA7QUFJQSxVQUFHLENBQUMsQ0FBQyxRQUFGLENBQVcsSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLEtBQXhCLEVBQStCLElBQUMsS0FBaEMsQ0FBSDtBQUNFLGNBQVUsVUFBTSw2Q0FBMkMsSUFBQyxLQUFsRCxDQUFWLENBREY7T0FKQTtBQUFBLE1BUUEsSUFBQyxVQUFELEdBQWEsQ0FBQyxDQUFDLE1BQUYsQ0FBUztBQUFBLGlCQUFTLElBQUMsSUFBRyxDQUFDLE9BQU8sQ0FBQyxzQkFBdEI7T0FBVCxFQUF1RCxJQUFDLFVBQXhELENBUmI7QUFBQSxNQVdBLElBQUMsa0JBQUQsRUFYQTtBQUFBLE1BWUEsSUFBQyxvQkFBRCxFQVpBO0FBQUEsTUFlQSxJQUFDLElBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQW5CLENBQXdCLElBQUMsS0FBekIsQ0FmQTtBQUFBLE1BaUJBLGlCQUFpQixDQUFDLENBQUMsTUFBRixDQUFTLGdCQUFULEVBQTJCLFNBQUMsTUFBRDtlQUMxQyxDQUFDLENBQUMsUUFBRixDQUFXLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBSSxDQUFDLFNBQVosQ0FBWCxFQUFtQyxNQUFuQyxFQUQwQztNQUFBLENBQTNCLENBakJqQjtBQUFBLE1BbUJBLGtCQUFrQixDQUFDLENBQUMsTUFBRixDQUFTLGdCQUFULEVBQTJCLFNBQUMsTUFBRDtlQUMzQyxDQUFDLENBQUMsUUFBRixDQUFXLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBSSxDQUFDLFNBQVosQ0FBWCxFQUFtQyxNQUFuQyxFQUQyQztNQUFBLENBQTNCLENBbkJsQjtBQUFBLE1BdUJBLFdBQVcsSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLE9BQWIsR0FBdUIsSUFBQyxLQXZCbkM7QUFBQSxNQXdCQSxDQUFDLENBQUMsSUFBRixDQUFPLGNBQVAsRUFBdUIsU0FBQyxNQUFEO0FBQ3JCO0FBQUEsbUJBQVcsSUFBSSxDQUFDLFNBQVUsUUFBMUI7ZUFDQSxVQUFVLENBQUMsR0FBWCxDQUFlLE1BQWYsRUFBdUIsUUFBdkIsRUFBaUMsU0FBQyxHQUFELEVBQU0sR0FBTjtBQUUvQjtBQUFBLDhCQUFvQixLQUFwQjtBQUFBLFVBQ0EsV0FBVzttQkFDVCxvQkFBb0IsS0FEWDtVQUFBLENBRFg7QUFBQSxVQUlBLGtCQUNFO0FBQUEsdUJBQVcsR0FBRyxDQUFDLE1BQWY7QUFBQSxZQUNBLGFBQWEsR0FBRyxDQUFDLEtBRGpCO0FBQUEsWUFFQSxZQUFZLEdBQUcsQ0FBQyxJQUZoQjtBQUFBLFlBR0EsU0FBUyxHQUhUO0FBQUEsWUFJQSxVQUFVLEdBSlY7QUFBQSxZQUtBLE1BQU0sUUFMTjtXQUxGO0FBQUEsVUFZQSxDQUFDLENBQUMsTUFBRixDQUFTLGVBQVQsRUFBMEIsUUFBMUIsQ0FaQTtBQUFBLFVBZUEsZUFBZSxJQWZmO0FBZ0JBO0FBQ0UsMkJBQWUsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsZUFBbkIsRUFBb0MsUUFBcEMsQ0FBZixDQURGO1dBQUE7QUFJRSxZQUZJLGNBRUo7QUFBQSwwQ0FBOEIsS0FBOUIsRUFBcUMsR0FBckMsRUFBMEMsR0FBMUM7QUFDQSxtQkFMRjtXQWhCQTtBQXVCQSxjQUFHLGlCQUFIO0FBRUUsZUFBRyxDQUFDLEdBQUo7QUFDQSxtQkFIRjtXQUFBO0FBS0UsZ0JBQUcsR0FBRyxDQUFDLFdBQVA7QUFDRSxvQkFBVSxVQUFNLHNFQUFvRSxNQUFwRSxHQUEyRSxHQUEzRSxHQUE4RSxRQUFwRixDQUFWLENBREY7YUFBQSxNQUVLLElBQUcsaUJBQWdCLElBQWhCLElBQXdCLGlCQUFnQixNQUEzQztBQUNILG9CQUFVLFVBQU0sdURBQXFELE1BQXJELEdBQTRELEdBQTVELEdBQStELFFBQXJFLENBQVYsQ0FERzthQVBQO1dBdkJBO0FBa0NBLGNBQUcsWUFBWSxDQUFDLElBQWIsSUFBc0IsQ0FBQyxZQUFZLENBQUMsVUFBYixJQUEyQixZQUFZLENBQUMsT0FBekMsQ0FBekI7bUJBQ0UsSUFBSSxDQUFDLFFBQUwsQ0FBYyxHQUFkLEVBQW1CLFlBQVksQ0FBQyxJQUFoQyxFQUFzQyxZQUFZLENBQUMsVUFBbkQsRUFBK0QsWUFBWSxDQUFDLE9BQTVFLEVBREY7V0FBQTttQkFHRSxJQUFJLENBQUMsUUFBTCxDQUFjLEdBQWQsRUFBbUIsWUFBbkIsRUFIRjtXQXBDK0I7UUFBQSxDQUFqQyxFQUZxQjtNQUFBLENBQXZCLENBeEJBO2FBbUVBLENBQUMsQ0FBQyxJQUFGLENBQU8sZUFBUCxFQUF3QixTQUFDLE1BQUQ7ZUFDdEIsVUFBVSxDQUFDLEdBQVgsQ0FBZSxNQUFmLEVBQXVCLFFBQXZCLEVBQWlDLFNBQUMsR0FBRCxFQUFNLEdBQU47QUFDL0I7QUFBQSx5QkFBZTtBQUFBLG9CQUFRLE9BQVI7QUFBQSxZQUFpQixTQUFTLDZCQUExQjtXQUFmO0FBQUEsVUFDQSxVQUFVO0FBQUEscUJBQVMsY0FBYyxDQUFDLElBQWYsQ0FBb0IsSUFBcEIsQ0FBeUIsQ0FBQyxXQUExQixFQUFUO1dBRFY7aUJBRUEsSUFBSSxDQUFDLFFBQUwsQ0FBYyxHQUFkLEVBQW1CLFlBQW5CLEVBQWlDLEdBQWpDLEVBQXNDLE9BQXRDLEVBSCtCO1FBQUEsQ0FBakMsRUFEc0I7TUFBQSxDQUF4QixFQXBFSztJQUFBLENBQVAsQ0FIVztFQUFBLEVBQUgsRUFQVjs7QUFxRkE7QUFBQTs7Ozs7S0FyRkE7O0FBQUEsa0JBMkZBLG9CQUFtQjtBQUNqQixLQUFDLENBQUMsSUFBRixDQUFPLElBQUMsVUFBUixFQUFtQixTQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFNBQW5CO0FBQ2pCLFVBQUcsQ0FBQyxDQUFDLFVBQUYsQ0FBYSxRQUFiLENBQUg7ZUFDRSxTQUFVLFFBQVYsR0FBb0I7QUFBQSxVQUFDLFFBQVEsUUFBVDtVQUR0QjtPQURpQjtJQUFBLENBQW5CLEVBRGlCO0VBQUEsQ0EzRm5COztBQWtHQTtBQUFBOzs7Ozs7Ozs7Ozs7OztLQWxHQTs7QUFBQSxrQkFpSEEsc0JBQXFCO0FBQ25CLEtBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxVQUFSLEVBQW1CLFNBQUMsUUFBRCxFQUFXLE1BQVg7QUFDakI7QUFBQSxVQUFHLFdBQVksU0FBZjtBQUVFLFlBQUcsb0NBQVksQ0FBRSxzQkFBakI7QUFDRSxjQUFDLFFBQU8sQ0FBQyxZQUFULEdBQXdCLEVBQXhCLENBREY7U0FBQTtBQUVBLFlBQUcsU0FBWSxDQUFDLFlBQWhCO0FBQ0Usa0JBQVEsQ0FBQyxZQUFULEdBQXdCLEVBQXhCLENBREY7U0FGQTtBQUFBLFFBSUEsUUFBUSxDQUFDLFlBQVQsR0FBd0IsQ0FBQyxDQUFDLEtBQUYsQ0FBUSxRQUFRLENBQUMsWUFBakIsRUFBK0IsSUFBQyxRQUFPLENBQUMsWUFBeEMsQ0FKeEI7QUFNQSxZQUFHLENBQUMsQ0FBQyxPQUFGLENBQVUsUUFBUSxDQUFDLFlBQW5CLENBQUg7QUFDRSxrQkFBUSxDQUFDLFlBQVQsR0FBd0IsS0FBeEIsQ0FERjtTQU5BO0FBVUEsWUFBRyxRQUFRLENBQUMsWUFBVCxLQUF5QixNQUE1QjtBQUNFLG1EQUFXLENBQUUsc0JBQVYsSUFBMEIsUUFBUSxDQUFDLFlBQXRDO0FBQ0Usb0JBQVEsQ0FBQyxZQUFULEdBQXdCLElBQXhCLENBREY7V0FBQTtBQUdFLG9CQUFRLENBQUMsWUFBVCxHQUF3QixLQUF4QixDQUhGO1dBREY7U0FaRjtPQURpQjtJQUFBLENBQW5CLEVBbUJFLElBbkJGLEVBRG1CO0VBQUEsQ0FqSHJCOztBQXlJQTtBQUFBOzs7O0tBeklBOztBQUFBLGtCQThJQSxnQkFBZSxTQUFDLGVBQUQsRUFBa0IsUUFBbEI7QUFFYixRQUFHLElBQUMsY0FBRCxDQUFlLGVBQWYsRUFBZ0MsUUFBaEMsQ0FBSDtBQUNFLFVBQUcsSUFBQyxjQUFELENBQWUsZUFBZixFQUFnQyxRQUFoQyxDQUFIO2VBQ0UsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFoQixDQUFxQixlQUFyQixFQURGO09BQUE7ZUFHRTtBQUFBLHNCQUFZLEdBQVo7QUFBQSxVQUNBLE1BQU07QUFBQSxZQUFDLFFBQVEsT0FBVDtBQUFBLFlBQWtCLFNBQVMsd0NBQTNCO1dBRE47VUFIRjtPQURGO0tBQUE7YUFPRTtBQUFBLG9CQUFZLEdBQVo7QUFBQSxRQUNBLE1BQU07QUFBQSxVQUFDLFFBQVEsT0FBVDtBQUFBLFVBQWtCLFNBQVMsbUNBQTNCO1NBRE47UUFQRjtLQUZhO0VBQUEsQ0E5SWY7O0FBMkpBO0FBQUE7Ozs7Ozs7O0tBM0pBOztBQUFBLGtCQW9LQSxnQkFBZSxTQUFDLGVBQUQsRUFBa0IsUUFBbEI7QUFDYixRQUFHLFFBQVEsQ0FBQyxZQUFaO2FBQ0UsSUFBQyxjQUFELENBQWUsZUFBZixFQURGO0tBQUE7YUFFSyxLQUZMO0tBRGE7RUFBQSxDQXBLZjs7QUEwS0E7QUFBQTs7Ozs7O0tBMUtBOztBQUFBLGtCQWlMQSxnQkFBZSxTQUFDLGVBQUQ7QUFFYjtBQUFBLFdBQU8sSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBdkIsQ0FBNEIsZUFBNUIsQ0FBUDtBQUdBLHdCQUFHLElBQUksQ0FBRSxnQkFBTixvQkFBaUIsSUFBSSxDQUFFLGVBQXZCLElBQWlDLGlCQUFJLElBQUksQ0FBRSxjQUE5QztBQUNFLHFCQUFlLEVBQWY7QUFBQSxNQUNBLFlBQVksQ0FBQyxHQUFiLEdBQW1CLElBQUksQ0FBQyxNQUR4QjtBQUFBLE1BRUEsWUFBYSxLQUFDLElBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQWxCLENBQWIsR0FBd0MsSUFBSSxDQUFDLEtBRjdDO0FBQUEsTUFHQSxJQUFJLENBQUMsSUFBTCxHQUFZLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBYixDQUFxQixZQUFyQixDQUhaLENBREY7S0FIQTtBQVVBLHVCQUFHLElBQUksQ0FBRSxhQUFUO0FBQ0UscUJBQWUsQ0FBQyxJQUFoQixHQUF1QixJQUFJLENBQUMsSUFBNUI7QUFBQSxNQUNBLGVBQWUsQ0FBQyxNQUFoQixHQUF5QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBRG5DO2FBRUEsS0FIRjtLQUFBO2FBSUssTUFKTDtLQVphO0VBQUEsQ0FqTGY7O0FBb01BO0FBQUE7Ozs7Ozs7S0FwTUE7O0FBQUEsa0JBNE1BLGdCQUFlLFNBQUMsZUFBRCxFQUFrQixRQUFsQjtBQUNiLFFBQUcsUUFBUSxDQUFDLFlBQVo7QUFDRSxVQUFHLENBQUMsQ0FBQyxPQUFGLENBQVUsQ0FBQyxDQUFDLFlBQUYsQ0FBZSxRQUFRLENBQUMsWUFBeEIsRUFBc0MsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUEzRCxDQUFWLENBQUg7QUFDRSxlQUFPLEtBQVAsQ0FERjtPQURGO0tBQUE7V0FHQSxLQUphO0VBQUEsQ0E1TWY7O0FBbU5BO0FBQUE7O0tBbk5BOztBQUFBLGtCQXNOQSxXQUFVLFNBQUMsUUFBRCxFQUFXLElBQVgsRUFBaUIsVUFBakIsRUFBaUMsT0FBakM7QUFHUjs7TUFIeUIsYUFBVztLQUdwQzs7TUFIeUMsVUFBUTtLQUdqRDtBQUFBLHFCQUFpQixJQUFDLGVBQUQsQ0FBZ0IsSUFBQyxJQUFHLENBQUMsT0FBTyxDQUFDLGNBQTdCLENBQWpCO0FBQUEsSUFDQSxVQUFVLElBQUMsZUFBRCxDQUFnQixPQUFoQixDQURWO0FBQUEsSUFFQSxVQUFVLENBQUMsQ0FBQyxNQUFGLENBQVMsY0FBVCxFQUF5QixPQUF6QixDQUZWO0FBS0EsUUFBRyxPQUFRLGdCQUFlLENBQUMsS0FBeEIsQ0FBOEIsaUJBQTlCLE1BQXNELElBQXpEO0FBQ0UsVUFBRyxJQUFDLElBQUcsQ0FBQyxPQUFPLENBQUMsVUFBaEI7QUFDRSxlQUFPLElBQUksQ0FBQyxTQUFMLENBQWUsSUFBZixFQUFxQixNQUFyQixFQUFnQyxDQUFoQyxDQUFQLENBREY7T0FBQTtBQUdFLGVBQU8sSUFBSSxDQUFDLFNBQUwsQ0FBZSxJQUFmLENBQVAsQ0FIRjtPQURGO0tBTEE7QUFBQSxJQVlBLGVBQWU7QUFDYixjQUFRLENBQUMsU0FBVCxDQUFtQixVQUFuQixFQUErQixPQUEvQjtBQUFBLE1BQ0EsUUFBUSxDQUFDLEtBQVQsQ0FBZSxJQUFmLENBREE7YUFFQSxRQUFRLENBQUMsR0FBVCxHQUhhO0lBQUEsQ0FaZjtBQWdCQSxRQUFHLGVBQWUsR0FBZixtQkFBb0IsR0FBdkI7QUFPRSxtQ0FBNkIsR0FBN0I7QUFBQSxNQUNBLG1DQUFtQyxJQUFJLElBQUksQ0FBQyxNQUFMLEVBRHZDO0FBQUEsTUFFQSxzQkFBc0IsNkJBQTZCLGdDQUZuRDthQUdBLE1BQU0sQ0FBQyxVQUFQLENBQWtCLFlBQWxCLEVBQWdDLG1CQUFoQyxFQVZGO0tBQUE7YUFZRSxlQVpGO0tBbkJRO0VBQUEsQ0F0TlY7O0FBdVBBO0FBQUE7O0tBdlBBOztBQUFBLGtCQTBQQSxpQkFBZ0IsU0FBQyxNQUFEO1dBQ2QsQ0FBQyxDQUFDLEtBQUYsQ0FBUSxNQUFSLENBQ0EsQ0FBQyxLQURELEVBRUEsQ0FBQyxHQUZELENBRUssU0FBQyxJQUFEO2FBQ0gsQ0FBQyxJQUFLLEdBQUUsQ0FBQyxXQUFSLEVBQUQsRUFBd0IsSUFBSyxHQUE3QixFQURHO0lBQUEsQ0FGTCxDQUlBLENBQUMsTUFKRCxFQUtBLENBQUMsS0FMRCxHQURjO0VBQUEsQ0ExUGhCOztlQUFBOztJQUZGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0VBQUE7O0FBQUEsSUFBTztBQUVRLG9CQUFDLE9BQUQ7QUFDWDtBQUFBLFFBQUMsUUFBRCxHQUFXLEVBQVg7QUFBQSxJQUNBLElBQUMsUUFBRCxHQUNFO0FBQUEsYUFBTyxFQUFQO0FBQUEsTUFDQSxnQkFBZ0IsS0FEaEI7QUFBQSxNQUVBLFNBQVMsTUFGVDtBQUFBLE1BR0EsU0FBUyxJQUhUO0FBQUEsTUFJQSxZQUFZLEtBSlo7QUFBQSxNQUtBLE1BQ0U7QUFBQSxlQUFPLHlDQUFQO0FBQUEsUUFDQSxNQUFNO0FBQ0o7QUFBQSxjQUFHLElBQUMsUUFBTyxDQUFDLE9BQVEsZ0JBQXBCO0FBQ0Usb0JBQVEsUUFBUSxDQUFDLGVBQVQsQ0FBeUIsSUFBQyxRQUFPLENBQUMsT0FBUSxnQkFBMUMsQ0FBUixDQURGO1dBQUE7aUJBRUE7QUFBQSxvQkFBUSxJQUFDLFFBQU8sQ0FBQyxPQUFRLGFBQXpCO0FBQUEsWUFDQSxPQUFPLEtBRFA7WUFISTtRQUFBLENBRE47T0FORjtBQUFBLE1BWUEsZ0JBQ0U7QUFBQSx3QkFBZ0Isa0JBQWhCO09BYkY7QUFBQSxNQWNBLFlBQVksSUFkWjtLQUZGO0FBQUEsSUFtQkEsQ0FBQyxDQUFDLE1BQUYsQ0FBUyxJQUFDLFFBQVYsRUFBbUIsT0FBbkIsQ0FuQkE7QUFxQkEsUUFBRyxJQUFDLFFBQU8sQ0FBQyxVQUFaO0FBQ0Usb0JBQ0U7QUFBQSx1Q0FBK0IsR0FBL0I7QUFBQSxRQUNBLGdDQUFnQyxnREFEaEM7T0FERjtBQUlBLFVBQUcsSUFBQyxRQUFPLENBQUMsY0FBWjtBQUNFLG1CQUFZLGdDQUFaLElBQStDLDJCQUEvQyxDQURGO09BSkE7QUFBQSxNQVFBLENBQUMsQ0FBQyxNQUFGLENBQVMsSUFBQyxRQUFPLENBQUMsY0FBbEIsRUFBa0MsV0FBbEMsQ0FSQTtBQVVBLFVBQUcsS0FBSyxRQUFPLENBQUMsc0JBQWhCO0FBQ0UsWUFBQyxRQUFPLENBQUMsc0JBQVQsR0FBa0M7QUFDaEMsY0FBQyxTQUFRLENBQUMsU0FBVixDQUFvQixHQUFwQixFQUF5QixXQUF6QjtpQkFDQSxJQUFDLEtBQUQsR0FGZ0M7UUFBQSxDQUFsQyxDQURGO09BWEY7S0FyQkE7QUFzQ0EsUUFBRyxJQUFDLFFBQU8sQ0FBQyxPQUFRLEdBQWpCLEtBQXVCLEdBQTFCO0FBQ0UsVUFBQyxRQUFPLENBQUMsT0FBVCxHQUFtQixJQUFDLFFBQU8sQ0FBQyxPQUFPLENBQUMsS0FBakIsQ0FBdUIsQ0FBdkIsQ0FBbkIsQ0FERjtLQXRDQTtBQXdDQSxRQUFHLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxRQUFPLENBQUMsT0FBaEIsTUFBOEIsR0FBakM7QUFDRSxVQUFDLFFBQU8sQ0FBQyxPQUFULEdBQW1CLElBQUMsUUFBTyxDQUFDLE9BQVQsR0FBbUIsR0FBdEMsQ0FERjtLQXhDQTtBQTZDQSxRQUFHLElBQUMsUUFBTyxDQUFDLE9BQVo7QUFDRSxVQUFDLFFBQU8sQ0FBQyxPQUFULElBQW9CLElBQUMsUUFBTyxDQUFDLE9BQVQsR0FBbUIsR0FBdkMsQ0FERjtLQTdDQTtBQWlEQSxRQUFHLElBQUMsUUFBTyxDQUFDLGNBQVo7QUFDRSxVQUFDLFVBQUQsR0FERjtLQUFBLE1BRUssSUFBRyxJQUFDLFFBQU8sQ0FBQyxPQUFaO0FBQ0gsVUFBQyxVQUFEO0FBQUEsTUFDQSxPQUFPLENBQUMsSUFBUixDQUFhLHlFQUNULDZDQURKLENBREEsQ0FERztLQW5ETDtBQXdEQSxXQUFPLElBQVAsQ0F6RFc7RUFBQSxDQUFiOztBQTREQTtBQUFBOzs7Ozs7Ozs7OztLQTVEQTs7QUFBQSxxQkF3RUEsV0FBVSxTQUFDLElBQUQsRUFBTyxPQUFQLEVBQWdCLFNBQWhCO0FBRVI7QUFBQSxZQUFZLFNBQUssQ0FBQyxLQUFOLENBQVksSUFBWixFQUFrQixJQUFsQixFQUF3QixPQUF4QixFQUFpQyxTQUFqQyxDQUFaO0FBQUEsSUFDQSxJQUFDLFFBQU8sQ0FBQyxJQUFULENBQWMsS0FBZCxDQURBO0FBQUEsSUFHQSxLQUFLLENBQUMsUUFBTixFQUhBO0FBS0EsV0FBTyxJQUFQLENBUFE7RUFBQSxDQXhFVjs7QUFrRkE7QUFBQTs7S0FsRkE7O0FBQUEscUJBcUZBLGdCQUFlLFNBQUMsVUFBRCxFQUFhLE9BQWI7QUFDYjs7TUFEMEIsVUFBUTtLQUNsQztBQUFBLGNBQVUsQ0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixLQUFoQixFQUF1QixRQUF2QixFQUFpQyxRQUFqQyxDQUFWO0FBQUEsSUFDQSxzQkFBc0IsQ0FBQyxNQUFELEVBQVMsUUFBVCxDQUR0QjtBQUlBLFFBQUcsZUFBYyxNQUFNLENBQUMsS0FBeEI7QUFDRSw0QkFBc0IsSUFBQyx5QkFBdkIsQ0FERjtLQUFBO0FBR0UsNEJBQXNCLElBQUMscUJBQXZCLENBSEY7S0FKQTtBQUFBLElBVUEsaUNBQWlDLE9BQU8sQ0FBQyxTQUFSLElBQXFCLEVBVnREO0FBQUEsSUFXQSxlQUFlLE9BQU8sQ0FBQyxZQUFSLElBQXdCLEVBWHZDO0FBQUEsSUFZQSxvQkFBb0IsT0FBTyxDQUFDLGlCQUFSLElBQTZCLEVBWmpEO0FBQUEsSUFjQSxPQUFPLE9BQU8sQ0FBQyxJQUFSLElBQWdCLFVBQVUsQ0FBQyxLQWRsQztBQUFBLElBa0JBLDJCQUEyQixFQWxCM0I7QUFBQSxJQW1CQSx1QkFBdUIsRUFuQnZCO0FBb0JBLFFBQUcsQ0FBQyxDQUFDLE9BQUYsQ0FBVSw4QkFBVixLQUE4QyxDQUFDLENBQUMsT0FBRixDQUFVLGlCQUFWLENBQWpEO0FBRUUsT0FBQyxDQUFDLElBQUYsQ0FBTyxPQUFQLEVBQWdCLFNBQUMsTUFBRDtBQUVkLFlBQUcsYUFBVSxtQkFBVixjQUFIO0FBQ0UsV0FBQyxDQUFDLE1BQUYsQ0FBUyx3QkFBVCxFQUFtQyxtQkFBb0IsUUFBTyxDQUFDLElBQTVCLENBQWlDLElBQWpDLEVBQXVDLFVBQXZDLENBQW5DLEVBREY7U0FBQTtBQUVLLFdBQUMsQ0FBQyxNQUFGLENBQVMsb0JBQVQsRUFBK0IsbUJBQW9CLFFBQU8sQ0FBQyxJQUE1QixDQUFpQyxJQUFqQyxFQUF1QyxVQUF2QyxDQUEvQixFQUZMO1NBRmM7TUFBQSxDQUFoQixFQU1FLElBTkYsRUFGRjtLQUFBO0FBV0UsT0FBQyxDQUFDLElBQUYsQ0FBTyxPQUFQLEVBQWdCLFNBQUMsTUFBRDtBQUNkO0FBQUEsWUFBRyxhQUFjLGlCQUFkLGlCQUFvQyw4QkFBK0IsUUFBL0IsS0FBNEMsS0FBbkY7QUFHRSw0QkFBa0IsOEJBQStCLFFBQWpEO0FBQUEsVUFDQSxxQkFBcUIsRUFEckI7QUFBQSxVQUVBLENBQUMsQ0FBQyxJQUFGLENBQU8sbUJBQW9CLFFBQU8sQ0FBQyxJQUE1QixDQUFpQyxJQUFqQyxFQUF1QyxVQUF2QyxDQUFQLEVBQTJELFNBQUMsTUFBRCxFQUFTLFVBQVQ7bUJBQ3pELGtCQUFtQixZQUFuQixHQUNFLENBQUMsQ0FBQyxLQUFGLENBQVEsTUFBUixDQUNBLENBQUMsS0FERCxFQUVBLENBQUMsTUFGRCxDQUVRLGVBRlIsQ0FHQSxDQUFDLEtBSEQsR0FGdUQ7VUFBQSxDQUEzRCxDQUZBO0FBU0EsY0FBRyxhQUFVLG1CQUFWLGNBQUg7QUFDRSxhQUFDLENBQUMsTUFBRixDQUFTLHdCQUFULEVBQW1DLGtCQUFuQyxFQURGO1dBQUE7QUFFSyxhQUFDLENBQUMsTUFBRixDQUFTLG9CQUFULEVBQStCLGtCQUEvQixFQUZMO1dBWkY7U0FEYztNQUFBLENBQWhCLEVBaUJFLElBakJGLEVBWEY7S0FwQkE7QUFBQSxJQW1EQSxJQUFDLFNBQUQsQ0FBVSxJQUFWLEVBQWdCLFlBQWhCLEVBQThCLHdCQUE5QixDQW5EQTtBQUFBLElBb0RBLElBQUMsU0FBRCxDQUFhLElBQUQsR0FBTSxNQUFsQixFQUF5QixZQUF6QixFQUF1QyxvQkFBdkMsQ0FwREE7QUFzREEsV0FBTyxJQUFQLENBdkRhO0VBQUEsQ0FyRmY7O0FBK0lBO0FBQUE7O0tBL0lBOztBQUFBLHFCQWtKQSx1QkFDRTtBQUFBLFNBQUssU0FBQyxVQUFEO2FBQ0g7QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHFCQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLElBQUMsVUFBUyxDQUFDLEVBQTlCLENBQVQ7QUFDQSxnQkFBRyxNQUFIO3FCQUNFO0FBQUEsZ0JBQUMsUUFBUSxTQUFUO0FBQUEsZ0JBQW9CLE1BQU0sTUFBMUI7Z0JBREY7YUFBQTtxQkFHRTtBQUFBLDRCQUFZLEdBQVo7QUFBQSxnQkFDQSxNQUFNO0FBQUEsa0JBQUMsUUFBUSxNQUFUO0FBQUEsa0JBQWlCLFNBQVMsZ0JBQTFCO2lCQUROO2dCQUhGO2FBRk07VUFBQSxDQUFSO1NBREY7UUFERztJQUFBLENBQUw7QUFBQSxJQVNBLEtBQUssU0FBQyxVQUFEO2FBQ0g7QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLDhCQUFrQixVQUFVLENBQUMsTUFBWCxDQUFrQixJQUFDLFVBQVMsQ0FBQyxFQUE3QixFQUFpQyxJQUFDLFdBQWxDLENBQWxCO0FBQ0EsZ0JBQUcsZUFBSDtBQUNFLHVCQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLElBQUMsVUFBUyxDQUFDLEVBQTlCLENBQVQ7cUJBQ0E7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTSxNQUExQjtnQkFGRjthQUFBO3FCQUlFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUyxnQkFBMUI7aUJBRE47Z0JBSkY7YUFGTTtVQUFBLENBQVI7U0FERjtRQURHO0lBQUEsQ0FUTDtBQUFBLElBbUJBLFVBQVEsU0FBQyxVQUFEO2FBQ047QUFBQSxrQkFDRTtBQUFBLGtCQUFRO0FBQ04sZ0JBQUcsVUFBVSxDQUFDLE1BQVgsQ0FBa0IsSUFBQyxVQUFTLENBQUMsRUFBN0IsQ0FBSDtxQkFDRTtBQUFBLGdCQUFDLFFBQVEsU0FBVDtBQUFBLGdCQUFvQixNQUFNO0FBQUEsMkJBQVMsY0FBVDtpQkFBMUI7Z0JBREY7YUFBQTtxQkFHRTtBQUFBLDRCQUFZLEdBQVo7QUFBQSxnQkFDQSxNQUFNO0FBQUEsa0JBQUMsUUFBUSxNQUFUO0FBQUEsa0JBQWlCLFNBQVMsZ0JBQTFCO2lCQUROO2dCQUhGO2FBRE07VUFBQSxDQUFSO1NBREY7UUFETTtJQUFBLENBbkJSO0FBQUEsSUEyQkEsTUFBTSxTQUFDLFVBQUQ7YUFDSjtBQUFBLGNBQ0U7QUFBQSxrQkFBUTtBQUNOO0FBQUEsdUJBQVcsVUFBVSxDQUFDLE1BQVgsQ0FBa0IsSUFBQyxXQUFuQixDQUFYO0FBQUEsWUFDQSxTQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLFFBQW5CLENBRFQ7QUFFQSxnQkFBRyxNQUFIO3FCQUNFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLFNBQVQ7QUFBQSxrQkFBb0IsTUFBTSxNQUExQjtpQkFETjtnQkFERjthQUFBO3FCQUlFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUyxlQUExQjtpQkFETjtnQkFKRjthQUhNO1VBQUEsQ0FBUjtTQURGO1FBREk7SUFBQSxDQTNCTjtBQUFBLElBc0NBLFFBQVEsU0FBQyxVQUFEO2FBQ047QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHVCQUFXLFVBQVUsQ0FBQyxJQUFYLEVBQWlCLENBQUMsS0FBbEIsRUFBWDtBQUNBLGdCQUFHLFFBQUg7cUJBQ0U7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTSxRQUExQjtnQkFERjthQUFBO3FCQUdFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUywwQ0FBMUI7aUJBRE47Z0JBSEY7YUFGTTtVQUFBLENBQVI7U0FERjtRQURNO0lBQUEsQ0F0Q1I7R0FuSkY7O0FBb01BO0FBQUE7O0tBcE1BOztBQUFBLHFCQXVNQSwyQkFDRTtBQUFBLFNBQUssU0FBQyxVQUFEO2FBQ0g7QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHFCQUFTLFVBQVUsQ0FBQyxPQUFYLENBQW1CLElBQUMsVUFBUyxDQUFDLEVBQTlCLEVBQWtDO0FBQUEsc0JBQVE7QUFBQSx5QkFBUyxDQUFUO2VBQVI7YUFBbEMsQ0FBVDtBQUNBLGdCQUFHLE1BQUg7cUJBQ0U7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTSxNQUExQjtnQkFERjthQUFBO3FCQUdFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLE1BQVQ7QUFBQSxrQkFBaUIsU0FBUyxnQkFBMUI7aUJBRE47Z0JBSEY7YUFGTTtVQUFBLENBQVI7U0FERjtRQURHO0lBQUEsQ0FBTDtBQUFBLElBU0EsS0FBSyxTQUFDLFVBQUQ7YUFDSDtBQUFBLGFBQ0U7QUFBQSxrQkFBUTtBQUNOO0FBQUEsOEJBQWtCLFVBQVUsQ0FBQyxNQUFYLENBQWtCLElBQUMsVUFBUyxDQUFDLEVBQTdCLEVBQWlDO0FBQUEsb0JBQU07QUFBQSx5QkFBUyxJQUFDLFdBQVY7ZUFBTjthQUFqQyxDQUFsQjtBQUNBLGdCQUFHLGVBQUg7QUFDRSx1QkFBUyxVQUFVLENBQUMsT0FBWCxDQUFtQixJQUFDLFVBQVMsQ0FBQyxFQUE5QixFQUFrQztBQUFBLHdCQUFRO0FBQUEsMkJBQVMsQ0FBVDtpQkFBUjtlQUFsQyxDQUFUO3FCQUNBO0FBQUEsZ0JBQUMsUUFBUSxTQUFUO0FBQUEsZ0JBQW9CLE1BQU0sTUFBMUI7Z0JBRkY7YUFBQTtxQkFJRTtBQUFBLDRCQUFZLEdBQVo7QUFBQSxnQkFDQSxNQUFNO0FBQUEsa0JBQUMsUUFBUSxNQUFUO0FBQUEsa0JBQWlCLFNBQVMsZ0JBQTFCO2lCQUROO2dCQUpGO2FBRk07VUFBQSxDQUFSO1NBREY7UUFERztJQUFBLENBVEw7QUFBQSxJQW1CQSxVQUFRLFNBQUMsVUFBRDthQUNOO0FBQUEsa0JBQ0U7QUFBQSxrQkFBUTtBQUNOLGdCQUFHLFVBQVUsQ0FBQyxNQUFYLENBQWtCLElBQUMsVUFBUyxDQUFDLEVBQTdCLENBQUg7cUJBQ0U7QUFBQSxnQkFBQyxRQUFRLFNBQVQ7QUFBQSxnQkFBb0IsTUFBTTtBQUFBLDJCQUFTLGNBQVQ7aUJBQTFCO2dCQURGO2FBQUE7cUJBR0U7QUFBQSw0QkFBWSxHQUFaO0FBQUEsZ0JBQ0EsTUFBTTtBQUFBLGtCQUFDLFFBQVEsTUFBVDtBQUFBLGtCQUFpQixTQUFTLGdCQUExQjtpQkFETjtnQkFIRjthQURNO1VBQUEsQ0FBUjtTQURGO1FBRE07SUFBQSxDQW5CUjtBQUFBLElBMkJBLE1BQU0sU0FBQyxVQUFEO2FBQ0o7QUFBQSxjQUNFO0FBQUEsa0JBQVE7QUFFTjtBQUFBLHVCQUFXLFFBQVEsQ0FBQyxVQUFULENBQW9CLElBQUMsV0FBckIsQ0FBWDtBQUFBLFlBQ0EsU0FBUyxVQUFVLENBQUMsT0FBWCxDQUFtQixRQUFuQixFQUE2QjtBQUFBLHNCQUFRO0FBQUEseUJBQVMsQ0FBVDtlQUFSO2FBQTdCLENBRFQ7QUFFQSxnQkFBRyxNQUFIO3FCQUNFO0FBQUEsNEJBQVksR0FBWjtBQUFBLGdCQUNBLE1BQU07QUFBQSxrQkFBQyxRQUFRLFNBQVQ7QUFBQSxrQkFBb0IsTUFBTSxNQUExQjtpQkFETjtnQkFERjthQUFBO0FBSUU7QUFBQSw0QkFBWSxHQUFaO2VBQUE7cUJBQ0E7QUFBQSxnQkFBQyxRQUFRLE1BQVQ7QUFBQSxnQkFBaUIsU0FBUyxlQUExQjtnQkFMRjthQUpNO1VBQUEsQ0FBUjtTQURGO1FBREk7SUFBQSxDQTNCTjtBQUFBLElBdUNBLFFBQVEsU0FBQyxVQUFEO2FBQ047QUFBQSxhQUNFO0FBQUEsa0JBQVE7QUFDTjtBQUFBLHVCQUFXLFVBQVUsQ0FBQyxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUEsc0JBQVE7QUFBQSx5QkFBUyxDQUFUO2VBQVI7YUFBcEIsQ0FBdUMsQ0FBQyxLQUF4QyxFQUFYO0FBQ0EsZ0JBQUcsUUFBSDtxQkFDRTtBQUFBLGdCQUFDLFFBQVEsU0FBVDtBQUFBLGdCQUFvQixNQUFNLFFBQTFCO2dCQURGO2FBQUE7cUJBR0U7QUFBQSw0QkFBWSxHQUFaO0FBQUEsZ0JBQ0EsTUFBTTtBQUFBLGtCQUFDLFFBQVEsTUFBVDtBQUFBLGtCQUFpQixTQUFTLDBCQUExQjtpQkFETjtnQkFIRjthQUZNO1VBQUEsQ0FBUjtTQURGO1FBRE07SUFBQSxDQXZDUjtHQXhNRjs7QUEwUEE7QUFBQTs7S0ExUEE7O0FBQUEscUJBNlBBLFlBQVc7QUFDVDtBQUFBLFdBQU8sSUFBUDtBQUNBO0FBQUE7Ozs7O09BREE7QUFBQSxJQU9BLElBQUMsU0FBRCxDQUFVLE9BQVYsRUFBbUI7QUFBQSxNQUFDLGNBQWMsS0FBZjtLQUFuQixFQUNFO0FBQUEsWUFBTTtBQUVKO0FBQUEsZUFBTyxFQUFQO0FBQ0EsWUFBRyxJQUFDLFdBQVUsQ0FBQyxJQUFmO0FBQ0UsY0FBRyxJQUFDLFdBQVUsQ0FBQyxJQUFJLENBQUMsT0FBakIsQ0FBeUIsR0FBekIsTUFBaUMsRUFBcEM7QUFDRSxnQkFBSSxDQUFDLFFBQUwsR0FBZ0IsSUFBQyxXQUFVLENBQUMsSUFBNUIsQ0FERjtXQUFBO0FBR0UsZ0JBQUksQ0FBQyxLQUFMLEdBQWEsSUFBQyxXQUFVLENBQUMsSUFBekIsQ0FIRjtXQURGO1NBQUEsTUFLSyxJQUFHLElBQUMsV0FBVSxDQUFDLFFBQWY7QUFDSCxjQUFJLENBQUMsUUFBTCxHQUFnQixJQUFDLFdBQVUsQ0FBQyxRQUE1QixDQURHO1NBQUEsTUFFQSxJQUFHLElBQUMsV0FBVSxDQUFDLEtBQWY7QUFDSCxjQUFJLENBQUMsS0FBTCxHQUFhLElBQUMsV0FBVSxDQUFDLEtBQXpCLENBREc7U0FSTDtBQVlBO0FBQ0UsaUJBQU8sSUFBSSxDQUFDLGlCQUFMLENBQXVCLElBQXZCLEVBQTZCLElBQUMsV0FBVSxDQUFDLFFBQXpDLENBQVAsQ0FERjtTQUFBO0FBR0UsVUFESSxVQUNKO0FBQUEsaUJBQ0U7QUFBQSx3QkFBWSxDQUFDLENBQUMsS0FBZDtBQUFBLFlBQ0EsTUFBTTtBQUFBLHNCQUFRLE9BQVI7QUFBQSxjQUFpQixTQUFTLENBQUMsQ0FBQyxNQUE1QjthQUROO1dBREYsQ0FIRjtTQVpBO0FBcUJBLFlBQUcsSUFBSSxDQUFDLE1BQUwsSUFBZ0IsSUFBSSxDQUFDLFNBQXhCO0FBQ0Usd0JBQWMsRUFBZDtBQUFBLFVBQ0EsV0FBWSxLQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFsQixDQUFaLEdBQXVDLFFBQVEsQ0FBQyxlQUFULENBQXlCLElBQUksQ0FBQyxTQUE5QixDQUR2QztBQUFBLFVBRUEsSUFBQyxLQUFELEdBQVEsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFiLENBQ047QUFBQSxtQkFBTyxJQUFJLENBQUMsTUFBWjtXQURNLEVBRU4sV0FGTSxDQUZSO0FBQUEsVUFLQSxJQUFDLE9BQUQsa0NBQWUsQ0FBRSxZQUxqQixDQURGO1NBckJBO0FBQUEsUUE2QkEsV0FBVztBQUFBLFVBQUMsUUFBUSxTQUFUO0FBQUEsVUFBb0IsTUFBTSxJQUExQjtTQTdCWDtBQUFBLFFBZ0NBLDJEQUFtQyxDQUFFLElBQXpCLENBQThCLElBQTlCLFVBaENaO0FBaUNBLFlBQUcsaUJBQUg7QUFDRSxXQUFDLENBQUMsTUFBRixDQUFTLFFBQVEsQ0FBQyxJQUFsQixFQUF3QjtBQUFBLFlBQUMsT0FBTyxTQUFSO1dBQXhCLEVBREY7U0FqQ0E7ZUFvQ0EsU0F0Q0k7TUFBQSxDQUFOO0tBREYsQ0FQQTtBQUFBLElBZ0RBLFNBQVM7QUFFUDtBQUFBLGtCQUFZLElBQUMsUUFBTyxDQUFDLE9BQVEsZ0JBQTdCO0FBQUEsTUFDQSxjQUFjLFFBQVEsQ0FBQyxlQUFULENBQXlCLFNBQXpCLENBRGQ7QUFBQSxNQUVBLGdCQUFnQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUZsQztBQUFBLE1BR0EsUUFBUSxhQUFhLENBQUMsV0FBZCxDQUEwQixHQUExQixDQUhSO0FBQUEsTUFJQSxZQUFZLGFBQWEsQ0FBQyxTQUFkLENBQXdCLENBQXhCLEVBQTJCLEtBQTNCLENBSlo7QUFBQSxNQUtBLGlCQUFpQixhQUFhLENBQUMsU0FBZCxDQUF3QixRQUFRLENBQWhDLENBTGpCO0FBQUEsTUFNQSxnQkFBZ0IsRUFOaEI7QUFBQSxNQU9BLGFBQWMsZ0JBQWQsR0FBZ0MsV0FQaEM7QUFBQSxNQVFBLG9CQUFvQixFQVJwQjtBQUFBLE1BU0EsaUJBQWtCLFdBQWxCLEdBQStCLGFBVC9CO0FBQUEsTUFVQSxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQWIsQ0FBb0IsSUFBQyxLQUFJLENBQUMsR0FBMUIsRUFBK0I7QUFBQSxRQUFDLE9BQU8saUJBQVI7T0FBL0IsQ0FWQTtBQUFBLE1BWUEsV0FBVztBQUFBLFFBQUMsUUFBUSxTQUFUO0FBQUEsUUFBb0IsTUFBTTtBQUFBLFVBQUMsU0FBUywwQkFBVjtTQUExQjtPQVpYO0FBQUEsTUFlQSwwREFBb0MsQ0FBRSxJQUExQixDQUErQixJQUEvQixVQWZaO0FBZ0JBLFVBQUcsaUJBQUg7QUFDRSxTQUFDLENBQUMsTUFBRixDQUFTLFFBQVEsQ0FBQyxJQUFsQixFQUF3QjtBQUFBLFVBQUMsT0FBTyxTQUFSO1NBQXhCLEVBREY7T0FoQkE7YUFtQkEsU0FyQk87SUFBQSxDQWhEVDtBQXVFQTtBQUFBOzs7OztPQXZFQTtXQTZFQSxJQUFDLFNBQUQsQ0FBVSxRQUFWLEVBQW9CO0FBQUEsTUFBQyxjQUFjLElBQWY7S0FBcEIsRUFDRTtBQUFBLFdBQUs7QUFDSCxlQUFPLENBQUMsSUFBUixDQUFhLHFGQUFiO0FBQUEsUUFDQSxPQUFPLENBQUMsSUFBUixDQUFhLCtEQUFiLENBREE7QUFFQSxlQUFPLE1BQU0sQ0FBQyxJQUFQLENBQVksSUFBWixDQUFQLENBSEc7TUFBQSxDQUFMO0FBQUEsTUFJQSxNQUFNLE1BSk47S0FERixFQTlFUztFQUFBLENBN1BYOztrQkFBQTs7SUFGRjs7QUFBQSxRQW9WQSxHQUFXLElBQUMsU0FwVloiLCJmaWxlIjoiL3BhY2thZ2VzL25pbWJsZV9yZXN0aXZ1cy5qcyIsInNvdXJjZXNDb250ZW50IjpbIkBBdXRoIG9yPSB7fVxuXG4jIyNcbiAgQSB2YWxpZCB1c2VyIHdpbGwgaGF2ZSBleGFjdGx5IG9uZSBvZiB0aGUgZm9sbG93aW5nIGlkZW50aWZpY2F0aW9uIGZpZWxkczogaWQsIHVzZXJuYW1lLCBvciBlbWFpbFxuIyMjXG51c2VyVmFsaWRhdG9yID0gTWF0Y2guV2hlcmUgKHVzZXIpIC0+XG4gIGNoZWNrIHVzZXIsXG4gICAgaWQ6IE1hdGNoLk9wdGlvbmFsIFN0cmluZ1xuICAgIHVzZXJuYW1lOiBNYXRjaC5PcHRpb25hbCBTdHJpbmdcbiAgICBlbWFpbDogTWF0Y2guT3B0aW9uYWwgU3RyaW5nXG5cbiAgaWYgXy5rZXlzKHVzZXIpLmxlbmd0aCBpcyBub3QgMVxuICAgIHRocm93IG5ldyBNYXRjaC5FcnJvciAnVXNlciBtdXN0IGhhdmUgZXhhY3RseSBvbmUgaWRlbnRpZmllciBmaWVsZCdcblxuICByZXR1cm4gdHJ1ZVxuXG5cbiMjI1xuICBSZXR1cm4gYSBNb25nb0RCIHF1ZXJ5IHNlbGVjdG9yIGZvciBmaW5kaW5nIHRoZSBnaXZlbiB1c2VyXG4jIyNcbmdldFVzZXJRdWVyeVNlbGVjdG9yID0gKHVzZXIpIC0+XG4gIGlmIHVzZXIuaWRcbiAgICByZXR1cm4geydfaWQnOiB1c2VyLmlkfVxuICBlbHNlIGlmIHVzZXIudXNlcm5hbWVcbiAgICByZXR1cm4geyd1c2VybmFtZSc6IHVzZXIudXNlcm5hbWV9XG4gIGVsc2UgaWYgdXNlci5lbWFpbFxuICAgIHJldHVybiB7J2VtYWlscy5hZGRyZXNzJzogdXNlci5lbWFpbH1cblxuICAjIFdlIHNob3VsZG4ndCBiZSBoZXJlIGlmIHRoZSB1c2VyIG9iamVjdCB3YXMgcHJvcGVybHkgdmFsaWRhdGVkXG4gIHRocm93IG5ldyBFcnJvciAnQ2Fubm90IGNyZWF0ZSBzZWxlY3RvciBmcm9tIGludmFsaWQgdXNlcidcblxuXG4jIyNcbiAgTG9nIGEgdXNlciBpbiB3aXRoIHRoZWlyIHBhc3N3b3JkXG4jIyNcbkBBdXRoLmxvZ2luV2l0aFBhc3N3b3JkID0gKHVzZXIsIHBhc3N3b3JkKSAtPlxuICBpZiBub3QgdXNlciBvciBub3QgcGFzc3dvcmRcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIDQwMSwgJ1VuYXV0aG9yaXplZCdcblxuICAjIFZhbGlkYXRlIHRoZSBsb2dpbiBpbnB1dCB0eXBlc1xuICBjaGVjayB1c2VyLCB1c2VyVmFsaWRhdG9yXG4gIGNoZWNrIHBhc3N3b3JkLCBTdHJpbmdcblxuICAjIFJldHJpZXZlIHRoZSB1c2VyIGZyb20gdGhlIGRhdGFiYXNlXG4gIGF1dGhlbnRpY2F0aW5nVXNlclNlbGVjdG9yID0gZ2V0VXNlclF1ZXJ5U2VsZWN0b3IodXNlcilcbiAgYXV0aGVudGljYXRpbmdVc2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoYXV0aGVudGljYXRpbmdVc2VyU2VsZWN0b3IpXG5cbiAgaWYgbm90IGF1dGhlbnRpY2F0aW5nVXNlclxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IgNDAxLCAnVW5hdXRob3JpemVkJ1xuICBpZiBub3QgYXV0aGVudGljYXRpbmdVc2VyLnNlcnZpY2VzPy5wYXNzd29yZFxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IgNDAxLCAnVW5hdXRob3JpemVkJ1xuXG4gICMgQXV0aGVudGljYXRlIHRoZSB1c2VyJ3MgcGFzc3dvcmRcbiAgcGFzc3dvcmRWZXJpZmljYXRpb24gPSBBY2NvdW50cy5fY2hlY2tQYXNzd29yZCBhdXRoZW50aWNhdGluZ1VzZXIsIHBhc3N3b3JkXG4gIGlmIHBhc3N3b3JkVmVyaWZpY2F0aW9uLmVycm9yXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciA0MDEsICdVbmF1dGhvcml6ZWQnXG5cbiAgIyBBZGQgYSBuZXcgYXV0aCB0b2tlbiB0byB0aGUgdXNlcidzIGFjY291bnRcbiAgYXV0aFRva2VuID0gQWNjb3VudHMuX2dlbmVyYXRlU3RhbXBlZExvZ2luVG9rZW4oKVxuICBoYXNoZWRUb2tlbiA9IEFjY291bnRzLl9oYXNoTG9naW5Ub2tlbiBhdXRoVG9rZW4udG9rZW5cbiAgQWNjb3VudHMuX2luc2VydEhhc2hlZExvZ2luVG9rZW4gYXV0aGVudGljYXRpbmdVc2VyLl9pZCwge2hhc2hlZFRva2VufVxuXG4gIHJldHVybiB7YXV0aFRva2VuOiBhdXRoVG9rZW4udG9rZW4sIHVzZXJJZDogYXV0aGVudGljYXRpbmdVc2VyLl9pZH1cbiIsImNsYXNzIHNoYXJlLlJvdXRlXG5cbiAgY29uc3RydWN0b3I6IChAYXBpLCBAcGF0aCwgQG9wdGlvbnMsIEBlbmRwb2ludHMpIC0+XG4gICAgIyBDaGVjayBpZiBvcHRpb25zIHdlcmUgcHJvdmlkZWRcbiAgICBpZiBub3QgQGVuZHBvaW50c1xuICAgICAgQGVuZHBvaW50cyA9IEBvcHRpb25zXG4gICAgICBAb3B0aW9ucyA9IHt9XG5cblxuICBhZGRUb0FwaTogZG8gLT5cbiAgICBhdmFpbGFibGVNZXRob2RzID0gWydnZXQnLCAncG9zdCcsICdwdXQnLCAncGF0Y2gnLCAnZGVsZXRlJywgJ29wdGlvbnMnXVxuXG4gICAgcmV0dXJuIC0+XG4gICAgICBzZWxmID0gdGhpc1xuXG4gICAgICAjIFRocm93IGFuIGVycm9yIGlmIGEgcm91dGUgaGFzIGFscmVhZHkgYmVlbiBhZGRlZCBhdCB0aGlzIHBhdGhcbiAgICAgICMgVE9ETzogQ2hlY2sgZm9yIGNvbGxpc2lvbnMgd2l0aCBwYXRocyB0aGF0IGZvbGxvdyBzYW1lIHBhdHRlcm4gd2l0aCBkaWZmZXJlbnQgcGFyYW1ldGVyIG5hbWVzXG4gICAgICBpZiBfLmNvbnRhaW5zIEBhcGkuX2NvbmZpZy5wYXRocywgQHBhdGhcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yIFwiQ2Fubm90IGFkZCBhIHJvdXRlIGF0IGFuIGV4aXN0aW5nIHBhdGg6ICN7QHBhdGh9XCJcblxuICAgICAgIyBPdmVycmlkZSB0aGUgZGVmYXVsdCBPUFRJT05TIGVuZHBvaW50IHdpdGggb3VyIG93blxuICAgICAgQGVuZHBvaW50cyA9IF8uZXh0ZW5kIG9wdGlvbnM6IEBhcGkuX2NvbmZpZy5kZWZhdWx0T3B0aW9uc0VuZHBvaW50LCBAZW5kcG9pbnRzXG5cbiAgICAgICMgQ29uZmlndXJlIGVhY2ggZW5kcG9pbnQgb24gdGhpcyByb3V0ZVxuICAgICAgQF9yZXNvbHZlRW5kcG9pbnRzKClcbiAgICAgIEBfY29uZmlndXJlRW5kcG9pbnRzKClcblxuICAgICAgIyBBZGQgdG8gb3VyIGxpc3Qgb2YgZXhpc3RpbmcgcGF0aHNcbiAgICAgIEBhcGkuX2NvbmZpZy5wYXRocy5wdXNoIEBwYXRoXG5cbiAgICAgIGFsbG93ZWRNZXRob2RzID0gXy5maWx0ZXIgYXZhaWxhYmxlTWV0aG9kcywgKG1ldGhvZCkgLT5cbiAgICAgICAgXy5jb250YWlucyhfLmtleXMoc2VsZi5lbmRwb2ludHMpLCBtZXRob2QpXG4gICAgICByZWplY3RlZE1ldGhvZHMgPSBfLnJlamVjdCBhdmFpbGFibGVNZXRob2RzLCAobWV0aG9kKSAtPlxuICAgICAgICBfLmNvbnRhaW5zKF8ua2V5cyhzZWxmLmVuZHBvaW50cyksIG1ldGhvZClcblxuICAgICAgIyBTZXR1cCBlbmRwb2ludHMgb24gcm91dGVcbiAgICAgIGZ1bGxQYXRoID0gQGFwaS5fY29uZmlnLmFwaVBhdGggKyBAcGF0aFxuICAgICAgXy5lYWNoIGFsbG93ZWRNZXRob2RzLCAobWV0aG9kKSAtPlxuICAgICAgICBlbmRwb2ludCA9IHNlbGYuZW5kcG9pbnRzW21ldGhvZF1cbiAgICAgICAgSnNvblJvdXRlcy5hZGQgbWV0aG9kLCBmdWxsUGF0aCwgKHJlcSwgcmVzKSAtPlxuICAgICAgICAgICMgQWRkIGZ1bmN0aW9uIHRvIGVuZHBvaW50IGNvbnRleHQgZm9yIGluZGljYXRpbmcgYSByZXNwb25zZSBoYXMgYmVlbiBpbml0aWF0ZWQgbWFudWFsbHlcbiAgICAgICAgICByZXNwb25zZUluaXRpYXRlZCA9IGZhbHNlXG4gICAgICAgICAgZG9uZUZ1bmMgPSAtPlxuICAgICAgICAgICAgcmVzcG9uc2VJbml0aWF0ZWQgPSB0cnVlXG5cbiAgICAgICAgICBlbmRwb2ludENvbnRleHQgPVxuICAgICAgICAgICAgdXJsUGFyYW1zOiByZXEucGFyYW1zXG4gICAgICAgICAgICBxdWVyeVBhcmFtczogcmVxLnF1ZXJ5XG4gICAgICAgICAgICBib2R5UGFyYW1zOiByZXEuYm9keVxuICAgICAgICAgICAgcmVxdWVzdDogcmVxXG4gICAgICAgICAgICByZXNwb25zZTogcmVzXG4gICAgICAgICAgICBkb25lOiBkb25lRnVuY1xuICAgICAgICAgICMgQWRkIGVuZHBvaW50IGNvbmZpZyBvcHRpb25zIHRvIGNvbnRleHRcbiAgICAgICAgICBfLmV4dGVuZCBlbmRwb2ludENvbnRleHQsIGVuZHBvaW50XG5cbiAgICAgICAgICAjIFJ1biB0aGUgcmVxdWVzdGVkIGVuZHBvaW50XG4gICAgICAgICAgcmVzcG9uc2VEYXRhID0gbnVsbFxuICAgICAgICAgIHRyeVxuICAgICAgICAgICAgcmVzcG9uc2VEYXRhID0gc2VsZi5fY2FsbEVuZHBvaW50IGVuZHBvaW50Q29udGV4dCwgZW5kcG9pbnRcbiAgICAgICAgICBjYXRjaCBlcnJvclxuICAgICAgICAgICAgIyBEbyBleGFjdGx5IHdoYXQgSXJvbiBSb3V0ZXIgd291bGQgaGF2ZSBkb25lLCB0byBhdm9pZCBjaGFuZ2luZyB0aGUgQVBJXG4gICAgICAgICAgICBpcm9uUm91dGVyU2VuZEVycm9yVG9SZXNwb25zZShlcnJvciwgcmVxLCByZXMpO1xuICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgICBpZiByZXNwb25zZUluaXRpYXRlZFxuICAgICAgICAgICAgIyBFbnN1cmUgdGhlIHJlc3BvbnNlIGlzIHByb3Blcmx5IGNvbXBsZXRlZFxuICAgICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBpZiByZXMuaGVhZGVyc1NlbnRcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yIFwiTXVzdCBjYWxsIHRoaXMuZG9uZSgpIGFmdGVyIGhhbmRsaW5nIGVuZHBvaW50IHJlc3BvbnNlIG1hbnVhbGx5OiAje21ldGhvZH0gI3tmdWxsUGF0aH1cIlxuICAgICAgICAgICAgZWxzZSBpZiByZXNwb25zZURhdGEgaXMgbnVsbCBvciByZXNwb25zZURhdGEgaXMgdW5kZWZpbmVkXG4gICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvciBcIkNhbm5vdCByZXR1cm4gbnVsbCBvciB1bmRlZmluZWQgZnJvbSBhbiBlbmRwb2ludDogI3ttZXRob2R9ICN7ZnVsbFBhdGh9XCJcblxuICAgICAgICAgICMgR2VuZXJhdGUgYW5kIHJldHVybiB0aGUgaHR0cCByZXNwb25zZSwgaGFuZGxpbmcgdGhlIGRpZmZlcmVudCBlbmRwb2ludCByZXNwb25zZSB0eXBlc1xuICAgICAgICAgIGlmIHJlc3BvbnNlRGF0YS5ib2R5IGFuZCAocmVzcG9uc2VEYXRhLnN0YXR1c0NvZGUgb3IgcmVzcG9uc2VEYXRhLmhlYWRlcnMpXG4gICAgICAgICAgICBzZWxmLl9yZXNwb25kIHJlcywgcmVzcG9uc2VEYXRhLmJvZHksIHJlc3BvbnNlRGF0YS5zdGF0dXNDb2RlLCByZXNwb25zZURhdGEuaGVhZGVyc1xuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHNlbGYuX3Jlc3BvbmQgcmVzLCByZXNwb25zZURhdGFcblxuICAgICAgXy5lYWNoIHJlamVjdGVkTWV0aG9kcywgKG1ldGhvZCkgLT5cbiAgICAgICAgSnNvblJvdXRlcy5hZGQgbWV0aG9kLCBmdWxsUGF0aCwgKHJlcSwgcmVzKSAtPlxuICAgICAgICAgIHJlc3BvbnNlRGF0YSA9IHN0YXR1czogJ2Vycm9yJywgbWVzc2FnZTogJ0FQSSBlbmRwb2ludCBkb2VzIG5vdCBleGlzdCdcbiAgICAgICAgICBoZWFkZXJzID0gJ0FsbG93JzogYWxsb3dlZE1ldGhvZHMuam9pbignLCAnKS50b1VwcGVyQ2FzZSgpXG4gICAgICAgICAgc2VsZi5fcmVzcG9uZCByZXMsIHJlc3BvbnNlRGF0YSwgNDA1LCBoZWFkZXJzXG5cblxuICAjIyNcbiAgICBDb252ZXJ0IGFsbCBlbmRwb2ludHMgb24gdGhlIGdpdmVuIHJvdXRlIGludG8gb3VyIGV4cGVjdGVkIGVuZHBvaW50IG9iamVjdCBpZiBpdCBpcyBhIGJhcmVcbiAgICBmdW5jdGlvblxuXG4gICAgQHBhcmFtIHtSb3V0ZX0gcm91dGUgVGhlIHJvdXRlIHRoZSBlbmRwb2ludHMgYmVsb25nIHRvXG4gICMjI1xuICBfcmVzb2x2ZUVuZHBvaW50czogLT5cbiAgICBfLmVhY2ggQGVuZHBvaW50cywgKGVuZHBvaW50LCBtZXRob2QsIGVuZHBvaW50cykgLT5cbiAgICAgIGlmIF8uaXNGdW5jdGlvbihlbmRwb2ludClcbiAgICAgICAgZW5kcG9pbnRzW21ldGhvZF0gPSB7YWN0aW9uOiBlbmRwb2ludH1cbiAgICByZXR1cm5cblxuXG4gICMjI1xuICAgIENvbmZpZ3VyZSB0aGUgYXV0aGVudGljYXRpb24gYW5kIHJvbGUgcmVxdWlyZW1lbnQgb24gYWxsIGVuZHBvaW50cyAoZXhjZXB0IE9QVElPTlMsIHdoaWNoIG11c3RcbiAgICBiZSBjb25maWd1cmVkIGRpcmVjdGx5IG9uIHRoZSBlbmRwb2ludClcblxuICAgIEF1dGhlbnRpY2F0aW9uIGNhbiBiZSByZXF1aXJlZCBvbiBhbiBlbnRpcmUgcm91dGUgb3IgaW5kaXZpZHVhbCBlbmRwb2ludHMuIElmIHJlcXVpcmVkIG9uIGFuXG4gICAgZW50aXJlIHJvdXRlLCB0aGF0IHNlcnZlcyBhcyB0aGUgZGVmYXVsdC4gSWYgcmVxdWlyZWQgaW4gYW55IGluZGl2aWR1YWwgZW5kcG9pbnRzLCB0aGF0IHdpbGxcbiAgICBvdmVycmlkZSB0aGUgZGVmYXVsdC5cblxuICAgIEFmdGVyIHRoZSBlbmRwb2ludCBpcyBjb25maWd1cmVkLCBhbGwgYXV0aGVudGljYXRpb24gYW5kIHJvbGUgcmVxdWlyZW1lbnRzIG9mIGFuIGVuZHBvaW50IGNhbiBiZVxuICAgIGFjY2Vzc2VkIGF0IDxjb2RlPmVuZHBvaW50LmF1dGhSZXF1aXJlZDwvY29kZT4gYW5kIDxjb2RlPmVuZHBvaW50LnJvbGVSZXF1aXJlZDwvY29kZT4sXG4gICAgcmVzcGVjdGl2ZWx5LlxuXG4gICAgQHBhcmFtIHtSb3V0ZX0gcm91dGUgVGhlIHJvdXRlIHRoZSBlbmRwb2ludHMgYmVsb25nIHRvXG4gICAgQHBhcmFtIHtFbmRwb2ludH0gZW5kcG9pbnQgVGhlIGVuZHBvaW50IHRvIGNvbmZpZ3VyZVxuICAjIyNcbiAgX2NvbmZpZ3VyZUVuZHBvaW50czogLT5cbiAgICBfLmVhY2ggQGVuZHBvaW50cywgKGVuZHBvaW50LCBtZXRob2QpIC0+XG4gICAgICBpZiBtZXRob2QgaXNudCAnb3B0aW9ucydcbiAgICAgICAgIyBDb25maWd1cmUgYWNjZXB0YWJsZSByb2xlc1xuICAgICAgICBpZiBub3QgQG9wdGlvbnM/LnJvbGVSZXF1aXJlZFxuICAgICAgICAgIEBvcHRpb25zLnJvbGVSZXF1aXJlZCA9IFtdXG4gICAgICAgIGlmIG5vdCBlbmRwb2ludC5yb2xlUmVxdWlyZWRcbiAgICAgICAgICBlbmRwb2ludC5yb2xlUmVxdWlyZWQgPSBbXVxuICAgICAgICBlbmRwb2ludC5yb2xlUmVxdWlyZWQgPSBfLnVuaW9uIGVuZHBvaW50LnJvbGVSZXF1aXJlZCwgQG9wdGlvbnMucm9sZVJlcXVpcmVkXG4gICAgICAgICMgTWFrZSBpdCBlYXNpZXIgdG8gY2hlY2sgaWYgbm8gcm9sZXMgYXJlIHJlcXVpcmVkXG4gICAgICAgIGlmIF8uaXNFbXB0eSBlbmRwb2ludC5yb2xlUmVxdWlyZWRcbiAgICAgICAgICBlbmRwb2ludC5yb2xlUmVxdWlyZWQgPSBmYWxzZVxuXG4gICAgICAgICMgQ29uZmlndXJlIGF1dGggcmVxdWlyZW1lbnRcbiAgICAgICAgaWYgZW5kcG9pbnQuYXV0aFJlcXVpcmVkIGlzIHVuZGVmaW5lZFxuICAgICAgICAgIGlmIEBvcHRpb25zPy5hdXRoUmVxdWlyZWQgb3IgZW5kcG9pbnQucm9sZVJlcXVpcmVkXG4gICAgICAgICAgICBlbmRwb2ludC5hdXRoUmVxdWlyZWQgPSB0cnVlXG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgZW5kcG9pbnQuYXV0aFJlcXVpcmVkID0gZmFsc2VcbiAgICAgICAgcmV0dXJuXG4gICAgLCB0aGlzXG4gICAgcmV0dXJuXG5cblxuICAjIyNcbiAgICBBdXRoZW50aWNhdGUgYW4gZW5kcG9pbnQgaWYgcmVxdWlyZWQsIGFuZCByZXR1cm4gdGhlIHJlc3VsdCBvZiBjYWxsaW5nIGl0XG5cbiAgICBAcmV0dXJucyBUaGUgZW5kcG9pbnQgcmVzcG9uc2Ugb3IgYSA0MDEgaWYgYXV0aGVudGljYXRpb24gZmFpbHNcbiAgIyMjXG4gIF9jYWxsRW5kcG9pbnQ6IChlbmRwb2ludENvbnRleHQsIGVuZHBvaW50KSAtPlxuICAgICMgQ2FsbCB0aGUgZW5kcG9pbnQgaWYgYXV0aGVudGljYXRpb24gZG9lc24ndCBmYWlsXG4gICAgaWYgQF9hdXRoQWNjZXB0ZWQgZW5kcG9pbnRDb250ZXh0LCBlbmRwb2ludFxuICAgICAgaWYgQF9yb2xlQWNjZXB0ZWQgZW5kcG9pbnRDb250ZXh0LCBlbmRwb2ludFxuICAgICAgICBlbmRwb2ludC5hY3Rpb24uY2FsbCBlbmRwb2ludENvbnRleHRcbiAgICAgIGVsc2VcbiAgICAgICAgc3RhdHVzQ29kZTogNDAzXG4gICAgICAgIGJvZHk6IHtzdGF0dXM6ICdlcnJvcicsIG1lc3NhZ2U6ICdZb3UgZG8gbm90IGhhdmUgcGVybWlzc2lvbiB0byBkbyB0aGlzLid9XG4gICAgZWxzZVxuICAgICAgc3RhdHVzQ29kZTogNDAxXG4gICAgICBib2R5OiB7c3RhdHVzOiAnZXJyb3InLCBtZXNzYWdlOiAnWW91IG11c3QgYmUgbG9nZ2VkIGluIHRvIGRvIHRoaXMuJ31cblxuXG4gICMjI1xuICAgIEF1dGhlbnRpY2F0ZSB0aGUgZ2l2ZW4gZW5kcG9pbnQgaWYgcmVxdWlyZWRcblxuICAgIE9uY2UgaXQncyBnbG9iYWxseSBjb25maWd1cmVkIGluIHRoZSBBUEksIGF1dGhlbnRpY2F0aW9uIGNhbiBiZSByZXF1aXJlZCBvbiBhbiBlbnRpcmUgcm91dGUgb3JcbiAgICBpbmRpdmlkdWFsIGVuZHBvaW50cy4gSWYgcmVxdWlyZWQgb24gYW4gZW50aXJlIGVuZHBvaW50LCB0aGF0IHNlcnZlcyBhcyB0aGUgZGVmYXVsdC4gSWYgcmVxdWlyZWRcbiAgICBpbiBhbnkgaW5kaXZpZHVhbCBlbmRwb2ludHMsIHRoYXQgd2lsbCBvdmVycmlkZSB0aGUgZGVmYXVsdC5cblxuICAgIEByZXR1cm5zIEZhbHNlIGlmIGF1dGhlbnRpY2F0aW9uIGZhaWxzLCBhbmQgdHJ1ZSBvdGhlcndpc2VcbiAgIyMjXG4gIF9hdXRoQWNjZXB0ZWQ6IChlbmRwb2ludENvbnRleHQsIGVuZHBvaW50KSAtPlxuICAgIGlmIGVuZHBvaW50LmF1dGhSZXF1aXJlZFxuICAgICAgQF9hdXRoZW50aWNhdGUgZW5kcG9pbnRDb250ZXh0XG4gICAgZWxzZSB0cnVlXG5cblxuICAjIyNcbiAgICBWZXJpZnkgdGhlIHJlcXVlc3QgaXMgYmVpbmcgbWFkZSBieSBhbiBhY3RpdmVseSBsb2dnZWQgaW4gdXNlclxuXG4gICAgSWYgdmVyaWZpZWQsIGF0dGFjaCB0aGUgYXV0aGVudGljYXRlZCB1c2VyIHRvIHRoZSBjb250ZXh0LlxuXG4gICAgQHJldHVybnMge0Jvb2xlYW59IFRydWUgaWYgdGhlIGF1dGhlbnRpY2F0aW9uIHdhcyBzdWNjZXNzZnVsXG4gICMjI1xuICBfYXV0aGVudGljYXRlOiAoZW5kcG9pbnRDb250ZXh0KSAtPlxuICAgICMgR2V0IGF1dGggaW5mb1xuICAgIGF1dGggPSBAYXBpLl9jb25maWcuYXV0aC51c2VyLmNhbGwoZW5kcG9pbnRDb250ZXh0KVxuXG4gICAgIyBHZXQgdGhlIHVzZXIgZnJvbSB0aGUgZGF0YWJhc2VcbiAgICBpZiBhdXRoPy51c2VySWQgYW5kIGF1dGg/LnRva2VuIGFuZCBub3QgYXV0aD8udXNlclxuICAgICAgdXNlclNlbGVjdG9yID0ge31cbiAgICAgIHVzZXJTZWxlY3Rvci5faWQgPSBhdXRoLnVzZXJJZFxuICAgICAgdXNlclNlbGVjdG9yW0BhcGkuX2NvbmZpZy5hdXRoLnRva2VuXSA9IGF1dGgudG9rZW5cbiAgICAgIGF1dGgudXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lIHVzZXJTZWxlY3RvclxuXG4gICAgIyBBdHRhY2ggdGhlIHVzZXIgYW5kIHRoZWlyIElEIHRvIHRoZSBjb250ZXh0IGlmIHRoZSBhdXRoZW50aWNhdGlvbiB3YXMgc3VjY2Vzc2Z1bFxuICAgIGlmIGF1dGg/LnVzZXJcbiAgICAgIGVuZHBvaW50Q29udGV4dC51c2VyID0gYXV0aC51c2VyXG4gICAgICBlbmRwb2ludENvbnRleHQudXNlcklkID0gYXV0aC51c2VyLl9pZFxuICAgICAgdHJ1ZVxuICAgIGVsc2UgZmFsc2VcblxuXG4gICMjI1xuICAgIEF1dGhlbnRpY2F0ZSB0aGUgdXNlciByb2xlIGlmIHJlcXVpcmVkXG5cbiAgICBNdXN0IGJlIGNhbGxlZCBhZnRlciBfYXV0aEFjY2VwdGVkKCkuXG5cbiAgICBAcmV0dXJucyBUcnVlIGlmIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIgYmVsb25ncyB0byA8aT5hbnk8L2k+IG9mIHRoZSBhY2NlcHRhYmxlIHJvbGVzIG9uIHRoZVxuICAgICAgICAgICAgIGVuZHBvaW50XG4gICMjI1xuICBfcm9sZUFjY2VwdGVkOiAoZW5kcG9pbnRDb250ZXh0LCBlbmRwb2ludCkgLT5cbiAgICBpZiBlbmRwb2ludC5yb2xlUmVxdWlyZWRcbiAgICAgIGlmIF8uaXNFbXB0eSBfLmludGVyc2VjdGlvbihlbmRwb2ludC5yb2xlUmVxdWlyZWQsIGVuZHBvaW50Q29udGV4dC51c2VyLnJvbGVzKVxuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICB0cnVlXG5cblxuICAjIyNcbiAgICBSZXNwb25kIHRvIGFuIEhUVFAgcmVxdWVzdFxuICAjIyNcbiAgX3Jlc3BvbmQ6IChyZXNwb25zZSwgYm9keSwgc3RhdHVzQ29kZT0yMDAsIGhlYWRlcnM9e30pIC0+XG4gICAgIyBPdmVycmlkZSBhbnkgZGVmYXVsdCBoZWFkZXJzIHRoYXQgaGF2ZSBiZWVuIHByb3ZpZGVkIChrZXlzIGFyZSBub3JtYWxpemVkIHRvIGJlIGNhc2UgaW5zZW5zaXRpdmUpXG4gICAgIyBUT0RPOiBDb25zaWRlciBvbmx5IGxvd2VyY2FzaW5nIHRoZSBoZWFkZXIga2V5cyB3ZSBuZWVkIG5vcm1hbGl6ZWQsIGxpa2UgQ29udGVudC1UeXBlXG4gICAgZGVmYXVsdEhlYWRlcnMgPSBAX2xvd2VyQ2FzZUtleXMgQGFwaS5fY29uZmlnLmRlZmF1bHRIZWFkZXJzXG4gICAgaGVhZGVycyA9IEBfbG93ZXJDYXNlS2V5cyBoZWFkZXJzXG4gICAgaGVhZGVycyA9IF8uZXh0ZW5kIGRlZmF1bHRIZWFkZXJzLCBoZWFkZXJzXG5cbiAgICAjIFByZXBhcmUgSlNPTiBib2R5IGZvciByZXNwb25zZSB3aGVuIENvbnRlbnQtVHlwZSBpbmRpY2F0ZXMgSlNPTiB0eXBlXG4gICAgaWYgaGVhZGVyc1snY29udGVudC10eXBlJ10ubWF0Y2goL2pzb258amF2YXNjcmlwdC8pIGlzbnQgbnVsbFxuICAgICAgaWYgQGFwaS5fY29uZmlnLnByZXR0eUpzb25cbiAgICAgICAgYm9keSA9IEpTT04uc3RyaW5naWZ5IGJvZHksIHVuZGVmaW5lZCwgMlxuICAgICAgZWxzZVxuICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkgYm9keVxuXG4gICAgIyBTZW5kIHJlc3BvbnNlXG4gICAgc2VuZFJlc3BvbnNlID0gLT5cbiAgICAgIHJlc3BvbnNlLndyaXRlSGVhZCBzdGF0dXNDb2RlLCBoZWFkZXJzXG4gICAgICByZXNwb25zZS53cml0ZSBib2R5XG4gICAgICByZXNwb25zZS5lbmQoKVxuICAgIGlmIHN0YXR1c0NvZGUgaW4gWzQwMSwgNDAzXVxuICAgICAgIyBIYWNrZXJzIGNhbiBtZWFzdXJlIHRoZSByZXNwb25zZSB0aW1lIHRvIGRldGVybWluZSB0aGluZ3MgbGlrZSB3aGV0aGVyIHRoZSA0MDEgcmVzcG9uc2Ugd2FzIFxuICAgICAgIyBjYXVzZWQgYnkgYmFkIHVzZXIgaWQgdnMgYmFkIHBhc3N3b3JkLlxuICAgICAgIyBJbiBkb2luZyBzbywgdGhleSBjYW4gZmlyc3Qgc2NhbiBmb3IgdmFsaWQgdXNlciBpZHMgcmVnYXJkbGVzcyBvZiB2YWxpZCBwYXNzd29yZHMuXG4gICAgICAjIERlbGF5IGJ5IGEgcmFuZG9tIGFtb3VudCB0byByZWR1Y2UgdGhlIGFiaWxpdHkgZm9yIGEgaGFja2VyIHRvIGRldGVybWluZSB0aGUgcmVzcG9uc2UgdGltZS5cbiAgICAgICMgU2VlIGh0dHBzOi8vd3d3Lm93YXNwLm9yZy9pbmRleC5waHAvQmxvY2tpbmdfQnJ1dGVfRm9yY2VfQXR0YWNrcyNGaW5kaW5nX090aGVyX0NvdW50ZXJtZWFzdXJlc1xuICAgICAgIyBTZWUgaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvVGltaW5nX2F0dGFja1xuICAgICAgbWluaW11bURlbGF5SW5NaWxsaXNlY29uZHMgPSA1MDBcbiAgICAgIHJhbmRvbU11bHRpcGxpZXJCZXR3ZWVuT25lQW5kVHdvID0gMSArIE1hdGgucmFuZG9tKClcbiAgICAgIGRlbGF5SW5NaWxsaXNlY29uZHMgPSBtaW5pbXVtRGVsYXlJbk1pbGxpc2Vjb25kcyAqIHJhbmRvbU11bHRpcGxpZXJCZXR3ZWVuT25lQW5kVHdvXG4gICAgICBNZXRlb3Iuc2V0VGltZW91dCBzZW5kUmVzcG9uc2UsIGRlbGF5SW5NaWxsaXNlY29uZHNcbiAgICBlbHNlXG4gICAgICBzZW5kUmVzcG9uc2UoKVxuXG4gICMjI1xuICAgIFJldHVybiB0aGUgb2JqZWN0IHdpdGggYWxsIG9mIHRoZSBrZXlzIGNvbnZlcnRlZCB0byBsb3dlcmNhc2VcbiAgIyMjXG4gIF9sb3dlckNhc2VLZXlzOiAob2JqZWN0KSAtPlxuICAgIF8uY2hhaW4gb2JqZWN0XG4gICAgLnBhaXJzKClcbiAgICAubWFwIChhdHRyKSAtPlxuICAgICAgW2F0dHJbMF0udG9Mb3dlckNhc2UoKSwgYXR0clsxXV1cbiAgICAub2JqZWN0KClcbiAgICAudmFsdWUoKVxuIiwiY2xhc3MgQFJlc3RpdnVzXG5cbiAgY29uc3RydWN0b3I6IChvcHRpb25zKSAtPlxuICAgIEBfcm91dGVzID0gW11cbiAgICBAX2NvbmZpZyA9XG4gICAgICBwYXRoczogW11cbiAgICAgIHVzZURlZmF1bHRBdXRoOiBmYWxzZVxuICAgICAgYXBpUGF0aDogJ2FwaS8nXG4gICAgICB2ZXJzaW9uOiBudWxsXG4gICAgICBwcmV0dHlKc29uOiBmYWxzZVxuICAgICAgYXV0aDpcbiAgICAgICAgdG9rZW46ICdzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMuaGFzaGVkVG9rZW4nXG4gICAgICAgIHVzZXI6IC0+XG4gICAgICAgICAgaWYgQHJlcXVlc3QuaGVhZGVyc1sneC1hdXRoLXRva2VuJ11cbiAgICAgICAgICAgIHRva2VuID0gQWNjb3VudHMuX2hhc2hMb2dpblRva2VuIEByZXF1ZXN0LmhlYWRlcnNbJ3gtYXV0aC10b2tlbiddXG4gICAgICAgICAgdXNlcklkOiBAcmVxdWVzdC5oZWFkZXJzWyd4LXVzZXItaWQnXVxuICAgICAgICAgIHRva2VuOiB0b2tlblxuICAgICAgZGVmYXVsdEhlYWRlcnM6XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgIGVuYWJsZUNvcnM6IHRydWVcblxuICAgICMgQ29uZmlndXJlIEFQSSB3aXRoIHRoZSBnaXZlbiBvcHRpb25zXG4gICAgXy5leHRlbmQgQF9jb25maWcsIG9wdGlvbnNcblxuICAgIGlmIEBfY29uZmlnLmVuYWJsZUNvcnNcbiAgICAgIGNvcnNIZWFkZXJzID1cbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJ1xuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdPcmlnaW4sIFgtUmVxdWVzdGVkLVdpdGgsIENvbnRlbnQtVHlwZSwgQWNjZXB0J1xuXG4gICAgICBpZiBAX2NvbmZpZy51c2VEZWZhdWx0QXV0aFxuICAgICAgICBjb3JzSGVhZGVyc1snQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyddICs9ICcsIFgtVXNlci1JZCwgWC1BdXRoLVRva2VuJ1xuXG4gICAgICAjIFNldCBkZWZhdWx0IGhlYWRlciB0byBlbmFibGUgQ09SUyBpZiBjb25maWd1cmVkXG4gICAgICBfLmV4dGVuZCBAX2NvbmZpZy5kZWZhdWx0SGVhZGVycywgY29yc0hlYWRlcnNcblxuICAgICAgaWYgbm90IEBfY29uZmlnLmRlZmF1bHRPcHRpb25zRW5kcG9pbnRcbiAgICAgICAgQF9jb25maWcuZGVmYXVsdE9wdGlvbnNFbmRwb2ludCA9IC0+XG4gICAgICAgICAgQHJlc3BvbnNlLndyaXRlSGVhZCAyMDAsIGNvcnNIZWFkZXJzXG4gICAgICAgICAgQGRvbmUoKVxuXG4gICAgIyBOb3JtYWxpemUgdGhlIEFQSSBwYXRoXG4gICAgaWYgQF9jb25maWcuYXBpUGF0aFswXSBpcyAnLydcbiAgICAgIEBfY29uZmlnLmFwaVBhdGggPSBAX2NvbmZpZy5hcGlQYXRoLnNsaWNlIDFcbiAgICBpZiBfLmxhc3QoQF9jb25maWcuYXBpUGF0aCkgaXNudCAnLydcbiAgICAgIEBfY29uZmlnLmFwaVBhdGggPSBAX2NvbmZpZy5hcGlQYXRoICsgJy8nXG5cbiAgICAjIFVSTCBwYXRoIHZlcnNpb25pbmcgaXMgdGhlIG9ubHkgdHlwZSBvZiBBUEkgdmVyc2lvbmluZyBjdXJyZW50bHkgYXZhaWxhYmxlLCBzbyBpZiBhIHZlcnNpb24gaXNcbiAgICAjIHByb3ZpZGVkLCBhcHBlbmQgaXQgdG8gdGhlIGJhc2UgcGF0aCBvZiB0aGUgQVBJXG4gICAgaWYgQF9jb25maWcudmVyc2lvblxuICAgICAgQF9jb25maWcuYXBpUGF0aCArPSBAX2NvbmZpZy52ZXJzaW9uICsgJy8nXG5cbiAgICAjIEFkZCBkZWZhdWx0IGxvZ2luIGFuZCBsb2dvdXQgZW5kcG9pbnRzIGlmIGF1dGggaXMgY29uZmlndXJlZFxuICAgIGlmIEBfY29uZmlnLnVzZURlZmF1bHRBdXRoXG4gICAgICBAX2luaXRBdXRoKClcbiAgICBlbHNlIGlmIEBfY29uZmlnLnVzZUF1dGhcbiAgICAgIEBfaW5pdEF1dGgoKVxuICAgICAgY29uc29sZS53YXJuICdXYXJuaW5nOiB1c2VBdXRoIEFQSSBjb25maWcgb3B0aW9uIHdpbGwgYmUgcmVtb3ZlZCBpbiBSZXN0aXZ1cyB2MS4wICcgK1xuICAgICAgICAgICdcXG4gICAgVXNlIHRoZSB1c2VEZWZhdWx0QXV0aCBvcHRpb24gaW5zdGVhZCdcblxuICAgIHJldHVybiB0aGlzXG5cblxuICAjIyMqXG4gICAgQWRkIGVuZHBvaW50cyBmb3IgdGhlIGdpdmVuIEhUVFAgbWV0aG9kcyBhdCB0aGUgZ2l2ZW4gcGF0aFxuXG4gICAgQHBhcmFtIHBhdGgge1N0cmluZ30gVGhlIGV4dGVuZGVkIFVSTCBwYXRoICh3aWxsIGJlIGFwcGVuZGVkIHRvIGJhc2UgcGF0aCBvZiB0aGUgQVBJKVxuICAgIEBwYXJhbSBvcHRpb25zIHtPYmplY3R9IFJvdXRlIGNvbmZpZ3VyYXRpb24gb3B0aW9uc1xuICAgIEBwYXJhbSBvcHRpb25zLmF1dGhSZXF1aXJlZCB7Qm9vbGVhbn0gVGhlIGRlZmF1bHQgYXV0aCByZXF1aXJlbWVudCBmb3IgZWFjaCBlbmRwb2ludCBvbiB0aGUgcm91dGVcbiAgICBAcGFyYW0gb3B0aW9ucy5yb2xlUmVxdWlyZWQge1N0cmluZyBvciBTdHJpbmdbXX0gVGhlIGRlZmF1bHQgcm9sZSByZXF1aXJlZCBmb3IgZWFjaCBlbmRwb2ludCBvbiB0aGUgcm91dGVcbiAgICBAcGFyYW0gZW5kcG9pbnRzIHtPYmplY3R9IEEgc2V0IG9mIGVuZHBvaW50cyBhdmFpbGFibGUgb24gdGhlIG5ldyByb3V0ZSAoZ2V0LCBwb3N0LCBwdXQsIHBhdGNoLCBkZWxldGUsIG9wdGlvbnMpXG4gICAgQHBhcmFtIGVuZHBvaW50cy48bWV0aG9kPiB7RnVuY3Rpb24gb3IgT2JqZWN0fSBJZiBhIGZ1bmN0aW9uIGlzIHByb3ZpZGVkLCBhbGwgZGVmYXVsdCByb3V0ZVxuICAgICAgICBjb25maWd1cmF0aW9uIG9wdGlvbnMgd2lsbCBiZSBhcHBsaWVkIHRvIHRoZSBlbmRwb2ludC4gT3RoZXJ3aXNlIGFuIG9iamVjdCB3aXRoIGFuIGBhY3Rpb25gXG4gICAgICAgIGFuZCBhbGwgb3RoZXIgcm91dGUgY29uZmlnIG9wdGlvbnMgYXZhaWxhYmxlLiBBbiBgYWN0aW9uYCBtdXN0IGJlIHByb3ZpZGVkIHdpdGggdGhlIG9iamVjdC5cbiAgIyMjXG4gIGFkZFJvdXRlOiAocGF0aCwgb3B0aW9ucywgZW5kcG9pbnRzKSAtPlxuICAgICMgQ3JlYXRlIGEgbmV3IHJvdXRlIGFuZCBhZGQgaXQgdG8gb3VyIGxpc3Qgb2YgZXhpc3Rpbmcgcm91dGVzXG4gICAgcm91dGUgPSBuZXcgc2hhcmUuUm91dGUodGhpcywgcGF0aCwgb3B0aW9ucywgZW5kcG9pbnRzKVxuICAgIEBfcm91dGVzLnB1c2gocm91dGUpXG5cbiAgICByb3V0ZS5hZGRUb0FwaSgpXG5cbiAgICByZXR1cm4gdGhpc1xuXG5cbiAgIyMjKlxuICAgIEdlbmVyYXRlIHJvdXRlcyBmb3IgdGhlIE1ldGVvciBDb2xsZWN0aW9uIHdpdGggdGhlIGdpdmVuIG5hbWVcbiAgIyMjXG4gIGFkZENvbGxlY3Rpb246IChjb2xsZWN0aW9uLCBvcHRpb25zPXt9KSAtPlxuICAgIG1ldGhvZHMgPSBbJ2dldCcsICdwb3N0JywgJ3B1dCcsICdkZWxldGUnLCAnZ2V0QWxsJ11cbiAgICBtZXRob2RzT25Db2xsZWN0aW9uID0gWydwb3N0JywgJ2dldEFsbCddXG5cbiAgICAjIEdyYWIgdGhlIHNldCBvZiBlbmRwb2ludHNcbiAgICBpZiBjb2xsZWN0aW9uIGlzIE1ldGVvci51c2Vyc1xuICAgICAgY29sbGVjdGlvbkVuZHBvaW50cyA9IEBfdXNlckNvbGxlY3Rpb25FbmRwb2ludHNcbiAgICBlbHNlXG4gICAgICBjb2xsZWN0aW9uRW5kcG9pbnRzID0gQF9jb2xsZWN0aW9uRW5kcG9pbnRzXG5cbiAgICAjIEZsYXR0ZW4gdGhlIG9wdGlvbnMgYW5kIHNldCBkZWZhdWx0cyBpZiBuZWNlc3NhcnlcbiAgICBlbmRwb2ludHNBd2FpdGluZ0NvbmZpZ3VyYXRpb24gPSBvcHRpb25zLmVuZHBvaW50cyBvciB7fVxuICAgIHJvdXRlT3B0aW9ucyA9IG9wdGlvbnMucm91dGVPcHRpb25zIG9yIHt9XG4gICAgZXhjbHVkZWRFbmRwb2ludHMgPSBvcHRpb25zLmV4Y2x1ZGVkRW5kcG9pbnRzIG9yIFtdXG4gICAgIyBVc2UgY29sbGVjdGlvbiBuYW1lIGFzIGRlZmF1bHQgcGF0aFxuICAgIHBhdGggPSBvcHRpb25zLnBhdGggb3IgY29sbGVjdGlvbi5fbmFtZVxuXG4gICAgIyBTZXBhcmF0ZSB0aGUgcmVxdWVzdGVkIGVuZHBvaW50cyBieSB0aGUgcm91dGUgdGhleSBiZWxvbmcgdG8gKG9uZSBmb3Igb3BlcmF0aW5nIG9uIHRoZSBlbnRpcmVcbiAgICAjIGNvbGxlY3Rpb24gYW5kIG9uZSBmb3Igb3BlcmF0aW5nIG9uIGEgc2luZ2xlIGVudGl0eSB3aXRoaW4gdGhlIGNvbGxlY3Rpb24pXG4gICAgY29sbGVjdGlvblJvdXRlRW5kcG9pbnRzID0ge31cbiAgICBlbnRpdHlSb3V0ZUVuZHBvaW50cyA9IHt9XG4gICAgaWYgXy5pc0VtcHR5KGVuZHBvaW50c0F3YWl0aW5nQ29uZmlndXJhdGlvbikgYW5kIF8uaXNFbXB0eShleGNsdWRlZEVuZHBvaW50cylcbiAgICAgICMgR2VuZXJhdGUgYWxsIGVuZHBvaW50cyBvbiB0aGlzIGNvbGxlY3Rpb25cbiAgICAgIF8uZWFjaCBtZXRob2RzLCAobWV0aG9kKSAtPlxuICAgICAgICAjIFBhcnRpdGlvbiB0aGUgZW5kcG9pbnRzIGludG8gdGhlaXIgcmVzcGVjdGl2ZSByb3V0ZXNcbiAgICAgICAgaWYgbWV0aG9kIGluIG1ldGhvZHNPbkNvbGxlY3Rpb25cbiAgICAgICAgICBfLmV4dGVuZCBjb2xsZWN0aW9uUm91dGVFbmRwb2ludHMsIGNvbGxlY3Rpb25FbmRwb2ludHNbbWV0aG9kXS5jYWxsKHRoaXMsIGNvbGxlY3Rpb24pXG4gICAgICAgIGVsc2UgXy5leHRlbmQgZW50aXR5Um91dGVFbmRwb2ludHMsIGNvbGxlY3Rpb25FbmRwb2ludHNbbWV0aG9kXS5jYWxsKHRoaXMsIGNvbGxlY3Rpb24pXG4gICAgICAgIHJldHVyblxuICAgICAgLCB0aGlzXG4gICAgZWxzZVxuICAgICAgIyBHZW5lcmF0ZSBhbnkgZW5kcG9pbnRzIHRoYXQgaGF2ZW4ndCBiZWVuIGV4cGxpY2l0bHkgZXhjbHVkZWRcbiAgICAgIF8uZWFjaCBtZXRob2RzLCAobWV0aG9kKSAtPlxuICAgICAgICBpZiBtZXRob2Qgbm90IGluIGV4Y2x1ZGVkRW5kcG9pbnRzIGFuZCBlbmRwb2ludHNBd2FpdGluZ0NvbmZpZ3VyYXRpb25bbWV0aG9kXSBpc250IGZhbHNlXG4gICAgICAgICAgIyBDb25maWd1cmUgZW5kcG9pbnQgYW5kIG1hcCB0byBpdCdzIGh0dHAgbWV0aG9kXG4gICAgICAgICAgIyBUT0RPOiBDb25zaWRlciBwcmVkZWZpbmluZyBhIG1hcCBvZiBtZXRob2RzIHRvIHRoZWlyIGh0dHAgbWV0aG9kIHR5cGUgKGUuZy4sIGdldEFsbDogZ2V0KVxuICAgICAgICAgIGVuZHBvaW50T3B0aW9ucyA9IGVuZHBvaW50c0F3YWl0aW5nQ29uZmlndXJhdGlvblttZXRob2RdXG4gICAgICAgICAgY29uZmlndXJlZEVuZHBvaW50ID0ge31cbiAgICAgICAgICBfLmVhY2ggY29sbGVjdGlvbkVuZHBvaW50c1ttZXRob2RdLmNhbGwodGhpcywgY29sbGVjdGlvbiksIChhY3Rpb24sIG1ldGhvZFR5cGUpIC0+XG4gICAgICAgICAgICBjb25maWd1cmVkRW5kcG9pbnRbbWV0aG9kVHlwZV0gPVxuICAgICAgICAgICAgICBfLmNoYWluIGFjdGlvblxuICAgICAgICAgICAgICAuY2xvbmUoKVxuICAgICAgICAgICAgICAuZXh0ZW5kIGVuZHBvaW50T3B0aW9uc1xuICAgICAgICAgICAgICAudmFsdWUoKVxuICAgICAgICAgICMgUGFydGl0aW9uIHRoZSBlbmRwb2ludHMgaW50byB0aGVpciByZXNwZWN0aXZlIHJvdXRlc1xuICAgICAgICAgIGlmIG1ldGhvZCBpbiBtZXRob2RzT25Db2xsZWN0aW9uXG4gICAgICAgICAgICBfLmV4dGVuZCBjb2xsZWN0aW9uUm91dGVFbmRwb2ludHMsIGNvbmZpZ3VyZWRFbmRwb2ludFxuICAgICAgICAgIGVsc2UgXy5leHRlbmQgZW50aXR5Um91dGVFbmRwb2ludHMsIGNvbmZpZ3VyZWRFbmRwb2ludFxuICAgICAgICAgIHJldHVyblxuICAgICAgLCB0aGlzXG5cbiAgICAjIEFkZCB0aGUgcm91dGVzIHRvIHRoZSBBUElcbiAgICBAYWRkUm91dGUgcGF0aCwgcm91dGVPcHRpb25zLCBjb2xsZWN0aW9uUm91dGVFbmRwb2ludHNcbiAgICBAYWRkUm91dGUgXCIje3BhdGh9LzppZFwiLCByb3V0ZU9wdGlvbnMsIGVudGl0eVJvdXRlRW5kcG9pbnRzXG5cbiAgICByZXR1cm4gdGhpc1xuXG5cbiAgIyMjKlxuICAgIEEgc2V0IG9mIGVuZHBvaW50cyB0aGF0IGNhbiBiZSBhcHBsaWVkIHRvIGEgQ29sbGVjdGlvbiBSb3V0ZVxuICAjIyNcbiAgX2NvbGxlY3Rpb25FbmRwb2ludHM6XG4gICAgZ2V0OiAoY29sbGVjdGlvbikgLT5cbiAgICAgIGdldDpcbiAgICAgICAgYWN0aW9uOiAtPlxuICAgICAgICAgIGVudGl0eSA9IGNvbGxlY3Rpb24uZmluZE9uZSBAdXJsUGFyYW1zLmlkXG4gICAgICAgICAgaWYgZW50aXR5XG4gICAgICAgICAgICB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGVudGl0eX1cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDRcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ0l0ZW0gbm90IGZvdW5kJ31cbiAgICBwdXQ6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgcHV0OlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgZW50aXR5SXNVcGRhdGVkID0gY29sbGVjdGlvbi51cGRhdGUgQHVybFBhcmFtcy5pZCwgQGJvZHlQYXJhbXNcbiAgICAgICAgICBpZiBlbnRpdHlJc1VwZGF0ZWRcbiAgICAgICAgICAgIGVudGl0eSA9IGNvbGxlY3Rpb24uZmluZE9uZSBAdXJsUGFyYW1zLmlkXG4gICAgICAgICAgICB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGVudGl0eX1cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDRcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ0l0ZW0gbm90IGZvdW5kJ31cbiAgICBkZWxldGU6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgZGVsZXRlOlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgaWYgY29sbGVjdGlvbi5yZW1vdmUgQHVybFBhcmFtcy5pZFxuICAgICAgICAgICAge3N0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiBtZXNzYWdlOiAnSXRlbSByZW1vdmVkJ31cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDRcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ0l0ZW0gbm90IGZvdW5kJ31cbiAgICBwb3N0OiAoY29sbGVjdGlvbikgLT5cbiAgICAgIHBvc3Q6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICBlbnRpdHlJZCA9IGNvbGxlY3Rpb24uaW5zZXJ0IEBib2R5UGFyYW1zXG4gICAgICAgICAgZW50aXR5ID0gY29sbGVjdGlvbi5maW5kT25lIGVudGl0eUlkXG4gICAgICAgICAgaWYgZW50aXR5XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiAyMDFcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogZW50aXR5fVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnTm8gaXRlbSBhZGRlZCd9XG4gICAgZ2V0QWxsOiAoY29sbGVjdGlvbikgLT5cbiAgICAgIGdldDpcbiAgICAgICAgYWN0aW9uOiAtPlxuICAgICAgICAgIGVudGl0aWVzID0gY29sbGVjdGlvbi5maW5kKCkuZmV0Y2goKVxuICAgICAgICAgIGlmIGVudGl0aWVzXG4gICAgICAgICAgICB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGVudGl0aWVzfVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnVW5hYmxlIHRvIHJldHJpZXZlIGl0ZW1zIGZyb20gY29sbGVjdGlvbid9XG5cblxuICAjIyMqXG4gICAgQSBzZXQgb2YgZW5kcG9pbnRzIHRoYXQgY2FuIGJlIGFwcGxpZWQgdG8gYSBNZXRlb3IudXNlcnMgQ29sbGVjdGlvbiBSb3V0ZVxuICAjIyNcbiAgX3VzZXJDb2xsZWN0aW9uRW5kcG9pbnRzOlxuICAgIGdldDogKGNvbGxlY3Rpb24pIC0+XG4gICAgICBnZXQ6XG4gICAgICAgIGFjdGlvbjogLT5cbiAgICAgICAgICBlbnRpdHkgPSBjb2xsZWN0aW9uLmZpbmRPbmUgQHVybFBhcmFtcy5pZCwgZmllbGRzOiBwcm9maWxlOiAxXG4gICAgICAgICAgaWYgZW50aXR5XG4gICAgICAgICAgICB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGVudGl0eX1cbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDRcbiAgICAgICAgICAgIGJvZHk6IHtzdGF0dXM6ICdmYWlsJywgbWVzc2FnZTogJ1VzZXIgbm90IGZvdW5kJ31cbiAgICBwdXQ6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgcHV0OlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgZW50aXR5SXNVcGRhdGVkID0gY29sbGVjdGlvbi51cGRhdGUgQHVybFBhcmFtcy5pZCwgJHNldDogcHJvZmlsZTogQGJvZHlQYXJhbXNcbiAgICAgICAgICBpZiBlbnRpdHlJc1VwZGF0ZWRcbiAgICAgICAgICAgIGVudGl0eSA9IGNvbGxlY3Rpb24uZmluZE9uZSBAdXJsUGFyYW1zLmlkLCBmaWVsZHM6IHByb2ZpbGU6IDFcbiAgICAgICAgICAgIHtzdGF0dXM6IFwic3VjY2Vzc1wiLCBkYXRhOiBlbnRpdHl9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDA0XG4gICAgICAgICAgICBib2R5OiB7c3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6ICdVc2VyIG5vdCBmb3VuZCd9XG4gICAgZGVsZXRlOiAoY29sbGVjdGlvbikgLT5cbiAgICAgIGRlbGV0ZTpcbiAgICAgICAgYWN0aW9uOiAtPlxuICAgICAgICAgIGlmIGNvbGxlY3Rpb24ucmVtb3ZlIEB1cmxQYXJhbXMuaWRcbiAgICAgICAgICAgIHtzdGF0dXM6ICdzdWNjZXNzJywgZGF0YTogbWVzc2FnZTogJ1VzZXIgcmVtb3ZlZCd9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDA0XG4gICAgICAgICAgICBib2R5OiB7c3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6ICdVc2VyIG5vdCBmb3VuZCd9XG4gICAgcG9zdDogKGNvbGxlY3Rpb24pIC0+XG4gICAgICBwb3N0OlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgIyBDcmVhdGUgYSBuZXcgdXNlciBhY2NvdW50XG4gICAgICAgICAgZW50aXR5SWQgPSBBY2NvdW50cy5jcmVhdGVVc2VyIEBib2R5UGFyYW1zXG4gICAgICAgICAgZW50aXR5ID0gY29sbGVjdGlvbi5maW5kT25lIGVudGl0eUlkLCBmaWVsZHM6IHByb2ZpbGU6IDFcbiAgICAgICAgICBpZiBlbnRpdHlcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMVxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiBlbnRpdHl9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwXG4gICAgICAgICAgICB7c3RhdHVzOiAnZmFpbCcsIG1lc3NhZ2U6ICdObyB1c2VyIGFkZGVkJ31cbiAgICBnZXRBbGw6IChjb2xsZWN0aW9uKSAtPlxuICAgICAgZ2V0OlxuICAgICAgICBhY3Rpb246IC0+XG4gICAgICAgICAgZW50aXRpZXMgPSBjb2xsZWN0aW9uLmZpbmQoe30sIGZpZWxkczogcHJvZmlsZTogMSkuZmV0Y2goKVxuICAgICAgICAgIGlmIGVudGl0aWVzXG4gICAgICAgICAgICB7c3RhdHVzOiAnc3VjY2VzcycsIGRhdGE6IGVudGl0aWVzfVxuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwNFxuICAgICAgICAgICAgYm9keToge3N0YXR1czogJ2ZhaWwnLCBtZXNzYWdlOiAnVW5hYmxlIHRvIHJldHJpZXZlIHVzZXJzJ31cblxuXG4gICMjI1xuICAgIEFkZCAvbG9naW4gYW5kIC9sb2dvdXQgZW5kcG9pbnRzIHRvIHRoZSBBUElcbiAgIyMjXG4gIF9pbml0QXV0aDogLT5cbiAgICBzZWxmID0gdGhpc1xuICAgICMjI1xuICAgICAgQWRkIGEgbG9naW4gZW5kcG9pbnQgdG8gdGhlIEFQSVxuXG4gICAgICBBZnRlciB0aGUgdXNlciBpcyBsb2dnZWQgaW4sIHRoZSBvbkxvZ2dlZEluIGhvb2sgaXMgY2FsbGVkIChzZWUgUmVzdGZ1bGx5LmNvbmZpZ3VyZSgpIGZvclxuICAgICAgYWRkaW5nIGhvb2spLlxuICAgICMjI1xuICAgIEBhZGRSb3V0ZSAnbG9naW4nLCB7YXV0aFJlcXVpcmVkOiBmYWxzZX0sXG4gICAgICBwb3N0OiAtPlxuICAgICAgICAjIEdyYWIgdGhlIHVzZXJuYW1lIG9yIGVtYWlsIHRoYXQgdGhlIHVzZXIgaXMgbG9nZ2luZyBpbiB3aXRoXG4gICAgICAgIHVzZXIgPSB7fVxuICAgICAgICBpZiBAYm9keVBhcmFtcy51c2VyXG4gICAgICAgICAgaWYgQGJvZHlQYXJhbXMudXNlci5pbmRleE9mKCdAJykgaXMgLTFcbiAgICAgICAgICAgIHVzZXIudXNlcm5hbWUgPSBAYm9keVBhcmFtcy51c2VyXG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgdXNlci5lbWFpbCA9IEBib2R5UGFyYW1zLnVzZXJcbiAgICAgICAgZWxzZSBpZiBAYm9keVBhcmFtcy51c2VybmFtZVxuICAgICAgICAgIHVzZXIudXNlcm5hbWUgPSBAYm9keVBhcmFtcy51c2VybmFtZVxuICAgICAgICBlbHNlIGlmIEBib2R5UGFyYW1zLmVtYWlsXG4gICAgICAgICAgdXNlci5lbWFpbCA9IEBib2R5UGFyYW1zLmVtYWlsXG5cbiAgICAgICAgIyBUcnkgdG8gbG9nIHRoZSB1c2VyIGludG8gdGhlIHVzZXIncyBhY2NvdW50IChpZiBzdWNjZXNzZnVsIHdlJ2xsIGdldCBhbiBhdXRoIHRva2VuIGJhY2spXG4gICAgICAgIHRyeVxuICAgICAgICAgIGF1dGggPSBBdXRoLmxvZ2luV2l0aFBhc3N3b3JkIHVzZXIsIEBib2R5UGFyYW1zLnBhc3N3b3JkXG4gICAgICAgIGNhdGNoIGVcbiAgICAgICAgICByZXR1cm4ge30gPVxuICAgICAgICAgICAgc3RhdHVzQ29kZTogZS5lcnJvclxuICAgICAgICAgICAgYm9keTogc3RhdHVzOiAnZXJyb3InLCBtZXNzYWdlOiBlLnJlYXNvblxuXG4gICAgICAgICMgR2V0IHRoZSBhdXRoZW50aWNhdGVkIHVzZXJcbiAgICAgICAgIyBUT0RPOiBDb25zaWRlciByZXR1cm5pbmcgdGhlIHVzZXIgaW4gQXV0aC5sb2dpbldpdGhQYXNzd29yZCgpLCBpbnN0ZWFkIG9mIGZldGNoaW5nIGl0IGFnYWluIGhlcmVcbiAgICAgICAgaWYgYXV0aC51c2VySWQgYW5kIGF1dGguYXV0aFRva2VuXG4gICAgICAgICAgc2VhcmNoUXVlcnkgPSB7fVxuICAgICAgICAgIHNlYXJjaFF1ZXJ5W3NlbGYuX2NvbmZpZy5hdXRoLnRva2VuXSA9IEFjY291bnRzLl9oYXNoTG9naW5Ub2tlbiBhdXRoLmF1dGhUb2tlblxuICAgICAgICAgIEB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmVcbiAgICAgICAgICAgICdfaWQnOiBhdXRoLnVzZXJJZFxuICAgICAgICAgICAgc2VhcmNoUXVlcnlcbiAgICAgICAgICBAdXNlcklkID0gQHVzZXI/Ll9pZFxuXG4gICAgICAgIHJlc3BvbnNlID0ge3N0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiBhdXRofVxuXG4gICAgICAgICMgQ2FsbCB0aGUgbG9naW4gaG9vayB3aXRoIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIgYXR0YWNoZWRcbiAgICAgICAgZXh0cmFEYXRhID0gc2VsZi5fY29uZmlnLm9uTG9nZ2VkSW4/LmNhbGwodGhpcylcbiAgICAgICAgaWYgZXh0cmFEYXRhP1xuICAgICAgICAgIF8uZXh0ZW5kKHJlc3BvbnNlLmRhdGEsIHtleHRyYTogZXh0cmFEYXRhfSlcblxuICAgICAgICByZXNwb25zZVxuXG4gICAgbG9nb3V0ID0gLT5cbiAgICAgICMgUmVtb3ZlIHRoZSBnaXZlbiBhdXRoIHRva2VuIGZyb20gdGhlIHVzZXIncyBhY2NvdW50XG4gICAgICBhdXRoVG9rZW4gPSBAcmVxdWVzdC5oZWFkZXJzWyd4LWF1dGgtdG9rZW4nXVxuICAgICAgaGFzaGVkVG9rZW4gPSBBY2NvdW50cy5faGFzaExvZ2luVG9rZW4gYXV0aFRva2VuXG4gICAgICB0b2tlbkxvY2F0aW9uID0gc2VsZi5fY29uZmlnLmF1dGgudG9rZW5cbiAgICAgIGluZGV4ID0gdG9rZW5Mb2NhdGlvbi5sYXN0SW5kZXhPZiAnLidcbiAgICAgIHRva2VuUGF0aCA9IHRva2VuTG9jYXRpb24uc3Vic3RyaW5nIDAsIGluZGV4XG4gICAgICB0b2tlbkZpZWxkTmFtZSA9IHRva2VuTG9jYXRpb24uc3Vic3RyaW5nIGluZGV4ICsgMVxuICAgICAgdG9rZW5Ub1JlbW92ZSA9IHt9XG4gICAgICB0b2tlblRvUmVtb3ZlW3Rva2VuRmllbGROYW1lXSA9IGhhc2hlZFRva2VuXG4gICAgICB0b2tlblJlbW92YWxRdWVyeSA9IHt9XG4gICAgICB0b2tlblJlbW92YWxRdWVyeVt0b2tlblBhdGhdID0gdG9rZW5Ub1JlbW92ZVxuICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSBAdXNlci5faWQsIHskcHVsbDogdG9rZW5SZW1vdmFsUXVlcnl9XG5cbiAgICAgIHJlc3BvbnNlID0ge3N0YXR1czogJ3N1Y2Nlc3MnLCBkYXRhOiB7bWVzc2FnZTogJ1lvdVxcJ3ZlIGJlZW4gbG9nZ2VkIG91dCEnfX1cblxuICAgICAgIyBDYWxsIHRoZSBsb2dvdXQgaG9vayB3aXRoIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIgYXR0YWNoZWRcbiAgICAgIGV4dHJhRGF0YSA9IHNlbGYuX2NvbmZpZy5vbkxvZ2dlZE91dD8uY2FsbCh0aGlzKVxuICAgICAgaWYgZXh0cmFEYXRhP1xuICAgICAgICBfLmV4dGVuZChyZXNwb25zZS5kYXRhLCB7ZXh0cmE6IGV4dHJhRGF0YX0pXG5cbiAgICAgIHJlc3BvbnNlXG5cbiAgICAjIyNcbiAgICAgIEFkZCBhIGxvZ291dCBlbmRwb2ludCB0byB0aGUgQVBJXG5cbiAgICAgIEFmdGVyIHRoZSB1c2VyIGlzIGxvZ2dlZCBvdXQsIHRoZSBvbkxvZ2dlZE91dCBob29rIGlzIGNhbGxlZCAoc2VlIFJlc3RmdWxseS5jb25maWd1cmUoKSBmb3JcbiAgICAgIGFkZGluZyBob29rKS5cbiAgICAjIyNcbiAgICBAYWRkUm91dGUgJ2xvZ291dCcsIHthdXRoUmVxdWlyZWQ6IHRydWV9LFxuICAgICAgZ2V0OiAtPlxuICAgICAgICBjb25zb2xlLndhcm4gXCJXYXJuaW5nOiBEZWZhdWx0IGxvZ291dCB2aWEgR0VUIHdpbGwgYmUgcmVtb3ZlZCBpbiBSZXN0aXZ1cyB2MS4wLiBVc2UgUE9TVCBpbnN0ZWFkLlwiXG4gICAgICAgIGNvbnNvbGUud2FybiBcIiAgICBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2thaG1hbGkvbWV0ZW9yLXJlc3RpdnVzL2lzc3Vlcy8xMDBcIlxuICAgICAgICByZXR1cm4gbG9nb3V0LmNhbGwodGhpcylcbiAgICAgIHBvc3Q6IGxvZ291dFxuXG5SZXN0aXZ1cyA9IEBSZXN0aXZ1c1xuIl19
